import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { sql } from "drizzle-orm";
import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

const instant = (name: string) => timestamp(name, { withTimezone: true });

export const departmentsTable = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  createdAt: instant("created_at").notNull().defaultNow(),
});

export const employeesTable = pgTable("employees", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  departmentId: integer("department_id")
    .notNull()
    .references(() => departmentsTable.id),
  active: boolean("active").notNull().default(true),
  createdAt: instant("created_at").notNull().defaultNow(),
}, table => [
  uniqueIndex("employees_email_normalized_unique").on(sql`lower(btrim(${table.email}))`),
]);

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  clerkUserId: text("clerk_user_id").unique(),
  email: text("email").unique(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  employeeId: integer("employee_id").references(() => employeesTable.id),
  createdAt: instant("created_at").notNull().defaultNow(),
  updatedAt: instant("updated_at").notNull().defaultNow(),
}, table => [
  uniqueIndex("users_email_normalized_unique").on(sql`lower(btrim(${table.email}))`),
]);

export const transactionsTable = pgTable("employee_transactions", {
  id: serial("id").primaryKey(),
  number: text("number").notNull().unique(),
  subject: text("subject").notNull(),
  employeeId: integer("employee_id")
    .notNull()
    .references(() => employeesTable.id),
  departmentId: integer("department_id")
    .notNull()
    .references(() => departmentsTable.id),
  type: text("type").notNull(),
  receivedAt: instant("received_at").notNull(),
  currentEntity: text("current_entity").notNull(),
  status: text("status").notNull(),
  priority: text("priority").notNull().default("normal"),
  lastUpdatedAt: instant("last_updated_at"),
  nextFollowUpAt: instant("next_follow_up_at"),
  notes: text("notes").notNull().default(""),
  createdAt: instant("created_at").notNull().defaultNow(),
});

export const transactionUpdatesTable = pgTable("transaction_updates", {
  id: serial("id").primaryKey(),
  transactionId: integer("transaction_id")
    .notNull()
    .references(() => transactionsTable.id),
  authorUserId: integer("author_user_id")
    .notNull()
    .references(() => usersTable.id),
  previousStatus: text("previous_status"),
  newStatus: text("new_status").notNull(),
  action: text("action").notNull(),
  notes: text("notes").notNull().default(""),
  createdAt: instant("created_at").notNull().defaultNow(),
});

export const attachmentsTable = pgTable("attachments", {
  id: serial("id").primaryKey(),
  transactionUpdateId: integer("transaction_update_id")
    .references(() => transactionUpdatesTable.id),
  uploadedBy: integer("uploaded_by")
    .notNull()
    .references(() => usersTable.id),
  fileName: text("file_name").notNull(),
  objectPath: text("object_path").notNull(),
  contentType: text("content_type").notNull(),
  size: integer("size").notNull(),
  createdAt: instant("created_at").notNull().defaultNow(),
});

export const notificationsTable = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => usersTable.id),
  type: text("type").notNull(),
  message: text("message").notNull(),
  transactionId: integer("transaction_id").references(() => transactionsTable.id),
  createdAt: instant("created_at").notNull().defaultNow(),
  readAt: instant("read_at"),
});

export const settingsTable = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: instant("updated_at").notNull().defaultNow(),
});

export const auditLogsTable = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => usersTable.id),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: integer("entity_id"),
  details: jsonb("details").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: instant("created_at").notNull().defaultNow(),
});

export const insertDepartmentSchema = createInsertSchema(departmentsTable).omit({
  id: true,
  createdAt: true,
});
export const insertEmployeeSchema = createInsertSchema(employeesTable).omit({
  id: true,
  createdAt: true,
});
export const insertUserSchema = createInsertSchema(usersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertTransactionSchema = createInsertSchema(transactionsTable).omit({
  id: true,
  lastUpdatedAt: true,
  createdAt: true,
});
export const insertTransactionUpdateSchema = createInsertSchema(
  transactionUpdatesTable,
).omit({ id: true, createdAt: true });
export const insertAttachmentSchema = createInsertSchema(attachmentsTable).omit({
  id: true,
  createdAt: true,
});
export const insertNotificationSchema = createInsertSchema(notificationsTable).omit({
  id: true,
  createdAt: true,
});
export const insertAuditLogSchema = createInsertSchema(auditLogsTable).omit({
  id: true,
  createdAt: true,
});

export type User = typeof usersTable.$inferSelect;
export type Employee = typeof employeesTable.$inferSelect;
export type Transaction = typeof transactionsTable.$inferSelect;
export type TransactionUpdate = typeof transactionUpdatesTable.$inferSelect;
export type Attachment = typeof attachmentsTable.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
