import { useState, type FormEvent } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  getGetSupervisorsQueryKey, useGetSupervisors, useAppointSupervisor,
  useRevokeSupervisor, type Supervisor,
} from '@workspace/api-client-react';
import { ShieldCheck } from 'lucide-react';

export function SupervisorManagement() {
  const query = useGetSupervisors();
  const appoint = useAppointSupervisor();
  const revoke = useRevokeSupervisor();
  const client = useQueryClient();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setMessage('');
    if (!window.confirm('سيحصل هذا الحساب على صلاحيات المشرف، بما فيها الاطلاع على جميع المعاملات وتعيين مشرفين آخرين. تبقى إدارة عبارة التوثيق وإلغاء صلاحيات المشرفين للمشرف الرئيس فقط. هل تريد المتابعة؟')) return;
    appoint.mutate({ data: { name: name.trim(), email: email.trim().toLowerCase() } }, {
      onSuccess: async (account) => {
        await client.invalidateQueries({ queryKey: getGetSupervisorsQueryKey() });
        setName('');
        setEmail('');
        setMessage(`تم تعيين ${account.name} مشرفًا.`);
      },
      onError: () => setError('تعذر تعيين المشرف. تحقق من البيانات وصلاحياتك ثم أعد المحاولة.'),
    });
  };

  const remove = (account: Supervisor) => {
    setError('');
    setMessage('');
    if (!window.confirm(`هل تريد إلغاء صلاحية الإشراف للحساب «${account.name}»؟ سيعود موظفًا إذا كان مرتبطًا بموظف، وإلا سيُمنع من دخول النظام. لن تُحذف بياناته أو تحديثاته أو مرفقاته السابقة.`)) return;
    revoke.mutate({ id: account.id }, {
      onSuccess: async result => {
        await client.invalidateQueries({ queryKey: getGetSupervisorsQueryKey() });
        setMessage(result.role === 'employee'
          ? `أُلغيت صلاحية الإشراف للحساب ${account.name}. عاد إلى صلاحيات الموظف، مع حفظ سجله.`
          : `أُلغيت صلاحية الإشراف للحساب ${account.name}. لا يستطيع دخول النظام لعدم وجود حساب موظف مرتبط به، مع حفظ سجله.`);
      },
      onError: () => {
        setError('تعذر إلغاء صلاحية الإشراف. هذه العملية للمشرف الرئيس فقط ولا يمكن إلغاء صلاحيات حسابه.');
        void client.invalidateQueries({ queryKey: getGetSupervisorsQueryKey() });
      },
    });
  };

  return <section className="panel mt-5 rounded-2xl p-5 md:p-6">
    <div className="flex items-center gap-3">
      <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#e5f0e8] text-[#2f6855]"><ShieldCheck size={18}/></div>
      <div><h2 className="font-bold">إدارة المشرفين</h2><p className="mt-1 text-xs text-[#7b857e]">يمكن لكل مشرف تعيين مشرفين آخرين. إلغاء الإشراف وإدارة عبارة التوثيق للمشرف الرئيس فقط.</p></div>
    </div>
    <p className="mt-4 text-xs leading-6 text-[#727e75]">أدخل بريد تسجيل الدخول الصحيح. إذا كان الحساب موظفًا موجودًا، تُمنح له صلاحيات المشرف مع الحفاظ على بياناته ومعاملاته. للحساب الجديد يُستخدم الاسم المدخل، ويسجل صاحبه الدخول بالبريد الموثق نفسه؛ لا تُرسل دعوة بالبريد تلقائيًا.</p>
    <form onSubmit={submit} className="mt-4 grid gap-3 sm:grid-cols-2">
      <label className="text-xs font-bold">الاسم الكامل<input className="field mt-2" required maxLength={200} value={name} onChange={e => setName(e.target.value)} data-testid="input-supervisor-name"/></label>
      <label className="text-xs font-bold">البريد الإلكتروني<input className="field mt-2" type="email" dir="ltr" required maxLength={254} value={email} onChange={e => setEmail(e.target.value)} data-testid="input-supervisor-email"/></label>
      <div className="sm:col-span-2"><button className="btn-primary rounded-xl px-4 py-2 text-sm font-bold" disabled={appoint.isPending || revoke.isPending || !name.trim()} data-testid="button-appoint-supervisor">{appoint.isPending ? 'جارٍ التعيين…' : 'تعيين مشرف'}</button></div>
    </form>
    {message && <p role="status" className="mt-3 text-sm text-[#286149]">{message}</p>}
    {error && <p role="alert" className="mt-3 text-sm text-[#a04437]">{error}</p>}
    <h3 className="mt-6 text-sm font-bold">المشرفون الحاليون</h3>
    {query.isLoading ? <p className="mt-3 text-xs">جارٍ التحميل…</p> : query.isError ? <div role="alert" className="mt-3 text-sm text-[#a04437]">تعذر تحميل المشرفين. <button type="button" onClick={() => query.refetch()} className="underline">إعادة المحاولة</button></div> :
      <ul className="mt-3 divide-y divide-[#eee9df]">{query.data?.map(account => <li key={account.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm" data-testid={`supervisor-${account.id}`}><span className="font-semibold">{account.name}</span><span dir="ltr" className="text-xs text-[#7b857e]">{account.email || 'لم يُربط بريد بعد'}</span><span className="rounded-full bg-[#e5f1e9] px-3 py-1 text-xs text-[#286149]">مشرف</span>{account.canRevoke && <button type="button" disabled={revoke.isPending || appoint.isPending} onClick={() => remove(account)} className="rounded-lg border border-[#dfb7ae] px-3 py-1.5 text-xs font-bold text-[#a04437]" data-testid={`button-revoke-supervisor-${account.id}`}>{revoke.isPending && revoke.variables?.id === account.id ? 'جارٍ الإلغاء…' : 'إلغاء صلاحية الإشراف'}</button>}</li>)}</ul>}
  </section>;
}
