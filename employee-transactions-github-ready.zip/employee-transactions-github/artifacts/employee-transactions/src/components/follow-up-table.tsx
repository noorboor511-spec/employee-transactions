import type { Transaction } from '@workspace/api-client-react';
import { Link } from 'wouter';

function date(value: string | null) {
  return value ? new Intl.DateTimeFormat('ar-SA', {
    timeZone: 'Asia/Riyadh', dateStyle: 'medium', timeStyle: 'short',
  }).format(new Date(value)) : '—';
}

export function FollowUpTags({ transaction: t }: { transaction: Transaction }) {
  const labels = [
    t.needsFollowUp && 'تحتاج متابعة',
    t.overdue && 'متأخرة',
    t.followUpToday && 'موعد متابعتها اليوم',
    t.followUpMissed && 'تجاوزت موعد المتابعة',
    t.recentlyUpdated && 'محدثة حديثًا',
  ].filter(Boolean);
  return <div className="mt-2 flex flex-wrap gap-1">{labels.map(label =>
    <span key={String(label)} className="status-chip bg-[#f4ecd7] text-[#755c2e]">{label}</span>
  )}</div>;
}

export function FollowUpTable({ transactions }: { transactions: Transaction[] }) {
  return <div className="table-scroll"><table className="w-full text-right">
    <thead className="bg-[#f8f6f0] text-[10px] font-bold text-[#7e8981]"><tr>
      {['رقم المعاملة','الموضوع','الموظف المسؤول','الجهة الحالية','الحالة والتصنيف','آخر تحديث','الأيام منذ آخر تحديث','موعد المتابعة القادمة',''].map(column =>
        <th key={column} className="whitespace-nowrap px-4 py-3">{column}</th>)}
    </tr></thead>
    <tbody className="divide-y divide-[#eee9df]">{transactions.map(t =>
      <tr key={t.id} data-testid={`row-transaction-${t.id}`} className="hover:bg-[#faf8f2]">
        <td className="px-4 py-3 font-mono text-xs">{t.number}<div className="mt-1 font-sans text-[10px]">{t.type}</div></td>
        <td className="min-w-[180px] px-4 py-3"><div className="text-sm font-semibold">{t.subject}</div><div className="text-[10px] text-[#8b948d]">{t.departmentName}</div></td>
        <td className="px-4 py-3 text-xs">{t.employeeName}</td>
        <td className="px-4 py-3 text-xs">{t.currentEntity || '—'}</td>
        <td className="min-w-[160px] px-4 py-3"><span className="status-chip bg-[#e7eee7] text-[#3b705d]">{t.status}</span><FollowUpTags transaction={t}/></td>
        <td className="whitespace-nowrap px-4 py-3 text-xs">{date(t.lastUpdatedAt ?? t.createdAt)}</td>
        <td className="px-4 py-3 text-center font-mono text-sm">{t.daysSinceUpdate}</td>
        <td className="whitespace-nowrap px-4 py-3 text-xs">{date(t.nextFollowUpAt)}</td>
        <td className="px-4 py-3"><Link href={`/transactions/${t.id}`} className="text-xs font-bold text-[#1d5a4d]">فتح ←</Link></td>
      </tr>)}</tbody>
  </table></div>;
}
