import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getGetProductionCleanupPreviewQueryKey,
  executeProductionCleanup,
  useGetProductionCleanupPreview,
  type ProductionCleanupInput,
  type ProductionCleanupCounts,
} from "@workspace/api-client-react";
import { AlertTriangle, CheckCircle2, LoaderCircle, ShieldCheck, Trash2 } from "lucide-react";

const CONFIRMATION = "حذف نهائي";

const countLabels: Array<[keyof ProductionCleanupCounts, string]> = [
  ["accountsToDelete", "حسابات إضافية"],
  ["employeeAccountsToDelete", "حسابات موظفين"],
  ["additionalSupervisorsToDelete", "حسابات مشرفين إضافية"],
  ["employeesToDelete", "سجلات الموظفين"],
  ["transactionsToDelete", "المعاملات"],
  ["updatesToDelete", "تحديثات المعاملات"],
  ["attachmentsToDelete", "سجلات المرفقات"],
  ["storageFilesToDelete", "ملفات App Storage"],
  ["notificationsToDelete", "الإشعارات"],
  ["auditLogsToDelete", "سجلات التدقيق"],
  ["departmentsToPreserve", "الأقسام التي ستبقى"],
  ["settingsToPreserve", "إعدادات النظام التي ستبقى"],
];

export function ProductionCleanupPanel({ isPrimarySupervisor }: { isPrimarySupervisor: boolean }) {
  const isProductionBuild = import.meta.env.PROD;
  const preview = useGetProductionCleanupPreview({
    query: {
      queryKey: getGetProductionCleanupPreviewQueryKey(),
      enabled: isPrimarySupervisor && isProductionBuild,
      retry: false,
      refetchOnWindowFocus: false,
    },
  });
  const queryClient = useQueryClient();
  const [confirmation, setConfirmation] = useState("");
  const [completed, setCompleted] = useState(false);
  const cleanup = useMutation({
    mutationFn: (input: ProductionCleanupInput) => executeProductionCleanup(input),
    onSuccess: async () => {
      setCompleted(true);
      await queryClient.invalidateQueries();
    },
  });

  if (!isPrimarySupervisor) return null;

  if (!isProductionBuild) {
    return (
      <section className="mt-5 rounded-2xl border border-[#e6d8b8] bg-[#fbf7eb] p-5 md:p-6" dir="rtl">
        <div className="flex items-start gap-3">
          <ShieldCheck className="mt-0.5 shrink-0 text-[#8b6c2e]" size={20} />
          <div>
            <h2 className="font-bold text-[#4c4738]">تنظيف بيانات Production</h2>
            <p className="mt-2 text-sm leading-6 text-[#70664f]">
              هذه المعاينة متصلة بقاعدة Development، لذلك لا تعرض أعداد Production ولا تتيح الحذف.
              ستظهر أداة Production في الموقع المنشور بعد نشر التحديث.
            </p>
          </div>
        </div>
      </section>
    );
  }

  const plan = preview.data;
  const counts = plan?.counts;
  const confirmed = confirmation === CONFIRMATION;

  return (
    <section className="mt-5 rounded-2xl border border-[#e5c6bb] bg-[#fffaf7] p-5 md:p-6" dir="rtl">
      <div className="flex items-start gap-3">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#f8e9e4] text-[#963d31]">
          <Trash2 size={18} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-semibold uppercase tracking-wide text-[#9b6257]">أداة للمشرف الرئيس فقط</p>
          <h2 className="mt-1 text-lg font-bold text-[#492d28]">تنظيف البيانات التجريبية</h2>
          <p className="mt-2 text-sm leading-6 text-[#725a54]">
            هذه الأداة تعمل على قاعدة Production للموقع المنشور فقط. تعرض الأعداد أولًا، ولا يبدأ الحذف عند فتح الصفحة أو نشر التحديث.
          </p>
        </div>
      </div>

      <div className="mt-4 flex gap-3 rounded-xl border border-[#e8d6a7] bg-[#fff6de] p-3 text-xs leading-5 text-[#6d5a2f]">
        <AlertTriangle className="mt-0.5 shrink-0" size={16} />
        <p>
          الحذف نهائي. سيبقى حساب المشرف الرئيس والأقسام والإعدادات، ولن تُحذف هويات Clerk الخارجية.
          الأداة لا تتحقق من وجود نسخة احتياطية ولا توفر تراجعًا. راجع الأعداد أدناه؛ سيُطلب منك
          كتابة «حذف نهائي» ثم الضغط على زر التنفيذ.
        </p>
      </div>

      {preview.isLoading && (
        <p className="mt-5 inline-flex items-center gap-2 text-sm text-[#68756d]">
          <LoaderCircle className="animate-spin" size={16} /> جارٍ قراءة الأعداد والتحقق من المرفقات…
        </p>
      )}
      {preview.isError && (
        <div className="mt-5 rounded-xl bg-[#f8e9e4] p-4 text-sm text-[#8b3329]">
          تعذر تحميل ملخص Production. لم يُنفّذ أي حذف.
          <button onClick={() => preview.refetch()} className="mr-3 font-bold underline">إعادة المحاولة</button>
        </div>
      )}
      {plan && (
        <>
          <div className="mt-5 grid gap-2 sm:grid-cols-2">
            {countLabels.map(([key, label]) => (
              <div key={key} className="flex items-center justify-between rounded-xl border border-[#eee4dc] bg-white px-3 py-2.5 text-sm">
                <span className="text-[#655a55]">{label}</span>
                <strong className="font-mono text-[#342b28]">{counts?.[key] ?? 0}</strong>
              </div>
            ))}
            <div className="flex items-center justify-between rounded-xl border border-[#eee4dc] bg-white px-3 py-2.5 text-sm sm:col-span-2">
              <span className="text-[#655a55]">ملفات التخزين التي تم التحقق منها</span>
              <strong className="font-mono text-[#342b28]">{plan.storageObjectsVerified} / {plan.storageObjectsTotal}</strong>
            </div>
          </div>

          <p className={`mt-3 rounded-xl p-3 text-xs leading-5 ${plan.canExecute ? "bg-[#edf3ed] text-[#45634f]" : "bg-[#fff1e8] text-[#874a32]"}`}>
            {plan.message}
          </p>

          {cleanup.data?.databaseCommitted && (
            <div className={`mt-4 rounded-xl p-4 text-sm leading-6 ${cleanup.data.storagePending ? "bg-[#fff1e8] text-[#874a32]" : "bg-[#edf3ed] text-[#45634f]"}`}>
              <div className="flex items-center gap-2 font-bold">
                <CheckCircle2 size={17} />
                {cleanup.data.storagePending
                  ? "اكتملت معاملة قاعدة البيانات، وبقيت ملفات تخزين تحتاج معالجة."
                  : "اكتملت إزالة البيانات والتحقق من ملفات التخزين."}
              </div>
              <p className="mt-1">ملفات أزيلت: {cleanup.data.storageDeleted} — ملفات معلّقة: {cleanup.data.storagePending}</p>
              {cleanup.data.pendingStorageObjects.map((item) => (
                <p key={`${item.attachmentIds.join(",")}:${item.objectPath}`} className="mt-2 break-all font-mono text-xs" dir="ltr">
                  سجلات المرفقات {item.attachmentIds.join("، ")}: {item.objectPath}
                </p>
              ))}
            </div>
          )}
          {cleanup.isError && (
            <p className="mt-4 rounded-xl bg-[#f8e9e4] p-3 text-sm text-[#8b3329]">
              تعذر تأكيد اكتمال العملية. أعد تحميل الملخص قبل أي محاولة أخرى.
            </p>
          )}

          {!completed && (
            <div className="mt-5 border-t border-[#eee4dc] pt-5">
              <label className="block text-sm font-semibold text-[#4f413c]" htmlFor="production-cleanup-confirmation">
                للتأكيد، اكتب «حذف نهائي» كما هي:
              </label>
              <input
                id="production-cleanup-confirmation"
                autoComplete="off"
                className="field mt-2 max-w-md"
                value={confirmation}
                onChange={(event) => setConfirmation(event.target.value)}
                placeholder="حذف نهائي"
                disabled={!plan.canExecute || cleanup.isPending}
              />
              <button
                type="button"
                disabled={!plan.canExecute || !confirmed || cleanup.isPending}
                onClick={() => cleanup.mutate({ confirmation: CONFIRMATION, fingerprint: plan.fingerprint })}
                className="mt-3 inline-flex items-center gap-2 rounded-xl bg-[#973f32] px-4 py-2.5 text-sm font-bold text-white transition hover:bg-[#7d342a] disabled:cursor-not-allowed disabled:opacity-45"
              >
                {cleanup.isPending ? <LoaderCircle className="animate-spin" size={16} /> : <Trash2 size={16} />}
                تنفيذ التنظيف النهائي
              </button>
              <button
                type="button"
                onClick={() => { setConfirmation(""); void preview.refetch(); }}
                disabled={cleanup.isPending}
                className="mr-3 mt-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-[#655a55] underline disabled:opacity-50"
              >
                إعادة قراءة الأعداد
              </button>
            </div>
          )}
        </>
      )}
    </section>
  );
}
