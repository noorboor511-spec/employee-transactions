import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Building2, Check, Pencil, Plus, Trash2, X } from "lucide-react";
import {
  getGetDepartmentsQueryKey,
  useCreateDepartment,
  useDeleteDepartment,
  useGetDepartments,
  useUpdateDepartment,
} from "@workspace/api-client-react";

type Notice = { kind: "success" | "error"; text: string };

function apiErrorMessage(error: unknown, fallback: string): string {
  if (typeof error !== "object" || error === null || !("data" in error)) return fallback;
  const data = error.data;
  if (typeof data === "object" && data !== null && "error" in data && typeof data.error === "string") {
    return data.error;
  }
  return fallback;
}

export function DepartmentManagement() {
  const client = useQueryClient();
  const departments = useGetDepartments();
  const createDepartment = useCreateDepartment();
  const updateDepartment = useUpdateDepartment();
  const deleteDepartment = useDeleteDepartment();
  const [newName, setNewName] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingName, setEditingName] = useState("");
  const [notice, setNotice] = useState<Notice | null>(null);

  const refreshDepartmentData = async () => {
    await client.invalidateQueries();
    await client.invalidateQueries({ queryKey: getGetDepartmentsQueryKey() });
  };

  const addDepartment = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setNotice(null);
    createDepartment.mutate(
      { data: { name: newName } },
      {
        onSuccess: async () => {
          await refreshDepartmentData();
          setNewName("");
          setNotice({ kind: "success", text: "تمت إضافة الإدارة." });
        },
        onError: (error) => setNotice({
          kind: "error",
          text: apiErrorMessage(error, "تعذرت إضافة الإدارة. أعد المحاولة."),
        }),
      },
    );
  };

  const saveDepartmentName = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (editingId === null) return;
    setNotice(null);
    updateDepartment.mutate(
      { id: editingId, data: { name: editingName } },
      {
        onSuccess: async () => {
          await refreshDepartmentData();
          setEditingId(null);
          setEditingName("");
          setNotice({ kind: "success", text: "تم تعديل اسم الإدارة دون تغيير ارتباطاتها." });
        },
        onError: (error) => setNotice({
          kind: "error",
          text: apiErrorMessage(error, "تعذر تعديل اسم الإدارة. أعد المحاولة."),
        }),
      },
    );
  };

  const removeDepartment = (id: number, name: string) => {
    if (!window.confirm(`هل تريد حذف إدارة «${name}»؟ لن يتم حذف أي موظف أو معاملة.`)) return;
    setNotice(null);
    deleteDepartment.mutate(
      { id },
      {
        onSuccess: async () => {
          await refreshDepartmentData();
          setNotice({ kind: "success", text: "تم حذف الإدارة." });
        },
        onError: (error) => setNotice({
          kind: "error",
          text: apiErrorMessage(error, "تعذر حذف الإدارة. أعد المحاولة."),
        }),
      },
    );
  };

  if (departments.isLoading) {
    return <div className="panel rounded-2xl p-6 text-sm text-[#718078]" role="status">جارٍ تحميل الإدارات…</div>;
  }
  if (departments.isError) {
    return <div className="panel rounded-2xl p-6" role="alert">
      <p className="text-sm text-[#a04437]">تعذر تحميل الإدارات.</p>
      <button type="button" onClick={() => void departments.refetch()} className="btn-quiet mt-3 rounded-lg px-3 py-2 text-xs font-bold">إعادة المحاولة</button>
    </div>;
  }

  const list = departments.data ?? [];
  const saving = createDepartment.isPending || updateDepartment.isPending || deleteDepartment.isPending;

  return <div className="fade-up space-y-5" dir="rtl">
    <header>
      <p className="text-xs font-bold tracking-widest text-[#92743b]">إدارة النظام</p>
      <h1 className="mt-2 text-2xl font-bold text-[#203b35]">إدارة الإدارات</h1>
      <p className="mt-2 text-sm leading-6 text-[#718078]">أضف الإدارات أو غيّر أسماءها. لا يمكن حذف إدارة مرتبطة بموظفين أو معاملات.</p>
    </header>

    <section className="panel rounded-2xl p-5 md:p-6">
      <h2 className="mb-4 flex items-center gap-2 font-bold text-[#203b35]"><Building2 size={18} className="text-[#1d5a4d}"/> إضافة إدارة</h2>
      <form onSubmit={addDepartment} className="flex flex-col gap-3 sm:flex-row">
        <label className="sr-only" htmlFor="new-department-name">اسم الإدارة الجديدة</label>
        <input
          id="new-department-name"
          className="field flex-1"
          maxLength={120}
          value={newName}
          onChange={(event) => setNewName(event.target.value)}
          placeholder="اكتب اسم الإدارة"
          required
          data-testid="input-new-department-name"
        />
        <button
          type="submit"
          disabled={saving || !newName.trim()}
          className="btn-primary inline-flex items-center justify-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold disabled:opacity-50"
          data-testid="button-add-department"
        ><Plus size={16}/> إضافة الإدارة</button>
      </form>
    </section>

    <section className="panel overflow-hidden rounded-2xl">
      <div className="flex items-center justify-between border-b border-[#e9e4da] px-5 py-4">
        <div><h2 className="font-bold text-[#203b35]">الإدارات الحالية</h2><p className="mt-1 text-xs text-[#7b857e]">{list.length} إدارة</p></div>
        <Building2 size={18} className="text-[#718078]"/>
      </div>
      {notice && <p className={`mx-5 mt-4 rounded-xl px-4 py-3 text-sm ${notice.kind === "error" ? "bg-[#fbefeb] text-[#a04437]" : "bg-[#e5f1e9] text-[#286149]"}`} role={notice.kind === "error" ? "alert" : "status"}>{notice.text}</p>}
      {list.length ? <ul className="divide-y divide-[#eee9df]">
        {list.map((department) => <li key={department.id} className="flex flex-wrap items-center gap-3 px-5 py-4" data-testid={`row-department-${department.id}`}>
          {editingId === department.id ? <form onSubmit={saveDepartmentName} className="flex min-w-0 flex-1 flex-wrap items-center gap-2">
            <label className="sr-only" htmlFor={`edit-department-${department.id}`}>اسم الإدارة</label>
            <input
              id={`edit-department-${department.id}`}
              className="field min-w-[180px] flex-1"
              maxLength={120}
              value={editingName}
              onChange={(event) => setEditingName(event.target.value)}
              required
              autoFocus
              data-testid={`input-edit-department-${department.id}`}
            />
            <button type="submit" disabled={saving || !editingName.trim()} className="btn-primary inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold disabled:opacity-50" data-testid={`button-save-department-${department.id}`}><Check size={14}/> حفظ</button>
            <button type="button" disabled={saving} onClick={() => { setEditingId(null); setEditingName(""); }} className="btn-quiet inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold" data-testid={`button-cancel-department-${department.id}`}><X size={14}/> إلغاء</button>
          </form> : <>
            <span className="min-w-0 flex-1 font-semibold text-[#203b35]" data-testid={`department-name-${department.id}`}>{department.name}</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={saving}
                onClick={() => { setNotice(null); setEditingId(department.id); setEditingName(department.name); }}
                className="btn-quiet inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold"
                data-testid={`button-edit-department-${department.id}`}
              ><Pencil size={14}/> تعديل</button>
              <button
                type="button"
                disabled={saving}
                onClick={() => removeDepartment(department.id, department.name)}
                className="inline-flex items-center gap-2 rounded-lg border border-[#ead4ce] px-3 py-2 text-xs font-bold text-[#a04437] hover:bg-[#fbefeb] disabled:opacity-50"
                data-testid={`button-delete-department-${department.id}`}
              ><Trash2 size={14}/> حذف</button>
            </div>
          </>}
        </li>)}
      </ul> : <p className="px-5 py-8 text-sm text-[#718078]">لا توجد إدارات لعرضها.</p>}
    </section>
  </div>;
}
