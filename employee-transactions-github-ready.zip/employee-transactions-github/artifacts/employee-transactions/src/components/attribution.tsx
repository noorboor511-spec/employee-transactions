import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { getGetBrandingQueryKey, useGetBranding, useGetCurrentUser, useUpdateBranding } from '@workspace/api-client-react';

export function AttributionFooter() {
  const query = useGetBranding();
  if (!query.data?.footerCredit) return null;
  return <footer dir="rtl" className="border-t border-[#e1dacc] bg-[#f6f3eb] px-4 py-3 text-center text-xs text-[#778078]" data-testid="footer-attribution">{query.data.footerCredit}</footer>;
}

export function AttributionSettings() {
  const user = useGetCurrentUser();
  const query = useGetBranding();
  const update = useUpdateBranding();
  const client = useQueryClient();
  const [draft, setDraft] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const value = draft ?? query.data?.footerCredit ?? '';

  if (user.data?.canEditFooterCredit !== true) return null;

  const save = (footerCredit: string) => {
    setMessage('');
    setError('');
    update.mutate({ data: { footerCredit } }, {
      onSuccess: async data => {
        client.setQueryData(getGetBrandingQueryKey(), data);
        setDraft(null);
        setMessage(data.footerCredit ? 'تم حفظ عبارة التوثيق.' : 'تم حذف عبارة التوثيق من صفحات النظام.');
        await client.invalidateQueries({ queryKey: getGetBrandingQueryKey() });
      },
      onError: () => setError('تعذر حفظ عبارة التوثيق. أعد المحاولة.'),
    });
  };

  return <section className="panel mt-5 rounded-2xl p-5 md:p-6">
    <h2 className="font-bold">عبارة التوثيق أسفل الصفحات</h2>
    <p className="mt-2 text-xs leading-6 text-[#7b857e]">يمكن للمشرف الرئيس وحده تعديل العبارة أو حذفها في أي وقت. حذفها لا يؤثر على النظام أو بياناته.</p>
    {query.isLoading ? <p className="mt-3 text-xs">جارٍ التحميل…</p> : query.isError ? <div className="mt-3 text-sm text-[#a04437]" role="alert">تعذر تحميل العبارة. <button type="button" className="underline" onClick={() => query.refetch()}>إعادة المحاولة</button></div> :
      <form className="mt-4 space-y-3" onSubmit={e => { e.preventDefault(); save(value); }}>
        <label className="block text-xs font-bold">النص<input className="field mt-2" maxLength={200} value={value} onChange={e => setDraft(e.target.value)} data-testid="input-footer-credit"/></label>
        <div className="flex flex-wrap gap-2">
          <button disabled={update.isPending} className="btn-primary rounded-xl px-4 py-2 text-sm font-bold" data-testid="button-save-footer-credit">{update.isPending ? 'جارٍ الحفظ…' : 'حفظ العبارة'}</button>
          <button type="button" disabled={update.isPending || !query.data?.footerCredit} onClick={() => { if (window.confirm('هل تريد حذف عبارة التوثيق من جميع صفحات النظام؟')) save(''); }} className="btn-quiet rounded-xl px-4 py-2 text-sm font-bold text-[#a04437]" data-testid="button-remove-footer-credit">حذف عبارة التوثيق</button>
        </div>
      </form>}
    {message && <p className="mt-3 text-sm text-[#286149]" role="status">{message}</p>}
    {error && <p className="mt-3 text-sm text-[#a04437]" role="alert">{error}</p>}
  </section>;
}
