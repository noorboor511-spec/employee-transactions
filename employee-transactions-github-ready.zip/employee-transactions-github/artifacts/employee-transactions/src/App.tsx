import { useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  ClerkProvider, SignIn, SignUp, Show, useClerk,
} from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import * as XLSX from 'xlsx';
import {
  Activity, Archive, ArrowDownLeft, ArrowLeft, Bell, Building2, CalendarDays,
  Check, CheckCheck, CircleAlert, ClipboardList, Clock3, Download,
  File, FilePlus2, Filter, LayoutDashboard, LogOut, Menu, Paperclip, Plus,
  Search, Settings2, ShieldCheck, Users, X,
} from 'lucide-react';
import {
  getGetDashboardQueryKey, getGetStorageObjectQueryKey,
  getGetEmployeesQueryKey, getGetNotificationsQueryKey, getGetReportsQueryKey,
  getGetSettingsQueryKey, getGetTransactionQueryKey, getGetTransactionsQueryKey,
  useAddTransactionUpdate, useCreateEmployee, useCreateTransaction, useGetCurrentUser,
  useGetDashboard, useGetDepartments, useGetEmployees, useGetNotifications,
  useGetReports, useGetSettings, useGetStorageObject, useGetTransaction, useGetTransactions,
  getHealthCheckQueryKey, useHealthCheck,
  useMarkNotificationRead, useRequestUploadUrl, useUpdateEmployee, useUpdateSettings,
  useUpdateTransaction,
} from '@workspace/api-client-react';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';
import './index.css';
import { FollowUpTable } from './components/follow-up-table';
import { SupervisorManagement } from './components/supervisor-management';
import { AttributionFooter, AttributionSettings } from './components/attribution';
import { ProductionCleanupPanel } from './components/production-cleanup-panel';
import { DepartmentManagement } from './components/department-management';

const queryClient = new QueryClient({ defaultOptions: { queries: {
  staleTime: 30_000, refetchInterval: 60_000, refetchOnWindowFocus: true,
} } });
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg?brand=tabie`,
  },
  variables: {
    colorPrimary: '#1d5a4d',
    colorForeground: '#203b35',
    colorMutedForeground: '#65736d',
    colorDanger: '#aa3f36',
    colorBackground: '#fffdf8',
    colorInput: '#fffdf8',
    colorInputForeground: '#203b35',
    colorNeutral: '#ded8cb',
    fontFamily: "'IBM Plex Sans Arabic', sans-serif",
    borderRadius: '12px',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fffdf8] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#e7e1d5]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#203b35] font-bold',
    headerSubtitle: 'text-[#65736d]',
    socialButtonsBlockButtonText: 'text-[#203b35]',
    formFieldLabel: 'text-[#31413a]',
    footerActionLink: 'text-[#1d5a4d]',
    footerActionText: 'text-[#65736d]',
    dividerText: 'text-[#65736d]',
    identityPreviewEditButton: 'text-[#1d5a4d]',
    formFieldSuccessText: 'text-[#1d5a4d]',
    alertText: 'text-[#8e332b]',
    logoBox: 'mb-2',
    logoImage: 'max-h-12',
    socialButtonsBlockButton: 'border-[#ded8cb] bg-[#fffdf8]',
    formButtonPrimary: 'bg-[#1d5a4d] hover:bg-[#17483e]',
    formFieldInput: 'border-[#ded8cb] bg-[#fffdf8] text-[#203b35]',
    footerAction: 'text-[#65736d]',
    dividerLine: 'bg-[#e7e1d5]',
    alert: 'bg-[#fbefeb]',
    otpCodeFieldInput: 'border-[#ded8cb] bg-[#fffdf8] text-[#203b35]',
    formFieldRow: 'text-[#203b35]',
    main: 'text-[#203b35]',
  },
};

const fmtDate = (value?: string | null) => value ? new Date(value).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric' }) : '—';
const fmtDateTime = (value?: string | null) => value ? new Date(value).toLocaleString('ar-SA', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const riyadhToday = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Riyadh' }).format(new Date());
const dateInputToIso = (value: string, time: string) => {
  if (!value) return null;
  const parsed = new Date(`${value}T${time}+03:00`);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
};
const statusTone = (status: string) => /مكتمل|منجز|completed|done/i.test(status) ? 'bg-[#e5f1e9] text-[#286149]' : /جديد|new/i.test(status) ? 'bg-[#e9eef4] text-[#466381]' : /متأخر|urgent|عاجل/i.test(status) ? 'bg-[#f8e9e4] text-[#a04437]' : 'bg-[#f5edda] text-[#826222]';
const priorityLabel = (priority: string) => ({ urgent: 'عاجل', important: 'مهم', normal: 'عادي' }[priority] || priority);

function BrandMark({ compact = false }: { compact?: boolean }) {
  return <div className="flex items-center gap-3" dir="rtl">
    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#c69a4a] text-[#173b35]"><Archive size={20} strokeWidth={2.2} /></div>
    {!compact && <div className="leading-tight"><strong className="block text-[14px]">تابع</strong><span className="text-[10px] opacity-65">متابعة المعاملات</span></div>}
  </div>;
}

function Home() {
  return <div className="min-h-[100dvh] bg-[#f6f3eb] px-5 text-[#203b35]" dir="rtl">
    <header className="mx-auto flex max-w-7xl items-center justify-between py-6">
      <BrandMark />
      <div className="flex gap-2">
        <Link href="/sign-in" className="rounded-xl px-4 py-2.5 text-sm font-semibold hover:bg-[#eae6dc]">تسجيل الدخول</Link>
        <Link href="/sign-up" className="rounded-xl bg-[#1d5a4d] px-4 py-2.5 text-sm font-semibold text-[#fffdf8] hover:bg-[#17483e]">إنشاء حساب</Link>
      </div>
    </header>
    <main className="mx-auto max-w-7xl pb-16">
      <section className="relative mt-6 overflow-hidden rounded-[28px] bg-[#173b35] px-7 py-12 text-[#f4f0e5] md:px-14 md:py-16">
        <div className="absolute -left-24 -top-28 h-96 w-96 rounded-full border border-white/10" />
        <div className="absolute -left-12 -top-16 h-72 w-72 rounded-full border border-white/10" />
        <div className="relative max-w-2xl">
          <div className="mb-5 flex items-center gap-2 text-xs font-semibold tracking-wide text-[#d5b673]"><ShieldCheck size={16} /> نظام يومي واضح، بلا مطاردة</div>
          <h1 className="max-w-xl text-4xl font-bold leading-[1.35] md:text-6xl">كل معاملة تعرف <span className="text-[#d6b56e]">خطوتها التالية.</span></h1>
          <p className="mt-5 max-w-xl text-base leading-8 text-[#d7e0d7] md:text-lg">لوحة عمل دقيقة للمشرف والموظف: ما الذي وصل، ما الذي يحتاج متابعة، ومن يملك الإجراء التالي.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/sign-in" className="inline-flex items-center gap-2 rounded-xl bg-[#e2bd70] px-5 py-3 font-bold text-[#203b35] hover:bg-[#edca80]">الدخول إلى النظام <ArrowLeft size={17} /></Link>
            <Link href="/sign-up" className="inline-flex items-center rounded-xl border border-white/25 px-5 py-3 font-semibold hover:bg-white/10">إنشاء حساب موظف</Link>
          </div>
        </div>
        <div className="relative mt-12 grid max-w-2xl grid-cols-3 gap-3 md:absolute md:bottom-12 md:left-12 md:mt-0 md:w-[41%]">
          {[['01', 'استلام واضح'], ['02', 'متابعة بموعد'], ['03', 'سجل موثق']].map(([n, label]) => <div key={n} className="rounded-2xl border border-white/15 bg-white/[.06] p-4 backdrop-blur-sm"><span className="font-mono text-xs text-[#d6b56e]">{n}</span><p className="mt-2 text-sm font-semibold">{label}</p></div>)}
        </div>
      </section>
      <section className="grid gap-5 py-12 md:grid-cols-[1.1fr_.9fr] md:py-16">
        <div className="py-4">
          <p className="text-xs font-bold tracking-widest text-[#92743b]">منضدة العمل اليومية</p>
          <h2 className="mt-3 text-3xl font-bold leading-relaxed">المعلومة المهمة في مكانها، والقرار أقرب.</h2>
          <p className="mt-3 max-w-xl leading-8 text-[#68736c]">بدلاً من الرسائل المتفرقة، اجعل رقم المعاملة وحالتها والمسؤول عنها وموعد مراجعتها في سجل واحد يمكن الرجوع إليه.</p>
        </div>
        <div className="panel rounded-2xl p-5">
          <div className="flex items-center justify-between border-b border-[#e7e1d5] pb-4"><div><span className="text-xs text-[#7a847e]">مؤشر المتابعة</span><div className="mt-1 text-xl font-bold">قائمة اليوم</div></div><span className="rounded-full bg-[#f7ead0] px-3 py-1 text-xs font-semibold text-[#826222]">تستحق إجراء</span></div>
          {[['٤٢٨١ / ١٤٤٦', 'اعتماد طلب صرف مستحقات', 'اليوم'], ['٤٢٧٦ / ١٤٤٦', 'تحديث بيانات الموظف', 'منذ يومين'], ['٤٢٦٤ / ١٤٤٦', 'إحالة طلب إجازة', 'بانتظار الرد']].map(([id, subject, state]) => <div key={id} className="flex items-center justify-between gap-3 border-b border-[#eee9df] py-4 last:border-0"><div><div className="font-mono text-[11px] text-[#718078]">{id}</div><div className="mt-1 text-sm font-semibold">{subject}</div></div><span className="text-xs text-[#8e6b2c]">{state}</span></div>)}
        </div>
      </section>
      <section className="grid gap-4 border-t border-[#e1dacc] py-9 md:grid-cols-3">
        {[[ClipboardList, 'سجل المعاملة', 'حالة ومسؤول وموعد متابعة في عرض واحد.'], [Activity, 'تاريخ لا يتغير', 'كل تحديث موثق باسم صاحبه ووقته.'], [Users, 'عبء موزع بوضوح', 'يرى المشرف الصورة الكاملة، ويرى الموظف ما يخصه.']].map(([Icon, title, body]) => <article key={String(title)} className="rounded-xl px-2 py-4"><Icon size={21} className="text-[#1d5a4d]" /><h3 className="mt-4 font-bold">{String(title)}</h3><p className="mt-2 text-sm leading-7 text-[#69756e]">{String(body)}</p></article>)}
      </section>
      <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-[#e1dacc] pt-5 text-xs text-[#778078]"><span>تابع · متابعة معاملات الموظفين</span><span>مساحة عمل داخلية منظمة</span></footer>
    </main>
  </div>;
}

function HomeRedirect() {
  return <><Show when="signed-in"><Redirect to="/dashboard" /></Show><Show when="signed-out"><Home /></Show></>;
}
function SignInPage() { return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f6f3eb] px-4 py-8" dir="rtl"><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} forceRedirectUrl={`${basePath}/dashboard`} /></div>; }
function SignUpPage() { return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f6f3eb] px-4 py-8" dir="rtl"><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} forceRedirectUrl={`${basePath}/dashboard`} /></div>; }

function ClerkProviderRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}
    localization={{
      signIn: { start: { title: 'مرحباً بعودتك', subtitle: 'سجّل الدخول لمتابعة معاملاتك', actionText: 'ليس لديك حساب؟', actionLink: 'إنشاء حساب' }, password: { title: 'أدخل كلمة المرور', subtitle: 'أدخل كلمة مرور حسابك للمتابعة' }, forgotPassword: { title: 'استعادة كلمة المرور', subtitle: 'سنرسل إليك تعليمات إعادة التعيين' } },
      signUp: { start: { title: 'إنشاء حسابك', subtitle: 'أنشئ حسابك للوصول إلى مساحة العمل', actionText: 'لديك حساب بالفعل؟', actionLink: 'تسجيل الدخول' } },
      formFieldLabel__emailAddress: 'البريد الإلكتروني',
      formFieldLabel__password: 'كلمة المرور',
      formFieldLabel__firstName: 'الاسم الأول',
      formFieldLabel__lastName: 'اسم العائلة',
      formButtonPrimary__signIn: 'تسجيل الدخول',
      formButtonPrimary__signUp: 'إنشاء الحساب',
      socialButtonsBlockButton: 'المتابعة باستخدام {{provider}}',
      dividerText: 'أو',
      footerActionText: 'لديك حساب؟',
      footerActionLink: 'تسجيل الدخول',
      backButton: 'رجوع',
    } as never}
    routerPush={(to) => setLocation(basePath && to.startsWith(basePath) ? to.slice(basePath.length) || '/' : to)}
    routerReplace={(to) => setLocation(basePath && to.startsWith(basePath) ? to.slice(basePath.length) || '/' : to, { replace: true })}>
    <QueryClientProvider client={queryClient}>
      <div className="noise" />
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route path="/dashboard"><Protected><DashboardPage /></Protected></Route>
        <Route path="/transactions"><Protected><TransactionsPage /></Protected></Route>
        <Route path="/transactions/:id"><Protected><TransactionPage /></Protected></Route>
        <Route path="/employees"><Protected supervisor><EmployeesPage /></Protected></Route>
        <Route path="/departments"><Protected primarySupervisor><DepartmentManagement /></Protected></Route>
        <Route path="/reports"><Protected supervisor><ReportsPage /></Protected></Route>
        <Route path="/settings"><Protected supervisor><SettingsPage /></Protected></Route>
        <Route path="/notifications"><Protected><NotificationsPage /></Protected></Route>
        <Route><NotFoundPage /></Route>
      </Switch>
      <AttributionFooter/>
    </QueryClientProvider>
  </ClerkProvider>;
}

function Protected({ children, supervisor = false, primarySupervisor = false }: { children: React.ReactNode; supervisor?: boolean; primarySupervisor?: boolean }) {
  const [location] = useLocation();
  const user = useGetCurrentUser();
  const { signOut } = useClerk();
  return <><Show when="signed-out"><Redirect to="/sign-in" /></Show><Show when="signed-in"><>{user.isLoading ? <LoadingPage /> : user.isError ? user.error.status === 403 ? <AccountAccessDenied error={user.error} onSignOut={() => signOut({ redirectUrl: basePath || '/' })}/> : <ErrorPage onRetry={() => user.refetch()} /> : user.data ? <Shell user={user.data} onSignOut={() => signOut({ redirectUrl: basePath || '/' })}>
    {supervisor && user.data.role !== 'supervisor' ? <AccessDenied /> : primarySupervisor && user.data.canEditFooterCredit !== true ? <AccessDenied /> : children}
  </Shell> : <Redirect to="/" />}</></Show></>;
}

function Shell({ user, children, onSignOut }: { user: {name:string;email:string;role:string;departmentName?:string|null;canEditFooterCredit?:boolean}; children: React.ReactNode; onSignOut: () => void }) {
  const [loc] = useLocation();
  const [mobileMenu, setMobileMenu] = useState(false);
  const { data: notifications = [] } = useGetNotifications();
  const unread = notifications.filter((item) => !item.readAt).length;
  const links = [
    { href: '/dashboard', label: 'لوحة المتابعة', icon: LayoutDashboard },
    { href: '/transactions', label: 'المعاملات', icon: ClipboardList },
    ...(user.role === 'supervisor' ? [{ href: '/employees', label: 'الموظفون', icon: Users }, { href: '/reports', label: 'التقارير', icon: Activity }, { href: '/settings', label: 'الإعدادات', icon: Settings2 }] : []),
    ...(user.role === 'supervisor' && user.canEditFooterCredit ? [{ href: '/departments', label: 'إدارة الإدارات', icon: Building2 }] : []),
    { href: '/notifications', label: 'التنبيهات', icon: Bell },
  ];
  return <div className="app-shell flex" dir="rtl">
    <aside className={`sidebar fixed inset-y-0 right-0 z-40 flex w-[258px] flex-col px-4 py-5 transition-transform md:sticky md:top-0 md:h-[100dvh] md:translate-x-0 ${mobileMenu ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}`}>
      <div className="flex items-center justify-between px-2 pb-8"><BrandMark /><button className="rounded-lg p-2 md:hidden" aria-label="إغلاق القائمة" onClick={() => setMobileMenu(false)}><X size={18}/></button></div>
      <div className="mb-3 px-3 text-[10px] font-bold tracking-widest text-[#aabbb2]">مساحة العمل</div>
      <nav className="space-y-1">{links.map(({href,label,icon:Icon}) => <Link key={href} href={href} onClick={() => setMobileMenu(false)} className={`sidebar-link flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-semibold ${loc === href || (href === '/transactions' && loc.startsWith('/transactions/')) ? 'active' : 'text-[#d7e2da]'}`} data-testid={`link-nav-${href.slice(1)}`}><Icon size={17}/><span className="flex-1">{label}</span>{href === '/notifications' && unread > 0 && <b className="rounded-full bg-[#d9b96f] px-2 py-0.5 text-[10px] text-[#233c35]">{unread}</b>}</Link>)}</nav>
      <div className="mt-auto rounded-2xl border border-white/10 bg-white/[.05] p-4">
        <div className="mb-3 flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-full bg-[#d6b56e] font-bold text-[#173b35]">{user.name.trim().slice(0,1)}</div><div className="min-w-0"><div className="truncate text-sm font-semibold">{user.name}</div><div className="text-[10px] text-[#b7c5bd]">{user.role === 'supervisor' ? 'مشرف النظام' : user.departmentName || 'موظف'}</div></div></div>
        <button onClick={onSignOut} className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-xs text-[#d7e2da] hover:bg-white/10"><LogOut size={15}/> تسجيل الخروج</button>
      </div>
    </aside>
    {mobileMenu && <button aria-label="إغلاق القائمة" onClick={() => setMobileMenu(false)} className="fixed inset-0 z-30 bg-[#102a26]/50 md:hidden" />}
    <div className="main-content min-w-0 flex-1">
      <header className="sticky top-0 z-20 flex h-[68px] items-center justify-between border-b border-[#e6e0d5] bg-[#f6f3eb]/95 px-4 backdrop-blur md:px-8">
        <div className="flex items-center gap-3"><button className="rounded-lg p-2 hover:bg-[#eae6dc] md:hidden" onClick={() => setMobileMenu(true)} aria-label="فتح القائمة"><Menu size={19}/></button><div className="hidden text-xs text-[#737f77] sm:block">{new Intl.DateTimeFormat('ar-SA',{weekday:'long',day:'numeric',month:'long'}).format(new Date())}</div></div>
        <div className="flex items-center gap-3"><Link href="/notifications" className="relative rounded-xl p-2.5 text-[#43564d] hover:bg-[#eae6dc]" aria-label="التنبيهات"><Bell size={18}/>{unread > 0 && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#bc664b] ring-2 ring-[#f6f3eb]"/>}</Link><div className="hidden h-7 w-px bg-[#ded8cb] sm:block"/><div className="text-left"><div className="text-xs font-bold">{user.name}</div><div className="text-[10px] text-[#78837c]">{user.role === 'supervisor' ? 'إدارة ومتابعة' : 'مساحة الموظف'}</div></div></div>
      </header>
      <main className="mx-auto w-full max-w-[1500px] px-4 py-6 md:px-8 md:py-8">{children}</main>
    </div>
  </div>;
}

function PageTitle({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="mb-6 flex flex-wrap items-end justify-between gap-4 fade-up"><div>{eyebrow && <div className="mb-1 text-[10px] font-bold tracking-widest text-[#92743b]">{eyebrow}</div>}<h1 className="text-2xl font-bold tracking-tight md:text-[28px]">{title}</h1>{description && <p className="mt-1.5 text-sm text-[#748078]">{description}</p>}</div>{action}</div>;
}
function LoadingPage() {
  return (
    <main
      dir="rtl"
      role="status"
      aria-live="polite"
      aria-busy="true"
      className="flex min-h-[65vh] items-center justify-center px-5 py-10 text-center"
    >
      <div className="panel w-full max-w-md rounded-2xl p-8">
        <svg
          aria-hidden="true"
          className="mx-auto h-10 w-10 animate-spin text-[#1d5a4d]"
          viewBox="0 0 24 24"
          fill="none"
        >
          <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="3" className="opacity-20" />
          <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
        </svg>
        <h1 className="mt-5 text-lg font-bold text-[#263f35]">جارٍ تحميل البيانات</h1>
        <p className="mt-2 text-sm text-[#748078]">يرجى الانتظار قليلًا، نجهّز بيانات النظام.</p>
      </div>
    </main>
  );
}

function ErrorPage({onRetry}: {onRetry:()=>void}) {
  return (
    <section
      dir="rtl"
      role="alert"
      className="panel mx-auto mt-14 max-w-lg rounded-2xl p-8 text-center"
    >
      <CircleAlert className="mx-auto text-[#ad5142]" size={30} aria-hidden="true" />
      <h1 className="mt-3 text-lg font-bold">تعذر تحميل البيانات</h1>
      <p className="mt-2 text-sm text-[#748078]">
        تعذّر الاتصال بالخادم أو استرجاع البيانات. تحقّق من اتصالك ثم أعد المحاولة.
      </p>
      <button
        type="button"
        onClick={onRetry}
        className="btn-primary mt-5 rounded-xl px-4 py-2.5 text-sm font-bold"
      >
        إعادة المحاولة
      </button>
    </section>
  );
}

function AccountAccessDenied({error,onSignOut}: {error:{data?:unknown};onSignOut:()=>void}) {
  const data=error.data;
  const message=data&&typeof data==='object'&&'error' in data&&typeof data.error==='string'
    ? data.error : 'هذا الحساب غير مخوّل للدخول إلى النظام. تواصل مع المشرف الرئيس.';
  return <div role="alert" className="panel mx-auto mt-14 max-w-lg rounded-2xl p-8 text-center"><ShieldCheck className="mx-auto text-[#8f783f]" size={30}/><h2 className="mt-3 text-lg font-bold">لا توجد صلاحية للدخول</h2><p className="mt-2 text-sm text-[#748078]">{message}</p><button onClick={onSignOut} className="btn-primary mt-5 rounded-xl px-4 py-2.5 text-sm font-bold">تسجيل الخروج</button></div>;
}
function EmptyState({title, body, action}: {title:string;body:string;action?:React.ReactNode}) { return <div className="py-12 text-center"><div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[#edf0e8] text-[#527564]"><ClipboardList size={22}/></div><h3 className="mt-3 font-bold">{title}</h3><p className="mx-auto mt-1 max-w-sm text-sm leading-6 text-[#7a847e]">{body}</p>{action && <div className="mt-4">{action}</div>}</div>; }
function AccessDenied() { return <div className="panel rounded-2xl p-10 text-center"><ShieldCheck className="mx-auto text-[#8f783f]" size={30}/><h2 className="mt-3 font-bold">هذه الصفحة للمشرف</h2><p className="mt-2 text-sm text-[#778078]">يمكنك متابعة المعاملات المسندة إليك من مساحة الموظف.</p><Link href="/dashboard" className="btn-primary mt-5 inline-flex rounded-xl px-4 py-2.5 text-sm font-bold">العودة للوحة المتابعة</Link></div>; }

function StatCard({label,value,detail,icon:Icon,tone='green',href}: {label:string;value:number|string;detail:string;icon:typeof Activity;tone?:string;href?:string}) {
  const content = <div className="panel lift flex min-h-[116px] items-start justify-between rounded-2xl p-4 md:p-5"><div><div className="text-xs font-semibold text-[#748078]">{label}</div><div className="mt-2 font-mono text-3xl font-semibold leading-none text-[#203b35]">{value ?? 0}</div><div className="mt-2 text-[10px] text-[#879189]">{detail}</div></div><div className={`grid h-10 w-10 place-items-center rounded-xl ${tone === 'gold' ? 'bg-[#f5ecd7] text-[#8b6c2e]' : tone === 'red' ? 'bg-[#f8e9e4] text-[#a04437]' : 'bg-[#e5f0e8] text-[#2f6855]'}`}><Icon size={18}/></div></div>;
  return href ? <Link href={href} className="block">{content}</Link> : content;
}

function DashboardPage() {
  const query = useGetDashboard();
  const user = useGetCurrentUser();
  if (query.isLoading || user.isLoading) return <LoadingPage />;
  if (query.isError || !query.data) return <ErrorPage onRetry={() => query.refetch()} />;
  const d = query.data;
  const isSupervisor = user.data?.role === 'supervisor';
  return <div className="fade-up">
    <PageTitle eyebrow={isSupervisor ? 'نظرة الفريق' : 'مساحة عملي'} title={isSupervisor ? 'صباح العمل، هذه صورة اليوم.' : 'معاملاتك، من أول إجراء لآخر تحديث.'} description={isSupervisor ? 'ابدأ بما يحتاج انتباهك، ثم راجع آخر ما أُنجز.' : 'حدّث حالة معاملاتك وسجّل الخطوة التالية عند إنجازها.'} action={<Link href="/transactions" className="btn-primary inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold"><ClipboardList size={16}/> عرض المعاملات</Link>} />
     <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
       <StatCard label="إجمالي المعاملات" value={d.total} detail="في نطاق العرض الحالي" icon={ClipboardList} href="/transactions" />
       <StatCard label="جديدة" value={d.new} detail="لم يبدأ العمل عليها" icon={FilePlus2} href="/transactions?status=جديدة" />
       <StatCard label="تحت الإجراء" value={d.inProgress} detail="قيد المعالجة حالياً" icon={Activity} href="/transactions?inProgress=true" />
       <StatCard label="مكتملة" value={d.completed} detail="أُنجزت وأُغلقت" icon={CheckCheck} href="/transactions?status=مكتملة" />
       <StatCard label="متأخرة" value={d.overdue} detail="حالة تأخير أو موعد متابعة فائت" icon={CircleAlert} tone="red" href="/transactions?overdue=true" />
       <StatCard label="معاملات تحتاج متابعة" value={d.needsFollowUp} detail="لم تُحدّث خلال المدة المحددة" icon={Clock3} tone="gold" href="/transactions?needsFollowUp=true" />
       <StatCard label="موعد متابعتها اليوم" value={d.followUpToday} detail="بحسب توقيت الرياض" icon={CalendarDays} tone="gold" href="/transactions?followUpToday=true" />
       <StatCard label="تجاوزت موعد المتابعة" value={d.followUpMissed} detail="انقضى موعد المتابعة المحدد" icon={CircleAlert} tone="red" href="/transactions?followUpMissed=true" />
       <StatCard label="محدثة حديثًا" value={d.recentlyUpdated} detail="خلال آخر 24 ساعة" icon={Activity} href="/transactions?recentlyUpdated=true" />
    </div>
    {d.needsFollowUp > 0 && <Link href="/transactions?needsFollowUp=true" role="status" className="mb-5 block rounded-xl border border-[#dcc18a] bg-[#f8f2e4] p-4 text-sm font-semibold text-[#755c2e]">{isSupervisor ? `تنبيه: ${d.needsFollowUp} معاملات تحتاج متابعة` : `يرجى تحديث معاملاتك: ${d.needsFollowUp} معاملات تحتاج متابعة`} ←</Link>}
    {isSupervisor && <div className="mb-5 grid gap-4 md:grid-cols-[1.5fr_.8fr]">
      <div className="panel rounded-2xl p-5 md:p-6"><div className="flex items-center justify-between"><div><div className="text-xs font-semibold text-[#748078]">نقاط الانتباه</div><h2 className="mt-1 text-lg font-bold">العمل الذي يحتاج قراراً</h2></div><Link href="/employees" className="text-xs font-bold text-[#1d5a4d]">عبء الموظفين ←</Link></div>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-xl bg-[#f8f2e4] p-4"><div className="font-mono text-2xl font-semibold">{d.followUpToday}</div><div className="mt-1 text-xs text-[#75663f]">متابعة اليوم</div><div className="mt-3 h-1.5 overflow-hidden rounded-full bg-[#e8dcc0]"><div className="h-full rounded-full bg-[#c69a4a]" style={{width:`${Math.min(100, (d.followUpToday / Math.max(1,d.total))*100)}%`}}/></div></div>
          <div className="rounded-xl bg-[#f8eae5] p-4"><div className="font-mono text-2xl font-semibold">{d.overdue}</div><div className="mt-1 text-xs text-[#895349]">تحتاج متابعة متأخرة</div><div className="mt-3 h-1.5 overflow-hidden rounded-full bg-[#ead5cf]"><div className="h-full rounded-full bg-[#b45a46]" style={{width:`${Math.min(100, (d.overdue / Math.max(1,d.total))*100)}%`}}/></div></div>
        </div>
      </div>
       <div className="rounded-2xl bg-[#dfe9df] p-5"><div className="flex items-start justify-between"><div><div className="text-xs font-bold text-[#526b5b]">معاملات لها تحديث</div><div className="mt-2 text-3xl font-semibold text-[#203b35]">{d.updates}</div></div><Activity className="text-[#3c735e]" size={21}/></div><p className="mt-4 text-xs leading-6 text-[#607467]">عدد المعاملات التي سُجل عليها تحديث واحد على الأقل.</p></div>
    </div>}
    <div className="panel rounded-2xl">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#e9e4da] px-5 py-4"><div><h2 className="font-bold">آخر التحديثات</h2><p className="mt-1 text-xs text-[#7b857e]">حركة العمل المسجلة مؤخراً</p></div><Link href="/transactions" className="text-xs font-bold text-[#1d5a4d]">كل المعاملات ←</Link></div>
      <div className="divide-y divide-[#eee9df]">{d.transactions.length ? d.transactions.slice(0,7).map((t,i)=><Link href={`/transactions/${t.id}`} key={t.id} className="flex items-center gap-3 px-5 py-4 transition hover:bg-[#faf8f2]" data-testid={`row-dashboard-transaction-${t.id}`}><div className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${t.overdue ? 'bg-[#f8e9e4] text-[#a04437]' : 'bg-[#e7eee7] text-[#3b705d]'}`}>{t.overdue?<Clock3 size={16}/>:<ArrowDownLeft size={16}/>}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><span className="font-mono text-[11px] text-[#778078]">{t.number}</span><span className="truncate text-sm font-semibold">{t.subject}</span></div><div className="mt-1 text-[11px] text-[#818b83]">{t.employeeName} · {t.currentEntity || '—'} · آخر تحديث {fmtDate(t.lastUpdatedAt)}</div></div><span className={`status-chip ${statusTone(t.status)}`}>{t.status}</span><ArrowLeft className="hidden text-[#9ba39e] sm:block" size={15}/></Link>) : <EmptyState title="لا توجد تحديثات بعد" body="ستظهر هنا أحدث حركة للمعاملات التي يمكنك الاطلاع عليها."/>}</div>
    </div>
  </div>;
}

function TransactionsPage() {
  const [, setLocation] = useLocation();
  const [search,setSearch] = useState(()=>new URLSearchParams(window.location.search).get('search')||'');
  const [status,setStatus] = useState(()=>new URLSearchParams(window.location.search).get('status')||'');
  const [priority,setPriority] = useState(()=>new URLSearchParams(window.location.search).get('priority')||'');
  const [employeeId,setEmployeeId] = useState(()=>new URLSearchParams(window.location.search).get('employeeId')||'');
  const [departmentId,setDepartmentId] = useState(()=>new URLSearchParams(window.location.search).get('departmentId')||'');
  const [from,setFrom] = useState(()=>new URLSearchParams(window.location.search).get('from')||'');
  const [to,setTo] = useState(()=>new URLSearchParams(window.location.search).get('to')||'');
  const [followUp,setFollowUp] = useState(()=>new URLSearchParams(window.location.search).get('needsFollowUp')==='true');
  const [overdue,setOverdue] = useState(()=>new URLSearchParams(window.location.search).get('overdue')==='true');
  const [followUpToday,setFollowUpToday] = useState(()=>new URLSearchParams(window.location.search).get('followUpToday')==='true');
  const [followUpMissed,setFollowUpMissed] = useState(()=>new URLSearchParams(window.location.search).get('followUpMissed')==='true');
  const [recentlyUpdated,setRecentlyUpdated] = useState(()=>new URLSearchParams(window.location.search).get('recentlyUpdated')==='true');
  const [inProgress,setInProgress] = useState(()=>new URLSearchParams(window.location.search).get('inProgress')==='true');
  const [createOpen,setCreateOpen] = useState(false);
  const [notice,setNotice] = useState('');
  const user = useGetCurrentUser();
  const departments = useGetDepartments();
  const employees = useGetEmployees({query:{enabled:user.data?.role === 'supervisor',queryKey:getGetEmployeesQueryKey()}});
  const settings = useGetSettings();
  const params = useMemo(() => ({ ...(search.trim()?{search:search.trim()}:{}), ...(status?{status}:{}), ...(priority?{priority}:{}), ...(employeeId&&user.data?.role==='supervisor'?{employeeId:Number(employeeId)}:{}), ...(departmentId?{departmentId:Number(departmentId)}:{}), ...(from?{from}:{}), ...(to?{to}:{}), ...(followUp?{needsFollowUp:true}:{}), ...(overdue?{overdue:true}:{}), ...(followUpToday?{followUpToday:true}:{}), ...(followUpMissed?{followUpMissed:true}:{}), ...(recentlyUpdated?{recentlyUpdated:true}:{}), ...(inProgress?{inProgress:true}:{}) }),[search,status,priority,employeeId,departmentId,from,to,followUp,overdue,followUpToday,followUpMissed,recentlyUpdated,inProgress,user.data?.role]);
  const transactions = useGetTransactions(params);
  const create = useCreateTransaction();
  const client = useQueryClient();
  const [form,setForm] = useState({number:'',subject:'',employeeId:'',departmentId:'',type:'مراسلة',receivedAt:riyadhToday(),currentEntity:'',status:'جديدة',priority:'normal',nextFollowUpAt:'',notes:''});
  const submitCreate = (e: React.FormEvent) => {
    e.preventDefault(); setNotice('');
    create.mutate({data:{...form,employeeId:Number(form.employeeId),departmentId:Number(form.departmentId),receivedAt:dateInputToIso(form.receivedAt,'12:00:00')||new Date().toISOString(),nextFollowUpAt:form.nextFollowUpAt?dateInputToIso(form.nextFollowUpAt,'23:59:59'):null,priority:form.priority as 'normal'|'important'|'urgent'}},{onSuccess:async t=>{await Promise.all([client.invalidateQueries({queryKey:getGetTransactionsQueryKey()}),client.invalidateQueries({queryKey:getGetDashboardQueryKey()}),client.invalidateQueries({queryKey:getGetReportsQueryKey()})]);setCreateOpen(false);setForm({number:'',subject:'',employeeId:'',departmentId:'',type:'مراسلة',receivedAt:riyadhToday(),currentEntity:'',status:'جديدة',priority:'normal',nextFollowUpAt:'',notes:''});setLocation(`/transactions/${t.id}`);},onError:()=>setNotice('تعذر إنشاء المعاملة. تحقق من الحقول ثم أعد المحاولة.')});
  };
  if(transactions.isLoading || user.isLoading) return <LoadingPage/>;
  if(transactions.isError) return <ErrorPage onRetry={()=>transactions.refetch()}/>;
  const isSupervisor=user.data?.role==='supervisor';
  return <div className="fade-up">
    <PageTitle eyebrow="سجل العمل" title="المعاملات" description="ابحث، صفِّ النتائج، وافتح أي معاملة لمعرفة تاريخها." action={isSupervisor?<button onClick={()=>setCreateOpen(true)} className="btn-primary inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold" data-testid="button-create-transaction"><Plus size={17}/> معاملة جديدة</button>:undefined}/>
    <div className="panel mb-4 rounded-2xl p-4">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <div className="relative"><Search className="absolute right-3 top-3 text-[#89938c]" size={16}/><input className="field pr-9" placeholder="ابحث بالرقم أو الموضوع أو الموظف" value={search} onChange={e=>setSearch(e.target.value)} aria-label="بحث المعاملات" data-testid="input-search-transactions"/></div>
        <select className="field" value={status} onChange={e=>setStatus(e.target.value)} aria-label="الحالة"><option value="">كل الحالات</option>{(settings.data?.statuses||[]).map(s=><option key={s}>{s}</option>)}</select>
        <select className="field" value={priority} onChange={e=>setPriority(e.target.value)} aria-label="الأولوية"><option value="">كل الأولويات</option><option value="urgent">عاجل</option><option value="important">مهم</option><option value="normal">عادي</option></select>
        {user.data?.role==='supervisor'&&<select className="field" value={employeeId} onChange={e=>setEmployeeId(e.target.value)} aria-label="الموظف"><option value="">كل الموظفين</option>{(employees.data||[]).map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</select>}
        <select className="field" value={departmentId} onChange={e=>setDepartmentId(e.target.value)} aria-label="القسم"><option value="">كل الأقسام</option>{(departments.data||[]).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select>
        <label className="field flex items-center gap-2"><span className="shrink-0 text-xs text-[#78837b]">من</span><input type="date" className="min-w-0 flex-1 bg-transparent text-xs" value={from} onChange={e=>setFrom(e.target.value)} aria-label="من تاريخ"/></label>
        <label className="field flex items-center gap-2"><span className="shrink-0 text-xs text-[#78837b]">إلى</span><input type="date" className="min-w-0 flex-1 bg-transparent text-xs" value={to} onChange={e=>setTo(e.target.value)} aria-label="إلى تاريخ"/></label>
        <label className="flex cursor-pointer items-center gap-2 rounded-xl bg-[#f2efe8] px-3 text-xs font-semibold"><input type="checkbox" checked={followUp} onChange={e=>setFollowUp(e.target.checked)} className="accent-[#1d5a4d]"/>تحتاج متابعة</label>
        <label className="flex cursor-pointer items-center gap-2 rounded-xl bg-[#f2efe8] px-3 text-xs font-semibold"><input type="checkbox" checked={followUpMissed} onChange={e=>setFollowUpMissed(e.target.checked)}/>تجاوزت موعد المتابعة</label>
        <label className="flex cursor-pointer items-center gap-2 rounded-xl bg-[#e7eee7] px-3 text-xs font-semibold"><input type="checkbox" checked={recentlyUpdated} onChange={e=>setRecentlyUpdated(e.target.checked)}/>محدثة حديثًا</label>
        <label className="flex cursor-pointer items-center gap-2 rounded-xl bg-[#f8eae5] px-3 text-xs font-semibold text-[#895349]"><input type="checkbox" checked={overdue} onChange={e=>setOverdue(e.target.checked)} className="accent-[#a04437]"/>متأخرة</label>
        <label className="flex cursor-pointer items-center gap-2 rounded-xl bg-[#f4ecd7] px-3 text-xs font-semibold text-[#75663f]"><input type="checkbox" checked={followUpToday} onChange={e=>setFollowUpToday(e.target.checked)} className="accent-[#8b6c2e]"/>متابعتها اليوم</label>
        <label className="flex cursor-pointer items-center gap-2 rounded-xl bg-[#e8eee8] px-3 text-xs font-semibold text-[#466454]"><input type="checkbox" checked={inProgress} onChange={e=>setInProgress(e.target.checked)} className="accent-[#1d5a4d]"/>تحت الإجراء</label>
      </div>
    </div>
    <div className="panel overflow-hidden rounded-2xl">
      <div className="flex items-center justify-between border-b border-[#e9e4da] px-5 py-4"><div><h2 className="font-bold">{followUp ? 'معاملات تحتاج متابعة' : 'قائمة المعاملات'}</h2><span className="text-xs text-[#7b857e]">{transactions.data?.length || 0} نتيجة</span></div><Filter size={17} className="text-[#879189]"/></div>
      {transactions.data?.length ? <FollowUpTable transactions={transactions.data}/> : <EmptyState title="لا توجد معاملات مطابقة" body="جرّب تعديل البحث أو إزالة بعض عوامل التصفية."/>}
    </div>
    {createOpen && <Modal title="تسجيل معاملة جديدة" onClose={()=>setCreateOpen(false)}><form onSubmit={submitCreate} className="grid gap-3 sm:grid-cols-2">
      <Field label="رقم المعاملة" required><input className="field" required value={form.number} onChange={e=>setForm({...form,number:e.target.value})}/></Field><Field label="نوع المعاملة" required><input className="field" required value={form.type} onChange={e=>setForm({...form,type:e.target.value})}/></Field>
      <Field label="موضوع المعاملة" required className="sm:col-span-2"><input className="field" required value={form.subject} onChange={e=>setForm({...form,subject:e.target.value})}/></Field>
      <Field label="الموظف المسؤول" required><select className="field" required value={form.employeeId} onChange={e=>{const value=e.target.value;const employee=employees.data?.find(emp=>String(emp.id)===value);setForm({...form,employeeId:value,departmentId:employee?String(employee.departmentId):form.departmentId});}}><option value="">اختر الموظف</option>{(employees.data||[]).filter(emp=>emp.active).map(emp=><option value={emp.id} key={emp.id}>{emp.name}</option>)}</select></Field>
      <Field label="الإدارة" required><select className="field" required value={form.departmentId} onChange={e=>{const value=e.target.value;const employee=employees.data?.find(emp=>emp.active&&String(emp.departmentId)===value);setForm({...form,departmentId:value,employeeId:employee?String(employee.id):''});}}><option value="">اختر الإدارة</option>{(departments.data||[]).map(dep=><option value={dep.id} key={dep.id}>{dep.name}</option>)}</select></Field>
      <Field label="تاريخ الاستلام" required><input type="date" className="field" required value={form.receivedAt} onChange={e=>setForm({...form,receivedAt:e.target.value})}/></Field><Field label="الجهة الحالية"><input className="field" value={form.currentEntity} onChange={e=>setForm({...form,currentEntity:e.target.value})}/></Field>
      <Field label="الحالة"><select className="field" value={form.status} onChange={e=>setForm({...form,status:e.target.value})}>{(settings.data?.statuses||['جديدة','تحت الإجراء','لدى الإدارة','بانتظار مستند','بانتظار رد','متوقفة','متأخرة','مكتملة']).map(s=><option key={s}>{s}</option>)}</select></Field><Field label="الأولوية"><select className="field" value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}><option value="normal">عادية</option><option value="important">مهمة</option><option value="urgent">عاجلة</option></select></Field>
      <Field label="موعد المتابعة"><input type="date" className="field" value={form.nextFollowUpAt} onChange={e=>setForm({...form,nextFollowUpAt:e.target.value})}/></Field><Field label="ملاحظات"><input className="field" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/></Field>
      {notice&&<p role="alert" className="text-sm text-[#a04437] sm:col-span-2">{notice}</p>}<div className="mt-2 flex justify-end gap-2 sm:col-span-2"><button type="button" onClick={()=>setCreateOpen(false)} className="btn-quiet rounded-xl px-4 py-2.5 text-sm">إلغاء</button><button disabled={create.isPending} className="btn-primary rounded-xl px-5 py-2.5 text-sm font-bold">{create.isPending?'جارٍ الحفظ…':'حفظ المعاملة'}</button></div>
    </form></Modal>}
  </div>;
}

function TransactionPage() {
  const params=useParams<{id:string}>();
  const id=Number(params.id);
  const query=useGetTransaction(id,{query:{queryKey:getGetTransactionQueryKey(id),enabled:Number.isFinite(id)&&id>0}});
  const settings=useGetSettings();
  const user=useGetCurrentUser();
  const departments=useGetDepartments();
  const employees=useGetEmployees({query:{enabled:user.data?.role==='supervisor',queryKey:getGetEmployeesQueryKey()}});
  const addUpdate=useAddTransactionUpdate();
  const updateTransaction=useUpdateTransaction();
  const upload=useRequestUploadUrl();
  const client=useQueryClient();
  const [status,setStatus]=useState('');
  const [action,setAction]=useState('');
  const [notes,setNotes]=useState('');
  const [nextFollowUpAt,setNextFollowUpAt]=useState('');
  const [attachments,setAttachments]=useState<{fileName:string;objectPath:string;contentType:string;size:number}[]>([]);
  const [uploading,setUploading]=useState(false);
  const [message,setMessage]=useState('');
  const [editOpen,setEditOpen]=useState(false);
  const [edit,setEdit]=useState({number:'',subject:'',employeeId:'',departmentId:'',type:'',receivedAt:'',currentEntity:'',status:'',priority:'normal',nextFollowUpAt:'',notes:''});
  if(query.isLoading||settings.isLoading||user.isLoading||departments.isLoading||(user.data?.role==='supervisor'&&employees.isLoading)) return <LoadingPage/>;
  if(query.isError||!query.data) return <ErrorPage onRetry={()=>query.refetch()}/>;
  const t=query.data;
  const isSupervisor=user.data?.role==='supervisor';
  const openEdit=()=>{setEdit({number:t.number,subject:t.subject,employeeId:String(t.employeeId),departmentId:String(t.departmentId),type:t.type,receivedAt:t.receivedAt.slice(0,10),currentEntity:t.currentEntity,status:t.status,priority:t.priority,nextFollowUpAt:t.nextFollowUpAt?.slice(0,10)||'',notes:t.notes});setEditOpen(true);};
  const submitUpdate=(e:React.FormEvent)=>{e.preventDefault();setMessage('');addUpdate.mutate({id,data:{status:status||t.status,action,notes,nextFollowUpAt:nextFollowUpAt?dateInputToIso(nextFollowUpAt,'23:59:59'):null,attachments}},{onSuccess:async()=>{setAction('');setNotes('');setAttachments([]);setNextFollowUpAt('');setStatus('');setMessage('تم تسجيل التحديث في السجل.');await Promise.all([client.invalidateQueries({queryKey:getGetTransactionQueryKey(id)}),client.invalidateQueries({queryKey:getGetTransactionsQueryKey()}),client.invalidateQueries({queryKey:getGetDashboardQueryKey()}),client.invalidateQueries({queryKey:getGetNotificationsQueryKey()}),client.invalidateQueries({queryKey:getGetReportsQueryKey()})]);},onError:()=>setMessage('تعذر حفظ التحديث. أعد المحاولة.')});};
  const uploadFile=async(file?:File)=>{if(!file)return;setUploading(true);setMessage('');try{const signed=await upload.mutateAsync({data:{transactionId:id,name:file.name,size:file.size,contentType:file.type||'application/octet-stream'}});const result=await fetch(signed.uploadURL,{method:'PUT',headers:{'Content-Type':file.type||'application/octet-stream'},body:file});if(!result.ok)throw new Error('upload failed');setAttachments(old=>[...old,{fileName:file.name,objectPath:signed.objectPath,contentType:file.type||'application/octet-stream',size:file.size}]);}catch{setMessage('تعذر رفع الملف. تحقق من نوع الملف أو أعد المحاولة.');}finally{setUploading(false);}};
  const submitEdit=(e:React.FormEvent)=>{e.preventDefault();updateTransaction.mutate({id,data:{number:edit.number,subject:edit.subject,employeeId:Number(edit.employeeId),departmentId:Number(edit.departmentId),type:edit.type,receivedAt:dateInputToIso(edit.receivedAt,'12:00:00')||t.receivedAt,currentEntity:edit.currentEntity,status:edit.status,priority:edit.priority as 'normal'|'important'|'urgent',nextFollowUpAt:edit.nextFollowUpAt?dateInputToIso(edit.nextFollowUpAt,'23:59:59'):null,notes:edit.notes}},{onSuccess:async()=>{await Promise.all([client.invalidateQueries({queryKey:getGetTransactionQueryKey(id)}),client.invalidateQueries({queryKey:getGetTransactionsQueryKey()}),client.invalidateQueries({queryKey:getGetDashboardQueryKey()}),client.invalidateQueries({queryKey:getGetReportsQueryKey()})]);setEditOpen(false);},onError:()=>setMessage('تعذر تحديث بيانات المعاملة.')});};
  return <div className="fade-up">
    <Link href="/transactions" className="mb-4 inline-flex items-center gap-2 text-xs font-semibold text-[#6e7b73] hover:text-[#1d5a4d]"><ArrowLeft size={15}/> العودة إلى المعاملات</Link>
    <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_370px]">
      <div>
        <div className="panel rounded-2xl p-5 md:p-7">
          <div className="flex flex-wrap items-start justify-between gap-4"><div><div className="flex flex-wrap items-center gap-2"><span className="font-mono text-xs text-[#738078]">{t.number}</span><span className={`status-chip ${statusTone(t.status)}`}>{t.status}</span>{t.overdue&&<span className="status-chip bg-[#f8e9e4] text-[#a04437]">متأخرة</span>}</div><h1 className="mt-3 text-2xl font-bold leading-relaxed">{t.subject}</h1><div className="mt-2 text-xs text-[#78837b]">{t.type} · {t.departmentName} · أُنشئت {fmtDate(t.createdAt)}</div></div>{isSupervisor&&<button onClick={openEdit} className="btn-quiet inline-flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold"><Settings2 size={15}/> تعديل البيانات</button>}</div>
          <div className="mt-6 grid gap-3 rounded-xl bg-[#f7f5ef] p-4 sm:grid-cols-2 lg:grid-cols-4">{[['الموظف المسؤول',t.employeeName],['الجهة الحالية',t.currentEntity||'—'],['تاريخ الاستلام',fmtDate(t.receivedAt)],['موعد المتابعة',fmtDate(t.nextFollowUpAt)]].map(([label,value])=><div key={label}><div className="text-[10px] text-[#879189]">{label}</div><div className="mt-1 text-sm font-semibold">{value}</div></div>)}</div>
          {t.notes&&<div className="mt-5 rounded-xl border-r-2 border-[#c69a4a] bg-[#fbf7eb] px-4 py-3"><div className="text-[10px] font-bold text-[#8e733c]">ملاحظة على المعاملة</div><p className="mt-1 text-sm leading-7 text-[#59685f]">{t.notes}</p></div>}
          <div className="mt-7 flex items-center justify-between border-b border-[#e9e4da] pb-3"><div><h2 className="font-bold">سجل المتابعة</h2><p className="mt-1 text-[11px] text-[#7c867e]">سجل زمني ثابت للتحديثات والإجراءات</p></div><span className="rounded-full bg-[#eeece4] px-2.5 py-1 text-xs">{t.updates.length}</span></div>
        <div className="mt-5">{t.updates.length ? <div className="space-y-0">{t.updates.map((u,i)=><div key={u.id} className="relative flex gap-4 pb-6 last:pb-0"><div className="relative flex w-6 shrink-0 justify-center"><span className="z-10 mt-1.5 h-3 w-3 rounded-full border-[3px] border-[#1d5a4d] bg-[#fffdf8]"/>{i<t.updates.length-1&&<span className="absolute top-4 h-full w-px bg-[#dcd9ce]"/>}</div><div className="min-w-0 flex-1 rounded-xl border border-[#ece7dc] p-4"><div className="flex flex-wrap items-center justify-between gap-2"><div className="font-semibold">{u.action}</div><time className="text-[10px] text-[#838d85]">{fmtDateTime(u.createdAt)}</time></div><div className="mt-1 text-[11px] text-[#718078]">{u.employeeName} · {u.previousStatus?`${u.previousStatus} ← `:''}<span className="font-semibold text-[#4f6a5a]">{u.newStatus}</span></div>{u.notes&&<p className="mt-3 text-sm leading-6 text-[#606e65]">{u.notes}</p>}{u.attachments?.length>0&&<div className="mt-3 flex flex-wrap gap-2">{u.attachments.map(a=><AttachmentDownload key={a.id} objectPath={a.objectPath} fileName={a.fileName}/>)}</div>}</div></div>)}</div>:<EmptyState title="لا يوجد سجل تحديثات" body="أضف أول إجراء لتوثيق حركة المعاملة."/ >}</div>
        </div>
      </div>
      <aside className="space-y-4">
        <div className="panel rounded-2xl p-5"><div className="flex items-center gap-2"><div className="grid h-9 w-9 place-items-center rounded-xl bg-[#e5f0e8] text-[#2f6855]"><FilePlus2 size={17}/></div><div><h2 className="font-bold">تسجيل إجراء</h2><p className="text-[10px] text-[#7d8780]">سيضاف كتحديث غير قابل للتعديل</p></div></div>
          <form onSubmit={submitUpdate} className="mt-5 space-y-3">
            <Field label="الحالة الجديدة" required><select className="field" value={status||t.status} onChange={e=>setStatus(e.target.value)}>{(settings.data?.statuses||[t.status]).map(s=><option value={s} key={s}>{s}</option>)}</select></Field>
            <Field label="الإجراء المنفذ" required><input className="field" required placeholder="مثال: إحالة للجهة المختصة" value={action} onChange={e=>setAction(e.target.value)}/></Field>
            <Field label="تفاصيل إضافية"><textarea rows={3} className="field resize-y" placeholder="ما الذي تم؟" value={notes} onChange={e=>setNotes(e.target.value)}/></Field>
            <Field label="موعد المتابعة القادم"><input type="date" className="field" value={nextFollowUpAt} onChange={e=>setNextFollowUpAt(e.target.value)}/></Field>
            <label className={`flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-[#d7d1c4] px-3 py-3 text-xs font-semibold text-[#54675b] hover:bg-[#f7f5ef] ${uploading?'opacity-60':''}`}><Paperclip size={15}/>{uploading?'جارٍ رفع الملف…':'إرفاق مستند'}<input type="file" className="hidden" disabled={uploading} onChange={e=>{void uploadFile(e.currentTarget.files?.[0]);e.currentTarget.value='';}}/></label>
            {attachments.length>0&&<div className="space-y-1">{attachments.map(a=><div key={a.objectPath} className="flex items-center justify-between rounded-lg bg-[#edf2ec] px-2.5 py-2 text-xs"><span className="flex min-w-0 items-center gap-2 truncate"><File size={14}/>{a.fileName}</span><button type="button" onClick={()=>setAttachments(list=>list.filter(v=>v.objectPath!==a.objectPath))} aria-label="إزالة المرفق"><X size={14}/></button></div>)}</div>}
            {message&&<p role="status" className="text-xs text-[#476b58]">{message}</p>}
            <button disabled={addUpdate.isPending||uploading} className="btn-primary flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold">{addUpdate.isPending?'جارٍ تسجيل الإجراء…':<><Check size={16}/> حفظ التحديث</>}</button>
          </form>
        </div>
        <div className="panel rounded-2xl p-5"><h3 className="text-sm font-bold">مؤشرات المعاملة</h3><div className="mt-4 space-y-3">{[['الأولوية',priorityLabel(t.priority)],['الأيام منذ آخر تحديث',`${t.daysSinceUpdate} يوم`],['تحتاج متابعة',t.needsFollowUp?'نعم':'لا'],['تاريخ آخر تحديث',fmtDateTime(t.lastUpdatedAt)]].map(([l,v])=><div key={l} className="flex justify-between gap-2 border-b border-[#eee9df] pb-2 text-xs last:border-0"><span className="text-[#7b867e]">{l}</span><span className="font-semibold">{v}</span></div>)}</div></div>
      </aside>
    </div>
    {editOpen&&<Modal title="تعديل بيانات المعاملة" onClose={()=>setEditOpen(false)}><form onSubmit={submitEdit} className="space-y-3"><div className="grid gap-3 sm:grid-cols-2">
      <Field label="رقم المعاملة" required><input className="field" required value={edit.number} onChange={e=>setEdit({...edit,number:e.target.value})}/></Field>
      <Field label="نوع المعاملة" required><input className="field" required value={edit.type} onChange={e=>setEdit({...edit,type:e.target.value})}/></Field>
      <Field label="الموضوع" required className="sm:col-span-2"><input className="field" required value={edit.subject} onChange={e=>setEdit({...edit,subject:e.target.value})}/></Field>
      <Field label="الموظف المسؤول" required><select className="field" required value={edit.employeeId} onChange={e=>{const value=e.target.value;const employee=employees.data?.find(emp=>String(emp.id)===value);setEdit({...edit,employeeId:value,departmentId:employee?String(employee.departmentId):edit.departmentId});}}>{(employees.data||[]).filter(emp=>emp.active||String(emp.id)===edit.employeeId).map(emp=><option key={emp.id} value={emp.id}>{emp.name}</option>)}</select></Field>
      <Field label="الإدارة" required><select className="field" required value={edit.departmentId} onChange={e=>{const value=e.target.value;const employee=employees.data?.find(emp=>emp.active&&String(emp.departmentId)===value);setEdit({...edit,departmentId:value,employeeId:employee?String(employee.id):''});}}>{(departments.data||[]).map(dep=><option key={dep.id} value={dep.id}>{dep.name}</option>)}</select></Field>
      <Field label="تاريخ الاستلام" required><input type="date" className="field" required value={edit.receivedAt} onChange={e=>setEdit({...edit,receivedAt:e.target.value})}/></Field>
      <Field label="الجهة الحالية"><input className="field" value={edit.currentEntity} onChange={e=>setEdit({...edit,currentEntity:e.target.value})}/></Field>
      <Field label="الحالة"><select className="field" value={edit.status} onChange={e=>setEdit({...edit,status:e.target.value})}>{(settings.data?.statuses||[]).map(s=><option key={s}>{s}</option>)}</select></Field>
      <Field label="الأولوية"><select className="field" value={edit.priority} onChange={e=>setEdit({...edit,priority:e.target.value})}><option value="normal">عادية</option><option value="important">مهمة</option><option value="urgent">عاجلة</option></select></Field>
      <Field label="موعد المتابعة القادمة"><input type="date" className="field" value={edit.nextFollowUpAt} onChange={e=>setEdit({...edit,nextFollowUpAt:e.target.value})}/></Field>
      <Field label="ملاحظات"><textarea className="field" rows={2} value={edit.notes} onChange={e=>setEdit({...edit,notes:e.target.value})}/></Field>
      </div><div className="flex justify-end gap-2 pt-2"><button type="button" className="btn-quiet rounded-xl px-4 py-2" onClick={()=>setEditOpen(false)}>إلغاء</button><button disabled={updateTransaction.isPending} className="btn-primary rounded-xl px-4 py-2 font-bold">{updateTransaction.isPending?'جارٍ الحفظ':'حفظ التعديلات'}</button></div></form></Modal>}
  </div>;
}

function AttachmentDownload({objectPath,fileName}:{objectPath:string;fileName:string}) {
  const path=objectPath.replace(/^\/objects\//,'');
  const object=useGetStorageObject(path,{query:{enabled:false,queryKey:getGetStorageObjectQueryKey(path)}});
  const download=async()=>{const result=await object.refetch();if(!result.data)return;const url=URL.createObjectURL(result.data);const link=document.createElement('a');link.href=url;link.download=fileName;link.click();URL.revokeObjectURL(url);};
  return <button type="button" disabled={object.isFetching} onClick={()=>void download()} className="inline-flex items-center gap-2 rounded-lg bg-[#f2f0e9] px-3 py-2 text-xs font-medium text-[#3d5c4d] disabled:opacity-60"><Paperclip size={13}/>{object.isFetching?'جارٍ التحميل':fileName}</button>;
}

function EmployeesPage() {
  const employees=useGetEmployees();
  const departments=useGetDepartments();
  const create=useCreateEmployee();
  const update=useUpdateEmployee();
  const client=useQueryClient();
  const [open,setOpen]=useState(false);
  const [form,setForm]=useState({name:'',email:'',departmentId:'',active:true});
  const [editing,setEditing]=useState<number|null>(null);
  const [error,setError]=useState('');
  const resetForm=()=>{setForm({name:'',email:'',departmentId:'',active:true});setEditing(null);setError('');};
  const openCreate=()=>{resetForm();setOpen(true);};
  const openEdit=(employee:NonNullable<typeof employees.data>[number])=>{setEditing(employee.id);setForm({name:employee.name,email:employee.email,departmentId:String(employee.departmentId),active:employee.active});setError('');setOpen(true);};
  const submit=(e:React.FormEvent)=>{e.preventDefault();setError('');const data={name:form.name,email:form.email.trim().toLowerCase(),departmentId:Number(form.departmentId),active:form.active};const onSuccess=async()=>{await client.invalidateQueries({queryKey:getGetEmployeesQueryKey()});setOpen(false);resetForm();};const onError=(failure:{status?:number})=>setError(failure.status===409?'البريد الإلكتروني مستخدم مسبقًا. استخدم بريدًا مختلفًا.':editing?'تعذر حفظ بيانات الموظف. تحقق من البريد والإدارة.':'تعذر إضافة الموظف. تحقق من البريد والإدارة.');if(editing!==null)update.mutate({id:editing,data},{onSuccess,onError});else create.mutate({data},{onSuccess,onError});};
  if(employees.isLoading||departments.isLoading)return <LoadingPage/>;
  if(employees.isError)return <ErrorPage onRetry={()=>employees.refetch()}/>;
  const team=employees.data||[];
  return <div className="fade-up"><PageTitle eyebrow="إدارة الفريق" title="عبء الموظفين" description="توزيع المعاملات المفتوحة ومؤشرات المتابعة لكل عضو." action={<button onClick={openCreate} className="btn-primary inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold"><Plus size={16}/> إضافة موظف</button>}/>
    <div className="mb-5 grid gap-3 sm:grid-cols-3"><StatCard label="أعضاء الفريق" value={team.filter(e=>e.active).length} detail="حسابات نشطة" icon={Users}/><StatCard label="معاملات مفتوحة" value={team.reduce((n,e)=>n+e.open,0)} detail="موزعة على الفريق" icon={ClipboardList} tone="gold"/><StatCard label="متأخرة" value={team.reduce((n,e)=>n+e.overdue,0)} detail="تحتاج إعادة ترتيب" icon={Clock3} tone="red"/></div>
    <div className="panel overflow-hidden rounded-2xl"><div className="border-b border-[#e9e4da] px-5 py-4"><h2 className="font-bold">أعضاء الفريق</h2><p className="mt-1 text-xs text-[#7b857e]">نظرة على حجم العمل وسرعة تحديثه. اربط كل موظف بالبريد الذي سيستخدمه لتسجيل الدخول.</p></div>{team.length?<div className="table-scroll"><table className="w-full text-right"><thead className="bg-[#f8f6f0] text-[10px] font-bold text-[#7e8981]"><tr>{['الموظف','الإدارة','إجمالي','مفتوحة','مكتملة','متأخرة','آخر تحديث','الحساب'].map(x=><th key={x} className="px-4 py-3">{x}</th>)}</tr></thead><tbody className="divide-y divide-[#eee9df]">{team.map(e=><tr key={e.id} className="hover:bg-[#faf8f2]" data-testid={`row-employee-${e.id}`}><td className="px-4 py-4"><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-full bg-[#e5eee8] text-sm font-bold text-[#315d4b]">{e.name.trim().slice(0,1)}</div><div><div className="text-sm font-semibold">{e.name}</div><div className="text-[10px] text-[#849088]">{e.email}</div></div></div></td><td className="px-4 py-4 text-xs">{e.departmentName}</td><td className="px-4 py-4 font-mono text-sm">{e.total}</td><td className="px-4 py-4 font-mono text-sm">{e.open}</td><td className="px-4 py-4 font-mono text-sm text-[#357153]">{e.completed}</td><td className="px-4 py-4 font-mono text-sm text-[#a04437]">{e.overdue}</td><td className="px-4 py-4 text-xs text-[#78837b]">{fmtDate(e.lastUpdatedAt)}</td><td className="px-4 py-4"><div className="flex items-center gap-2"><button onClick={()=>openEdit(e)} className="rounded-lg px-2 py-1.5 text-[10px] font-bold text-[#1d5a4d] hover:bg-[#e8efe9]">تعديل</button><button onClick={()=>update.mutate({id:e.id,data:{name:e.name,email:e.email,departmentId:e.departmentId,active:!e.active}},{onSuccess:()=>client.invalidateQueries({queryKey:getGetEmployeesQueryKey()})})} className={`rounded-full px-3 py-1.5 text-[10px] font-bold ${e.active?'bg-[#e5f1e9] text-[#286149]':'bg-[#efeee8] text-[#758078]'}`} data-testid={`button-toggle-employee-${e.id}`}>{e.active?'نشط':'غير نشط'} · تغيير</button></div></td></tr>)}</tbody></table></div>:<EmptyState title="لا يوجد موظفون مسجلون" body="أضف أعضاء الفريق لبدء توزيع العمل."/>}</div>
    {open&&<Modal title={editing!==null?'تعديل بيانات موظف':'إضافة موظف للفريق'} onClose={()=>setOpen(false)}><form onSubmit={submit} className="space-y-3"><Field label="الاسم الكامل" required><input className="field" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></Field><Field label="البريد الإلكتروني" required><input type="email" className="field" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></Field><Field label="الإدارة" required><select className="field" required value={form.departmentId} onChange={e=>setForm({...form,departmentId:e.target.value})}><option value="">اختر الإدارة</option>{(departments.data||[]).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select></Field><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.active} onChange={e=>setForm({...form,active:e.target.checked})} className="accent-[#1d5a4d]"/>حساب نشط</label>{error&&<p className="text-xs text-[#a04437]">{error}</p>}<div className="flex justify-end gap-2 pt-2"><button type="button" onClick={()=>{setOpen(false);resetForm();}} className="btn-quiet rounded-xl px-4 py-2">إلغاء</button><button disabled={create.isPending||update.isPending} className="btn-primary rounded-xl px-4 py-2 font-bold">{create.isPending||update.isPending?'جارٍ الحفظ…':editing!==null?'حفظ التغييرات':'إضافة الموظف'}</button></div></form></Modal>}
  </div>;
}

function ReportsPage() {
  const employees=useGetEmployees();
  const departments=useGetDepartments();
  const settings=useGetSettings();
  const [employeeId,setEmployeeId]=useState('');
  const [departmentId,setDepartmentId]=useState('');
  const [status,setStatus]=useState('');
  const [from,setFrom]=useState('');
  const [to,setTo]=useState('');
  const [overdue,setOverdue]=useState(false);
  const [needsFollowUp,setNeedsFollowUp]=useState(false);
  const params=useMemo(()=>({...employeeId?{employeeId:Number(employeeId)}:{},...departmentId?{departmentId:Number(departmentId)}:{},...status?{status}:{},...from?{from}:{},...to?{to}:{},...(overdue?{overdue:true}:{}),...(needsFollowUp?{needsFollowUp:true}:{})}),[employeeId,departmentId,status,from,to,overdue,needsFollowUp]);
  const query=useGetReports(params);
  const exportExcel=()=>{if(!query.data)return;const headers=['رقم المعاملة','الموضوع','الموظف','الإدارة','النوع','الحالة','الأولوية','تاريخ الاستلام','موعد المتابعة','آخر تحديث','الجهة الحالية'];const rows=query.data.map(t=>[t.number,t.subject,t.employeeName,t.departmentName,t.type,t.status,priorityLabel(t.priority),fmtDate(t.receivedAt),fmtDate(t.nextFollowUpAt),fmtDate(t.lastUpdatedAt),t.currentEntity]);const sheet=XLSX.utils.aoa_to_sheet([headers,...rows]);sheet['!cols']=[{wch:18},{wch:32},{wch:24},{wch:22},{wch:18},{wch:18},{wch:14},{wch:16},{wch:16},{wch:16},{wch:24}];const workbook=XLSX.utils.book_new();XLSX.utils.book_append_sheet(workbook,sheet,'المعاملات');XLSX.writeFile(workbook,`تقرير-المعاملات-${new Date().toISOString().slice(0,10)}.xlsx`);};
  if(query.isLoading||employees.isLoading||departments.isLoading||settings.isLoading)return <LoadingPage/>;
  if(query.isError)return <ErrorPage onRetry={()=>query.refetch()}/>;
  return <div className="fade-up"><PageTitle eyebrow="قراءة الأداء" title="تقارير المعاملات" description="حدد النطاق، راجع النتائج، ثم صدّرها للاجتماع أو الأرشفة." action={<div className="flex gap-2 no-print"><button onClick={exportExcel} disabled={!query.data?.length} className="btn-primary inline-flex items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold"><Download size={15}/> تصدير Excel</button><button onClick={()=>window.print()} className="btn-quiet inline-flex items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold"><File size={15}/> حفظ PDF</button></div>}/>
    <div className="panel mb-4 rounded-2xl p-4"><div className="mb-3 flex items-center gap-2 text-xs font-bold text-[#5c6a61]"><Filter size={15}/> معايير التقرير</div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><select className="field" value={employeeId} onChange={e=>setEmployeeId(e.target.value)}><option value="">كل الموظفين</option>{(employees.data||[]).map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</select><select className="field" value={departmentId} onChange={e=>setDepartmentId(e.target.value)}><option value="">كل الإدارات</option>{(departments.data||[]).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select><select className="field" value={status} onChange={e=>setStatus(e.target.value)}><option value="">كل الحالات</option>{(settings.data?.statuses||[]).map(s=><option key={s}>{s}</option>)}</select><input type="date" className="field" aria-label="من تاريخ" value={from} onChange={e=>setFrom(e.target.value)}/><input type="date" className="field" aria-label="إلى تاريخ" value={to} onChange={e=>setTo(e.target.value)}/><label className="flex cursor-pointer items-center gap-2 rounded-xl bg-[#f8eae5] px-3 text-xs font-semibold"><input type="checkbox" checked={overdue} onChange={e=>setOverdue(e.target.checked)} className="accent-[#a04437]"/>المتأخرة</label><label className="flex cursor-pointer items-center gap-2 rounded-xl bg-[#f4ecd7] px-3 text-xs font-semibold"><input type="checkbox" checked={needsFollowUp} onChange={e=>setNeedsFollowUp(e.target.checked)} className="accent-[#8b6c2e]"/>التي تحتاج تحديثاً</label></div></div>
    <div className="mb-4 grid gap-3 sm:grid-cols-3"><StatCard label="عدد النتائج" value={query.data?.length||0} detail="ضمن نطاق التقرير" icon={ClipboardList}/><StatCard label="متأخرة" value={query.data?.filter(t=>t.overdue).length||0} detail="بحسب الفلاتر المحددة" icon={Clock3} tone="red"/><StatCard label="مكتملة" value={query.data?.filter(t=>/مكتمل|منجز|completed|done/i.test(t.status)).length||0} detail="ضمن نطاق التقرير" icon={CheckCheck}/></div>
    <div className="panel overflow-hidden rounded-2xl"><div className="flex items-center justify-between border-b border-[#e9e4da] px-5 py-4"><div><h2 className="font-bold">نتائج التقرير</h2><div className="mt-1 text-xs text-[#7b857e]">{query.data?.length||0} معاملة</div></div><CalendarDays size={17} className="text-[#718078]"/></div>{query.data?.length?<div className="table-scroll"><table className="w-full text-right"><thead className="bg-[#f8f6f0] text-[10px] font-bold text-[#7e8981]"><tr>{['الرقم','الموضوع','الموظف','الإدارة','الحالة','الأولوية','الاستلام','آخر تحديث'].map(x=><th key={x} className="px-4 py-3">{x}</th>)}</tr></thead><tbody className="divide-y divide-[#eee9df]">{query.data.map(t=><tr key={t.id} className="hover:bg-[#faf8f2]"><td className="px-4 py-3 font-mono text-xs">{t.number}</td><td className="max-w-[240px] truncate px-4 py-3 text-xs font-semibold">{t.subject}</td><td className="px-4 py-3 text-xs">{t.employeeName}</td><td className="px-4 py-3 text-xs">{t.departmentName}</td><td className="px-4 py-3"><span className={`status-chip ${statusTone(t.status)}`}>{t.status}</span></td><td className="px-4 py-3 text-xs">{priorityLabel(t.priority)}</td><td className="px-4 py-3 text-xs">{fmtDate(t.receivedAt)}</td><td className="px-4 py-3 text-xs">{fmtDate(t.lastUpdatedAt)}</td></tr>)}</tbody></table></div>:<EmptyState title="لا توجد نتائج في هذا النطاق" body="وسّع فترة التقرير أو غيّر أحد المرشحات."/>}</div>
  </div>;
}

function SettingsPage() {
  const health=useHealthCheck({query:{queryKey:getHealthCheckQueryKey()}});
  const query=useGetSettings();
  const currentUser=useGetCurrentUser();
  const update=useUpdateSettings();
  const client=useQueryClient();
  const [days,setDays]=useState<number|null>(null);
  const [statuses,setStatuses]=useState<string[]|null>(null);
  const [newStatus,setNewStatus]=useState('');
  const [message,setMessage]=useState('');
  if(query.isLoading)return <LoadingPage/>;
  if(query.isError||!query.data)return <ErrorPage onRetry={()=>query.refetch()}/>;
  const followUpDays=days??query.data.followUpDays;
  const currentStatuses=statuses??query.data.statuses;
  const save=()=>{setMessage('');update.mutate({data:{followUpDays,statuses:currentStatuses}},{onSuccess:async()=>{await client.invalidateQueries();setDays(null);setStatuses(null);setMessage('تم حفظ إعدادات المتابعة.');},onError:()=>setMessage('تعذر حفظ الإعدادات. أعد المحاولة.')});};
  return <div className="fade-up"><PageTitle eyebrow="ضبط النظام" title="الإعدادات" description="حدد إيقاع المتابعة وقائمة الحالات المستخدمة في سجل المعاملات."/>
    <div className="grid gap-5 lg:grid-cols-[.85fr_1.15fr]">
      <section className="panel rounded-2xl p-5 md:p-6"><div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[#f4ecd7] text-[#8b6c2e]"><Clock3 size={18}/></div><div><h2 className="font-bold">مدة المتابعة الافتراضية</h2><p className="mt-1 text-xs text-[#7b857e]">عدد الأيام قبل ظهور المعاملة كبحاجة متابعة</p></div></div><div className="mt-7 flex items-center gap-3"><input type="number" min="1" max="90" className="field max-w-[130px] text-center font-mono text-xl" value={followUpDays} onChange={e=>setDays(Math.min(90,Math.max(1,Number(e.target.value))))} data-testid="input-followup-days"/><span className="text-sm text-[#748078]">يوماً</span></div><div className="mt-4 rounded-xl bg-[#f7f5ef] p-4 text-xs leading-6 text-[#727e75]">تبدأ المتابعة عند بلوغ هذه المدة من آخر تحديث فعلي، سواء وُجد موعد متابعة أم لا. المعاملات المكتملة مستثناة. الحد المسموح من يوم إلى ٩٠ يوماً.</div></section>
      <section className="panel rounded-2xl p-5 md:p-6"><div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[#e5f0e8] text-[#2f6855]"><ClipboardList size={18}/></div><div><h2 className="font-bold">حالات المعاملة</h2><p className="mt-1 text-xs text-[#7b857e]">الحالات المتاحة عند تسجيل تحديث</p></div></div><div className="mt-5 flex flex-wrap gap-2">{currentStatuses.map(s=><span key={s} className="inline-flex items-center gap-2 rounded-full border border-[#e5dfd3] bg-[#faf8f2] px-3 py-2 text-xs font-semibold">{s}<button aria-label={`حذف حالة ${s}`} onClick={()=>setStatuses(currentStatuses.filter(x=>x!==s))} className="text-[#9c7666] hover:text-[#a04437]"><X size={13}/></button></span>)}</div><form className="mt-5 flex gap-2" onSubmit={e=>{e.preventDefault();if(newStatus.trim()&&!currentStatuses.includes(newStatus.trim()))setStatuses([...currentStatuses,newStatus.trim()]);setNewStatus('');}}><input className="field" placeholder="اسم حالة جديدة" value={newStatus} onChange={e=>setNewStatus(e.target.value)}/><button className="btn-quiet shrink-0 rounded-xl px-4 font-bold" aria-label="إضافة حالة"><Plus size={17}/></button></form></section>
    </div>
    <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-[#e4ece3] p-4"><div className="text-xs text-[#526b5b]">{message||'لن تتغير الإعدادات إلا بعد حفظ التغييرات.'}</div><div className="flex items-center gap-4"><span className="text-[10px] text-[#6d7a70]">{health.isError?'تعذر التحقق من اتصال النظام':health.data?.status==='ok'?'النظام متصل':'جارٍ التحقق من النظام'}</span><button disabled={update.isPending||currentStatuses.length===0} onClick={save} className="btn-primary inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold">{update.isPending?'جارٍ الحفظ…':<><Check size={15}/> حفظ الإعدادات</>}</button></div></div>
    <SupervisorManagement/>
    <AttributionSettings/>
     <ProductionCleanupPanel isPrimarySupervisor={currentUser.data?.canEditFooterCredit===true}/>
  </div>;
}

function NotificationsPage() {
  const query=useGetNotifications();
  const mark=useMarkNotificationRead();
  const client=useQueryClient();
  if(query.isLoading)return <LoadingPage/>;
  if(query.isError)return <ErrorPage onRetry={()=>query.refetch()}/>;
  const list=query.data||[];
  return <div className="fade-up"><PageTitle eyebrow="مركز التنبيه" title="التنبيهات" description="تابع التنبيهات المرتبطة بحركة المعاملات ومواعيدها." action={list.some(n=>!n.readAt)?<button onClick={()=>list.filter(n=>!n.readAt).forEach(n=>mark.mutate({id:n.id},{onSuccess:()=>client.invalidateQueries({queryKey:getGetNotificationsQueryKey()})}))} className="btn-quiet rounded-xl px-4 py-2.5 text-xs font-bold" data-testid="button-mark-all-read">تحديد الكل كمقروء</button>:undefined}/>
    <div className="panel overflow-hidden rounded-2xl">{list.length?<div className="divide-y divide-[#eee9df]">{list.map(n=><div key={n.id} className={`flex gap-4 px-5 py-4 ${n.readAt?'':'bg-[#fbf8ed]'}`} data-testid={`notification-${n.id}`}><div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${n.readAt?'bg-[#f0eee8] text-[#78837b]':'bg-[#f2e8cf] text-[#8b6c2e]'}`}><Bell size={17}/></div><div className="min-w-0 flex-1"><div className="text-sm font-semibold leading-6">{n.message}</div><div className="mt-1 text-[10px] text-[#818b83]">{fmtDateTime(n.createdAt)}{n.type&&` · ${n.type}`}</div>{n.transactionId&&<Link href={`/transactions/${n.transactionId}`} className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-[#1d5a4d]">عرض المعاملة <ArrowLeft size={13}/></Link>}</div>{!n.readAt&&<button aria-label="تحديد كمقروء" onClick={()=>mark.mutate({id:n.id},{onSuccess:()=>client.invalidateQueries({queryKey:getGetNotificationsQueryKey()})})} className="h-fit rounded-lg p-2 text-[#557360] hover:bg-[#e7eee7]"><Check size={16}/></button>}</div>)}</div>:<EmptyState title="لا توجد تنبيهات" body="ستظهر هنا تنبيهات المتابعة وتحديثات معاملاتك."/>}</div>
  </div>;
}

function Modal({title,children,onClose}:{title:string;children:React.ReactNode;onClose:()=>void}) {
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#172c27]/50 p-0 backdrop-blur-[2px] sm:items-center sm:p-5" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><section role="dialog" aria-modal="true" aria-label={title} className="max-h-[92dvh] w-full max-w-2xl overflow-y-auto rounded-t-[24px] bg-[#fffdf8] p-5 shadow-2xl sm:rounded-2xl sm:p-6"><div className="mb-5 flex items-center justify-between border-b border-[#e9e4da] pb-4"><h2 className="text-lg font-bold">{title}</h2><button onClick={onClose} aria-label="إغلاق" className="rounded-lg p-2 hover:bg-[#f0eee8]"><X size={17}/></button></div>{children}</section></div>;
}
function Field({label,required,children,className=''}:{label:string;required?:boolean;children:React.ReactNode;className?:string}) { return <label className={`block ${className}`}><span className="label">{label}{required&&<b className="mr-1 text-[#a04437]">*</b>}</span>{children}</label>; }
function NotFoundPage() { return <div className="grid min-h-[100dvh] place-items-center bg-[#f6f3eb] p-6 text-center" dir="rtl"><div><div className="font-mono text-6xl font-semibold text-[#1d5a4d]">404</div><h1 className="mt-3 text-xl font-bold">الصفحة غير موجودة</h1><p className="mt-2 text-sm text-[#78837b]">قد يكون الرابط غير صحيح أو أن الصفحة نُقلت.</p><Link href="/" className="btn-primary mt-5 inline-flex rounded-xl px-4 py-2.5 text-sm font-bold">العودة للرئيسية</Link></div></div>; }

function App() {
  return <WouterRouter base={basePath}><ClerkProviderRoutes/></WouterRouter>;
}
export default App;
