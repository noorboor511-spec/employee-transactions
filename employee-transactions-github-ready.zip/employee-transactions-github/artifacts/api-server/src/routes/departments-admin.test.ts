import test from "node:test";
import assert from "node:assert/strict";
import express from "express";
import departmentsAdminRouter from "./departments-admin";
import * as database from "@workspace/db";

const { departmentManagementTestState } = database as unknown as {
  departmentManagementTestState: {
    departments: Array<{ id: number; name: string }>;
    employees: Array<{ id: number; departmentId: number }>;
    transactions: Array<{ id: number; departmentId: number }>;
    audits: Array<{ action: string; entityId: number | null }>;
    lockCount: number;
    nextDepartmentId: number;
    primaryId: number;
  };
};

test("department administration is primary-only and preserves linked records", async () => {
  const state = departmentManagementTestState;
  state.primaryId = 901;
  state.departments = [
    { id: 1, name: "الموارد البشرية" },
    { id: 2, name: "الشؤون المالية" },
    { id: 3, name: "الخدمات" },
    { id: 4, name: "المتابعة" },
    { id: 5, name: "الإدارة العامة" },
  ];
  state.employees = [];
  state.transactions = [];
  state.audits = [];
  state.lockCount = 0;
  state.nextDepartmentId = 6;

  const app = express();
  app.use(express.json());
  app.use("/api", departmentsAdminRouter);
  const server = app.listen(0, "127.0.0.1");
  await new Promise<void>((resolve) => server.once("listening", resolve));
  const address = server.address();
  assert.ok(address && typeof address !== "string");
  const url = `http://127.0.0.1:${address.port}/api/departments`;
  const request = (method: string, path = "", role?: string, id = 901, body?: unknown) =>
    fetch(`${url}${path}`, {
      method,
      headers: {
        ...(role ? { "x-test-role": role } : {}),
        "x-test-id": String(id),
        ...(body ? { "Content-Type": "application/json" } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });

  try {
    assert.equal((await request("POST", "", undefined, 901, { name: "مرفوضة" })).status, 401);
    assert.equal((await request("POST", "", "employee", 903, { name: "مرفوضة" })).status, 403);
    assert.equal((await request("POST", "", "supervisor", 902, { name: "مرفوضة" })).status, 403);
    assert.equal(state.departments.length, 5);

    assert.equal((await request("POST", "", "supervisor", 901, { name: "   " })).status, 400);
    const createdResponse = await request("POST", "", "supervisor", 901, { name: "  Operations   Desk  " });
    assert.equal(createdResponse.status, 201);
    const created = await createdResponse.json() as { id: number; name: string };
    assert.equal(created.name, "Operations Desk");
    assert.equal(state.departments.length, 6);

    const duplicate = await request("POST", "", "supervisor", 901, { name: " operations desk " });
    assert.equal(duplicate.status, 409);
    assert.equal(state.departments.length, 6);

    const renamedResponse = await request("PATCH", `/${created.id}`, "supervisor", 901, { name: "قسم العمليات" });
    assert.equal(renamedResponse.status, 200);
    const renamed = await renamedResponse.json() as { id: number; name: string };
    assert.deepEqual(renamed, { id: created.id, name: "قسم العمليات" });

    const duplicateRename = await request("PATCH", `/${created.id}`, "supervisor", 901, { name: " الموارد البشرية " });
    assert.equal(duplicateRename.status, 409);
    assert.equal(state.departments.find((item) => item.id === created.id)?.name, "قسم العمليات");

    state.employees.push({ id: 71, departmentId: created.id });
    state.transactions.push({ id: 81, departmentId: created.id });
    const blockedDelete = await request("DELETE", `/${created.id}`, "supervisor", 901);
    assert.equal(blockedDelete.status, 409);
    assert.match((await blockedDelete.json() as { error: string }).error, /موظفين ومعاملات/);
    assert.ok(state.departments.some((item) => item.id === created.id));
    assert.equal(state.employees[0]?.departmentId, created.id);
    assert.equal(state.transactions[0]?.departmentId, created.id);

    const unusedResponse = await request("POST", "", "supervisor", 901, { name: "إدارة قابلة للحذف" });
    assert.equal(unusedResponse.status, 201);
    const unused = await unusedResponse.json() as { id: number };
    const deleteUnused = await request("DELETE", `/${unused.id}`, "supervisor", 901);
    assert.equal(deleteUnused.status, 200);
    assert.deepEqual(await deleteUnused.json(), { id: unused.id, deleted: true });
    assert.ok(!state.departments.some((item) => item.id === unused.id));

    assert.deepEqual(
      state.departments.filter((item) => item.id <= 5).map((item) => item.id),
      [1, 2, 3, 4, 5],
    );
    assert.ok(state.lockCount >= 6, "each attempted mutation should take the cross-instance name lock");
  } finally {
    server.closeAllConnections();
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
});
