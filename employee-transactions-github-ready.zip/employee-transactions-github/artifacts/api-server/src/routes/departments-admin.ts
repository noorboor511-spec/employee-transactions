import { eq, sql } from "drizzle-orm";
import { Router, type IRouter, type RequestHandler } from "express";
import {
  CreateDepartmentBody,
  CreateDepartmentResponse,
  DeleteDepartmentParams,
  DeleteDepartmentResponse,
  UpdateDepartmentBody,
  UpdateDepartmentParams,
  UpdateDepartmentResponse,
} from "@workspace/api-zod";
import {
  auditLogsTable,
  db,
  departmentsTable,
  employeesTable,
  transactionsTable,
} from "@workspace/db";
import { requireAppUser } from "../lib/auth";
import { isPrimarySupervisor } from "../lib/footer-permissions";

const router: IRouter = Router();
const DEPARTMENT_NAME_LOCK = 846_239_117;

class DuplicateDepartmentNameError extends Error {}

type DepartmentExecutor = Parameters<Parameters<typeof db.transaction>[0]>[0];

function normalizeDepartmentName(value: string): string {
  return value.trim().replace(/\s+/gu, " ").toLowerCase();
}

function cleanDepartmentName(value: string): string {
  return value.trim().replace(/\s+/gu, " ");
}

function postgresCode(error: unknown): string | undefined {
  if (typeof error !== "object" || error === null || !("code" in error)) return undefined;
  return typeof error.code === "string" ? error.code : undefined;
}

function departmentId(raw: unknown): number | null {
  const value = Array.isArray(raw) ? raw[0] : raw;
  if (typeof value !== "string" || !/^[1-9]\d*$/.test(value)) return null;
  const id = Number(value);
  return Number.isSafeInteger(id) ? id : null;
}

const primarySupervisorOnly: RequestHandler = async (req, res, next) => {
  try {
    if (!req.appUser || !await isPrimarySupervisor(req.appUser)) {
      res.status(403).json({ error: "إدارة الإدارات متاحة للمشرف الرئيس فقط." });
      return;
    }
    next();
  } catch (error) {
    req.log.error({ err: error }, "Could not verify department management permission");
    res.status(500).json({ error: "تعذر التحقق من صلاحية إدارة الإدارات." });
  }
};

async function lockDepartmentNames(tx: DepartmentExecutor): Promise<void> {
  // Serialize all app-level department name changes, including requests handled
  // by different API instances, without requiring a schema migration.
  await tx.execute(sql`SELECT pg_advisory_xact_lock(${DEPARTMENT_NAME_LOCK})`);
}

async function assertUniqueName(
  tx: DepartmentExecutor,
  name: string,
  excludeId?: number,
): Promise<void> {
  const departments = await tx
    .select({ id: departmentsTable.id, name: departmentsTable.name })
    .from(departmentsTable);
  const normalized = normalizeDepartmentName(name);
  if (departments.some((item) =>
    item.id !== excludeId && normalizeDepartmentName(item.name) === normalized
  )) {
    throw new DuplicateDepartmentNameError();
  }
}

router.post(
  "/departments",
  requireAppUser,
  primarySupervisorOnly,
  async (req, res): Promise<void> => {
    const parsed = CreateDepartmentBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "أدخل اسم إدارة صحيحًا لا يتجاوز 120 حرفًا." });
      return;
    }
    const name = cleanDepartmentName(parsed.data.name);
    if (!name) {
      res.status(400).json({ error: "اسم الإدارة مطلوب." });
      return;
    }

    try {
      const department = await db.transaction(async (tx) => {
        await lockDepartmentNames(tx);
        await assertUniqueName(tx, name);
        const [created] = await tx
          .insert(departmentsTable)
          .values({ name })
          .returning({ id: departmentsTable.id, name: departmentsTable.name });
        await tx.insert(auditLogsTable).values({
          userId: req.appUser!.id,
          action: "create_department",
          entity: "department",
          entityId: created.id,
          details: { name: created.name },
        });
        return created;
      });
      res.status(201).json(CreateDepartmentResponse.parse(department));
    } catch (error) {
      if (error instanceof DuplicateDepartmentNameError || postgresCode(error) === "23505") {
        res.status(409).json({ error: "توجد إدارة بهذا الاسم أو باسم يختلف بالمسافات أو حالة الأحرف فقط." });
        return;
      }
      req.log.error({ err: error }, "Could not create department");
      res.status(500).json({ error: "تعذرت إضافة الإدارة. أعد المحاولة." });
    }
  },
);

router.patch(
  "/departments/:id",
  requireAppUser,
  primarySupervisorOnly,
  async (req, res): Promise<void> => {
    const params = UpdateDepartmentParams.safeParse(req.params);
    const parsed = UpdateDepartmentBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: "تحقق من رقم الإدارة واسمها." });
      return;
    }
    const name = cleanDepartmentName(parsed.data.name);
    if (!name) {
      res.status(400).json({ error: "اسم الإدارة مطلوب." });
      return;
    }

    try {
      const result = await db.transaction(async (tx) => {
        await lockDepartmentNames(tx);
        const [current] = await tx
          .select({ id: departmentsTable.id, name: departmentsTable.name })
          .from(departmentsTable)
          .where(eq(departmentsTable.id, params.data.id))
          .limit(1)
          .for("update");
        if (!current) return { kind: "missing" as const };
        await assertUniqueName(tx, name, current.id);
        const [updated] = await tx
          .update(departmentsTable)
          .set({ name })
          .where(eq(departmentsTable.id, current.id))
          .returning({ id: departmentsTable.id, name: departmentsTable.name });
        await tx.insert(auditLogsTable).values({
          userId: req.appUser!.id,
          action: "rename_department",
          entity: "department",
          entityId: current.id,
          details: { previousName: current.name, name: updated.name },
        });
        return { kind: "updated" as const, department: updated };
      });
      if (result.kind === "missing") {
        res.status(404).json({ error: "الإدارة غير موجودة." });
        return;
      }
      res.json(UpdateDepartmentResponse.parse(result.department));
    } catch (error) {
      if (error instanceof DuplicateDepartmentNameError || postgresCode(error) === "23505") {
        res.status(409).json({ error: "توجد إدارة بهذا الاسم أو باسم يختلف بالمسافات أو حالة الأحرف فقط." });
        return;
      }
      req.log.error({ err: error }, "Could not rename department");
      res.status(500).json({ error: "تعذر تعديل اسم الإدارة. أعد المحاولة." });
    }
  },
);

router.delete(
  "/departments/:id",
  requireAppUser,
  primarySupervisorOnly,
  async (req, res): Promise<void> => {
    const params = DeleteDepartmentParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: "رقم الإدارة غير صحيح." });
      return;
    }

    try {
      const result = await db.transaction(async (tx) => {
        await lockDepartmentNames(tx);
        const [department] = await tx
          .select({ id: departmentsTable.id, name: departmentsTable.name })
          .from(departmentsTable)
          .where(eq(departmentsTable.id, params.data.id))
          .limit(1)
          .for("update");
        if (!department) return { kind: "missing" as const };

        const [employee] = await tx
          .select({ id: employeesTable.id })
          .from(employeesTable)
          .where(eq(employeesTable.departmentId, department.id))
          .limit(1);
        const [transaction] = await tx
          .select({ id: transactionsTable.id })
          .from(transactionsTable)
          .where(eq(transactionsTable.departmentId, department.id))
          .limit(1);
        if (employee || transaction) {
          return {
            kind: "linked" as const,
            hasEmployees: Boolean(employee),
            hasTransactions: Boolean(transaction),
          };
        }

        await tx.delete(departmentsTable).where(eq(departmentsTable.id, department.id));
        await tx.insert(auditLogsTable).values({
          userId: req.appUser!.id,
          action: "delete_department",
          entity: "department",
          entityId: department.id,
          details: { name: department.name },
        });
        return { kind: "deleted" as const, id: department.id };
      });

      if (result.kind === "missing") {
        res.status(404).json({ error: "الإدارة غير موجودة." });
        return;
      }
      if (result.kind === "linked") {
        const reasons = [
          result.hasEmployees ? "موظفين" : "",
          result.hasTransactions ? "معاملات" : "",
        ].filter(Boolean).join(" و");
        res.status(409).json({ error: `لا يمكن حذف الإدارة لارتباطها بـ${reasons}. غيّر اسمها بدلًا من ذلك إذا لزم.` });
        return;
      }
      res.json(DeleteDepartmentResponse.parse({ id: result.id, deleted: true }));
    } catch (error) {
      if (postgresCode(error) === "23503") {
        res.status(409).json({ error: "لا يمكن حذف الإدارة لارتباطها بموظفين أو معاملات." });
        return;
      }
      req.log.error({ err: error }, "Could not delete department");
      res.status(500).json({ error: "تعذر حذف الإدارة. أعد المحاولة." });
    }
  },
);

export default router;
