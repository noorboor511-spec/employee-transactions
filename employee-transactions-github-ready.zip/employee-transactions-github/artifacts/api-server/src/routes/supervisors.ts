import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, auditLogsTable } from "@workspace/db";
import {
  AppointSupervisorBody,
  AppointSupervisorResponse,
  GetSupervisorsResponse,
} from "@workspace/api-zod";
import { requireAppUser, supervisorOnly } from "../lib/auth";
import { isPrimarySupervisor } from "../lib/footer-permissions";

const router: IRouter = Router();
const publicFields = {
  id: usersTable.id,
  name: usersTable.name,
  email: usersTable.email,
};

router.get("/supervisors", requireAppUser, supervisorOnly, async (req, res) => {
  const canRevoke = await isPrimarySupervisor(req.appUser!);
  const supervisors = await db.select(publicFields).from(usersTable)
    .where(eq(usersTable.role, "supervisor")).orderBy(usersTable.name);
  res.json(GetSupervisorsResponse.parse(supervisors.map(account => ({
    ...account, canRevoke: canRevoke && account.id !== req.appUser!.id,
  }))));
});

router.post("/supervisors", requireAppUser, supervisorOnly, async (req, res): Promise<void> => {
  const parsed = AppointSupervisorBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.name.trim()) {
    res.status(400).json({ error: "أدخل الاسم والبريد الإلكتروني الصحيحين." });
    return;
  }
  const email = parsed.data.email.trim().toLowerCase();
  const supervisor = await db.transaction(async (tx) => {
    // The server owns the role. Promotion preserves the existing identity,
    // name, email, employee link, and transaction history.
    const [account] = await tx.insert(usersTable).values({
      name: parsed.data.name.trim(),
      email,
      role: "supervisor",
    }).onConflictDoUpdate({
      target: usersTable.email,
      set: { role: "supervisor" },
    }).returning(publicFields);
    await tx.insert(auditLogsTable).values({
      userId: req.appUser!.id,
      action: "appoint_supervisor",
      entity: "user",
      entityId: account.id,
      details: { role: "supervisor" },
    });
    return account;
  });
  res.status(201).json(AppointSupervisorResponse.parse({
    ...supervisor,
    canRevoke: await isPrimarySupervisor(req.appUser!) && supervisor.id !== req.appUser!.id,
  }));
});

// Remove only the supervisor role, never the account or its historical records.
router.delete("/supervisors/:id", requireAppUser, supervisorOnly, async (req, res): Promise<void> => {
  if (!await isPrimarySupervisor(req.appUser!)) {
    res.status(403).json({ error: "إلغاء صلاحية الإشراف متاح للمشرف الرئيس فقط." });
    return;
  }
  const rawId = String(req.params.id);
  const id = Number(rawId);
  if (!/^[1-9]\d*$/.test(rawId) || !Number.isSafeInteger(id)) {
    res.status(400).json({ error: "رقم حساب غير صحيح." });
    return;
  }
  if (id === req.appUser!.id) {
    res.status(409).json({ error: "لا يمكن إلغاء صلاحية المشرف الرئيس." });
    return;
  }
  const result = await db.transaction(async tx => {
    const [account] = await tx.select().from(usersTable)
      .where(eq(usersTable.id, id)).limit(1).for("update");
    if (!account || account.role !== "supervisor") return null;
    const role = account.employeeId ? "employee" : "revoked";
    await tx.update(usersTable).set({ role, updatedAt: new Date() })
      .where(eq(usersTable.id, id));
    await tx.insert(auditLogsTable).values({
      userId: req.appUser!.id,
      action: "revoke_supervisor",
      entity: "user",
      entityId: id,
      details: { previousRole: "supervisor", role },
    });
    return { id, role };
  });
  if (!result) {
    res.status(404).json({ error: "حساب المشرف غير موجود أو أُلغيت صلاحياته بالفعل." });
    return;
  }
  res.json(result);
});

export default router;
