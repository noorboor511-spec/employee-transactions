import { createHash } from "node:crypto";
import type { RequestHandler } from "express";
import { Router } from "express";
import { sql, eq } from "drizzle-orm";
import type { File } from "@google-cloud/storage";
import {
  attachmentsTable,
  auditLogsTable,
  db,
  departmentsTable,
  employeesTable,
  notificationsTable,
  settingsTable,
  transactionUpdatesTable,
  transactionsTable,
  usersTable,
} from "@workspace/db";
import { ExecuteProductionCleanupBody } from "@workspace/api-zod";
import type {
  ProductionCleanupCounts,
  ProductionCleanupInput,
  ProductionCleanupPreview,
  ProductionCleanupResult,
} from "@workspace/api-zod";
import { requireAppUser } from "../lib/auth";
import { ObjectStorageService } from "../lib/objectStorage";
import {
  hasExactCleanupConfirmation,
  isProductionCleanupEnabled,
  isSafePrivateUploadPath,
} from "../lib/production-cleanup-guards";

const router = Router();
const PRIMARY_SUPERVISOR_KEY = "primary_supervisor_id";
const storage = new ObjectStorageService();
const CONFIRMATION_MESSAGE = "لا يمكن التنفيذ قبل إعادة تحميل الملخص ومراجعة الأعداد.";

type QueryExecutor = Pick<typeof db, "select">;
type PrimaryUser = typeof usersTable.$inferSelect;
type AttachmentRow = typeof attachmentsTable.$inferSelect;
type DepartmentRow = typeof departmentsTable.$inferSelect;
type SettingRow = typeof settingsTable.$inferSelect;

interface CleanupSnapshot {
  primaryId: number;
  primary: PrimaryUser;
  counts: ProductionCleanupCounts;
  attachments: AttachmentRow[];
  departments: DepartmentRow[];
  settings: SettingRow[];
  fingerprint: string;
}

interface VerifiedStorageObject {
  file: File;
  objectPath: string;
  attachmentIds: number[];
}

interface StorageInspection {
  objects: VerifiedStorageObject[];
  issue: string | null;
}

class CleanupBlockedError extends Error {}
class StalePreviewError extends Error {}
class AttachmentVerificationError extends Error {}

function validPrimaryId(value: unknown): number | null {
  return typeof value === "number" && Number.isSafeInteger(value) && value > 0
    ? value
    : null;
}

function isEligiblePrimary(primary: PrimaryUser): boolean {
  return primary.role === "supervisor" &&
    typeof primary.clerkUserId === "string" &&
    primary.clerkUserId.trim().length > 0 &&
    primary.employeeId === null;
}

function primaryIdentity(primary: PrimaryUser) {
  return {
    id: primary.id,
    clerkUserId: primary.clerkUserId,
    email: primary.email,
    name: primary.name,
    role: primary.role,
    employeeId: primary.employeeId,
    createdAt: primary.createdAt.toISOString(),
    updatedAt: primary.updatedAt.toISOString(),
  };
}

function stableRows<T extends { createdAt?: Date; updatedAt?: Date }>(rows: T[]) {
  return rows.map((row) => ({
    ...row,
    ...(row.createdAt instanceof Date ? { createdAt: row.createdAt.toISOString() } : {}),
    ...(row.updatedAt instanceof Date ? { updatedAt: row.updatedAt.toISOString() } : {}),
  }));
}

async function readCleanupSnapshot(executor: QueryExecutor): Promise<CleanupSnapshot> {
  const [pinned] = await executor
    .select({ value: settingsTable.value })
    .from(settingsTable)
    .where(eq(settingsTable.key, PRIMARY_SUPERVISOR_KEY))
    .limit(1);
  const primaryId = validPrimaryId(pinned?.value);
  if (!primaryId) {
    throw new CleanupBlockedError("لا يمكن التحقق من المشرف الرئيس المثبت.");
  }

  const [primary] = await executor
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, primaryId))
    .limit(1);
  if (!primary || !isEligiblePrimary(primary)) {
    throw new CleanupBlockedError("حساب المشرف الرئيس غير صالح أو مرتبط بسجل موظف.");
  }

  const [rawCounts] = await executor
    .select({
      accountsToDelete: sql<number>`(SELECT count(*)::int FROM public.users WHERE id <> ${primaryId})`,
      employeeAccountsToDelete: sql<number>`(SELECT count(*)::int FROM public.users WHERE id <> ${primaryId} AND role = 'employee')`,
      additionalSupervisorsToDelete: sql<number>`(SELECT count(*)::int FROM public.users WHERE id <> ${primaryId} AND role = 'supervisor')`,
      employeesToDelete: sql<number>`(SELECT count(*)::int FROM public.employees)`,
      transactionsToDelete: sql<number>`(SELECT count(*)::int FROM public.employee_transactions)`,
      updatesToDelete: sql<number>`(SELECT count(*)::int FROM public.transaction_updates)`,
      attachmentsToDelete: sql<number>`(SELECT count(*)::int FROM public.attachments)`,
      notificationsToDelete: sql<number>`(SELECT count(*)::int FROM public.notifications)`,
      auditLogsToDelete: sql<number>`(SELECT count(*)::int FROM public.audit_logs)`,
      departmentsToPreserve: sql<number>`(SELECT count(*)::int FROM public.departments)`,
      settingsToPreserve: sql<number>`(SELECT count(*)::int FROM public.settings)`,
      storageFilesToDelete: sql<number>`(SELECT count(DISTINCT object_path)::int FROM public.attachments)`,
    })
    .from(usersTable)
    .limit(1);

  const counts: ProductionCleanupCounts = {
    accountsToDelete: Number(rawCounts.accountsToDelete),
    employeeAccountsToDelete: Number(rawCounts.employeeAccountsToDelete),
    additionalSupervisorsToDelete: Number(rawCounts.additionalSupervisorsToDelete),
    employeesToDelete: Number(rawCounts.employeesToDelete),
    transactionsToDelete: Number(rawCounts.transactionsToDelete),
    updatesToDelete: Number(rawCounts.updatesToDelete),
    attachmentsToDelete: Number(rawCounts.attachmentsToDelete),
    notificationsToDelete: Number(rawCounts.notificationsToDelete),
    auditLogsToDelete: Number(rawCounts.auditLogsToDelete),
    departmentsToPreserve: Number(rawCounts.departmentsToPreserve),
    settingsToPreserve: Number(rawCounts.settingsToPreserve),
    storageFilesToDelete: Number(rawCounts.storageFilesToDelete),
  };

  const attachments = await executor
    .select()
    .from(attachmentsTable)
    .orderBy(attachmentsTable.id);
  const departments = await executor
    .select()
    .from(departmentsTable)
    .orderBy(departmentsTable.id);
  const settings = await executor
    .select()
    .from(settingsTable)
    .orderBy(settingsTable.key);

  const fingerprintPayload = JSON.stringify({
    primary: primaryIdentity(primary),
    counts,
    attachments: stableRows(attachments),
    departments: stableRows(departments),
    settings: stableRows(settings),
  });
  const fingerprint = createHash("sha256").update(fingerprintPayload).digest("hex");

  return { primaryId, primary, counts, attachments, departments, settings, fingerprint };
}

async function inspectStorageObjects(
  attachmentRows: AttachmentRow[],
  logVerificationFailure: (attachmentId: number) => void,
): Promise<StorageInspection> {
  const rowsByPath = new Map<string, AttachmentRow[]>();
  for (const row of attachmentRows) {
    const group = rowsByPath.get(row.objectPath) ?? [];
    group.push(row);
    rowsByPath.set(row.objectPath, group);
  }

  const objects: VerifiedStorageObject[] = [];
  for (const [objectPath, rows] of rowsByPath) {
    if (!isSafePrivateUploadPath(objectPath)) {
      logVerificationFailure(rows[0].id);
      return { objects, issue: "تعذر التحقق من مسار ملف مرفق واحد أو أكثر." };
    }

    try {
      const file = await storage.getObjectEntityFile(objectPath);
      const [metadata] = await file.getMetadata();
      const actualSize = Number(metadata.size);
      const actualContentType = String(metadata.contentType ?? "").trim().toLowerCase();
      const matchesEveryRecord = rows.every((row) =>
        Number.isSafeInteger(row.size) &&
        row.size > 0 &&
        actualSize === row.size &&
        actualContentType === row.contentType.trim().toLowerCase()
      );
      if (!matchesEveryRecord) {
        logVerificationFailure(rows[0].id);
        return { objects, issue: "لا تتطابق بيانات ملف التخزين مع سجل المرفق." };
      }

      objects.push({
        file,
        objectPath,
        attachmentIds: rows.map((row) => row.id),
      });
    } catch {
      logVerificationFailure(rows[0].id);
      return { objects, issue: "تعذر التحقق من وجود ملف مرفق أو بياناته." };
    }
  }

  return { objects, issue: null };
}

function preserveCountsAreExpected(counts: ProductionCleanupCounts): boolean {
  return counts.departmentsToPreserve === 5 && counts.settingsToPreserve === 3;
}

function previewResponse(
  snapshot: CleanupSnapshot,
  storageInspection: StorageInspection,
): ProductionCleanupPreview {
  const storageObjectsVerified = storageInspection.objects.length;
  const canExecute =
    isEligiblePrimary(snapshot.primary) &&
    preserveCountsAreExpected(snapshot.counts) &&
    storageInspection.issue === null &&
    storageObjectsVerified === snapshot.counts.storageFilesToDelete;

  let message = "الأعداد جاهزة للمراجعة. لن يحدث حذف قبل كتابة عبارة التأكيد والضغط على الزر.";
  if (!preserveCountsAreExpected(snapshot.counts)) {
    message = "توقف الإجراء: يجب أن تكون الأقسام خمسة وإعدادات النظام ثلاثة.";
  } else if (storageInspection.issue) {
    message = storageInspection.issue;
  } else if (storageObjectsVerified !== snapshot.counts.storageFilesToDelete) {
    message = "توقف الإجراء: لم يكتمل التحقق من جميع ملفات App Storage.";
  }

  return {
    counts: snapshot.counts,
    fingerprint: snapshot.fingerprint,
    storageObjectsVerified,
    storageObjectsTotal: snapshot.counts.storageFilesToDelete,
    canExecute,
    message,
  };
}

const productionOnly: RequestHandler = (_req, res, next) => {
  if (!isProductionCleanupEnabled(process.env.NODE_ENV)) {
    res.status(404).json({ error: "هذه الأداة غير متاحة في هذه البيئة." });
    return;
  }
  next();
};

const primarySupervisorOnly: RequestHandler = async (req, res, next) => {
  try {
    if (!req.appUser || req.appUser.role !== "supervisor") {
      res.status(403).json({ error: "هذه الأداة متاحة للمشرف الرئيس فقط." });
      return;
    }
    const [pinned] = await db
      .select({ value: settingsTable.value })
      .from(settingsTable)
      .where(eq(settingsTable.key, PRIMARY_SUPERVISOR_KEY))
      .limit(1);
    if (validPrimaryId(pinned?.value) !== req.appUser.id) {
      res.status(403).json({ error: "هذه الأداة متاحة للمشرف الرئيس فقط." });
      return;
    }
    next();
  } catch {
    req.log.error("Could not verify primary supervisor for production cleanup");
    res.status(500).json({ error: "تعذر التحقق من صلاحية المشرف الرئيس." });
  }
};

function requestIsSameOrigin(req: Parameters<RequestHandler>[0]): boolean {
  const originValue = req.get("origin");
  if (!originValue) return false;
  try {
    const origin = new URL(originValue);
    const allowedHosts = new Set(
      [
        req.get("host") ?? "",
        process.env.REPLIT_DOMAINS ?? "",
      ]
        .flatMap((value) => value.split(","))
        .map((host) => host.trim().toLowerCase())
        .filter(Boolean),
    );
    return origin.protocol === "https:" &&
      allowedHosts.has(origin.host.toLowerCase());
  } catch {
    return false;
  }
}

router.get(
  "/production-cleanup/preview",
  productionOnly,
  requireAppUser,
  primarySupervisorOnly,
  async (req, res): Promise<void> => {
  try {
    const snapshot = await readCleanupSnapshot(db);
    const storageInspection = await inspectStorageObjects(
      snapshot.attachments,
      (attachmentId) => req.log.warn({ attachmentId }, "Attachment storage preflight failed"),
    );
    res.json(previewResponse(snapshot, storageInspection));
  } catch (error) {
    if (error instanceof CleanupBlockedError) {
      res.status(409).json({ error: error.message });
      return;
    }
    req.log.error("Could not build production cleanup preview");
    res.status(500).json({ error: "تعذر إعداد معاينة التنظيف." });
  }
  },
);

router.post(
  "/production-cleanup/execute",
  productionOnly,
  requireAppUser,
  primarySupervisorOnly,
  async (req, res): Promise<void> => {
  if (!requestIsSameOrigin(req)) {
    res.status(403).json({ error: "يجب تنفيذ الطلب من الموقع نفسه." });
    return;
  }

  const parsed = ExecuteProductionCleanupBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "بيانات التأكيد غير صالحة." });
    return;
  }
  const input: ProductionCleanupInput = parsed.data;
  if (!hasExactCleanupConfirmation(input.confirmation)) {
    res.status(400).json({ error: CONFIRMATION_MESSAGE });
    return;
  }

  try {
    const committed = await db.transaction(async (tx) => {
      await tx.execute(sql`SET LOCAL lock_timeout = '5s'`);
      await tx.execute(sql`SET LOCAL statement_timeout = '60s'`);
      await tx.execute(sql`
        LOCK TABLE
          public.settings,
          public.departments,
          public.users,
          public.employees,
          public.employee_transactions,
          public.transaction_updates,
          public.attachments,
          public.notifications,
          public.audit_logs
        IN SHARE ROW EXCLUSIVE MODE
      `);

      const before = await readCleanupSnapshot(tx);
      if (before.primaryId !== req.appUser!.id || before.fingerprint !== input.fingerprint) {
        throw new StalePreviewError("أُضيفت تغييرات منذ عرض الملخص. أعد تحميله قبل التأكيد.");
      }
      if (!isEligiblePrimary(before.primary) || !preserveCountsAreExpected(before.counts)) {
        throw new CleanupBlockedError("تعذر التحقق من الحساب أو بيانات النظام المطلوب الاحتفاظ بها.");
      }

      const storageInspection = await inspectStorageObjects(
        before.attachments,
        (attachmentId) => req.log.warn({ attachmentId }, "Attachment storage preflight failed"),
      );
      if (storageInspection.issue ||
        storageInspection.objects.length !== before.counts.storageFilesToDelete) {
        throw new AttachmentVerificationError(
          storageInspection.issue ?? "لم يكتمل التحقق من ملفات التخزين.",
        );
      }

      await tx.delete(attachmentsTable);
      await tx.delete(transactionUpdatesTable);
      await tx.delete(notificationsTable);
      await tx.delete(transactionsTable);
      await tx.delete(auditLogsTable);
      await tx.delete(usersTable).where(sql`${usersTable.id} <> ${before.primaryId}`);
      await tx.delete(employeesTable);

      const after = await readCleanupSnapshot(tx);
      const zerosConfirmed =
        after.counts.accountsToDelete === 0 &&
        after.counts.employeeAccountsToDelete === 0 &&
        after.counts.additionalSupervisorsToDelete === 0 &&
        after.counts.employeesToDelete === 0 &&
        after.counts.transactionsToDelete === 0 &&
        after.counts.updatesToDelete === 0 &&
        after.counts.attachmentsToDelete === 0 &&
        after.counts.notificationsToDelete === 0 &&
        after.counts.auditLogsToDelete === 0 &&
        after.counts.storageFilesToDelete === 0;
      if (!zerosConfirmed || !preserveCountsAreExpected(after.counts)) {
        throw new CleanupBlockedError("فشل التحقق من الأعداد داخل المعاملة؛ تم إلغاء التغييرات.");
      }

      const [primaryAfter] = await tx
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, before.primaryId))
        .limit(1);
      if (!primaryAfter ||
        JSON.stringify(primaryIdentity(primaryAfter)) !== JSON.stringify(primaryIdentity(before.primary)) ||
        JSON.stringify(stableRows(after.departments)) !== JSON.stringify(stableRows(before.departments)) ||
        JSON.stringify(stableRows(after.settings)) !== JSON.stringify(stableRows(before.settings))) {
        throw new CleanupBlockedError("تعذر تأكيد بقاء حساب المشرف والإعدادات والأقسام كما هي.");
      }

      return {
        countsAfter: after.counts,
        objects: storageInspection.objects,
      };
    });

    const pendingStorageObjects: ProductionCleanupResult["pendingStorageObjects"] = [];
    let storageDeleted = 0;
    for (const object of committed.objects) {
      try {
        await object.file.delete({ ignoreNotFound: true });
        const [stillExists] = await object.file.exists();
        if (stillExists) throw new Error("Object remains after deletion");
        storageDeleted += 1;
      } catch {
        pendingStorageObjects.push({
          attachmentIds: object.attachmentIds,
          objectPath: object.objectPath,
        });
        req.log.warn(
          { attachmentIds: object.attachmentIds },
          "Database cleanup committed but an attachment object remains",
        );
      }
    }

    const result: ProductionCleanupResult = {
      databaseCommitted: true,
      countsAfter: committed.countsAfter,
      storageDeleted,
      storagePending: pendingStorageObjects.length,
      pendingStorageObjects,
    };
    res.json(result);
  } catch (error) {
    if (error instanceof StalePreviewError) {
      res.status(409).json({ error: error.message });
      return;
    }
    if (error instanceof AttachmentVerificationError) {
      res.status(409).json({ error: error.message });
      return;
    }
    if (error instanceof CleanupBlockedError) {
      res.status(409).json({ error: error.message });
      return;
    }
    req.log.error("Production cleanup could not be confirmed");
    res.status(500).json({
      error: "تعذر تأكيد اكتمال التنظيف. أعد تحميل الملخص قبل أي محاولة أخرى.",
    });
  }
  },
);

export default router;
