import { Router, type IRouter, type Request } from "express";
import { and, eq, gte, inArray, isNull, lt, or, type SQL } from "drizzle-orm";
import {
  AddTransactionUpdateBody,
  CreateEmployeeBody,
  CreateTransactionBody,
  GetCurrentUserResponse,
  GetDashboardResponse,
  GetDepartmentsResponse,
  GetEmployeesResponse,
  GetNotificationsResponse,
  GetReportsQueryParams,
  GetReportsResponse,
  GetSettingsResponse,
  GetStorageObjectParams,
  GetTransactionParams,
  GetTransactionResponse,
  GetTransactionsQueryParams,
  GetTransactionsResponse,
  MarkNotificationReadParams,
  MarkNotificationReadResponse,
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
  UpdateEmployeeBody,
  UpdateEmployeeParams,
  UpdateEmployeeResponse,
  UpdateSettingsBody,
  UpdateSettingsResponse,
  UpdateTransactionBody,
  UpdateTransactionParams,
  UpdateTransactionResponse,
} from "@workspace/api-zod";
import {
  attachmentsTable,
  db,
  departmentsTable,
  employeesTable,
  notificationsTable,
  settingsTable,
  transactionUpdatesTable,
  transactionsTable,
  usersTable,
} from "@workspace/db";
import { ObjectStorageService } from "../lib/objectStorage";
import { requireAppUser, supervisorOnly, writeAudit } from "../lib/auth";
import { canEditFooterCredit } from "../lib/footer-permissions";
import { classifyFollowUp } from "../lib/follow-up";
import { ensureFollowUpAlerts } from "../lib/follow-up-alerts";
import { createEmployeeAccount, updateEmployeeAccount, normalizeEmployeeInput, isUniqueViolation } from "../lib/employee-accounts";

const router: IRouter = Router();
const storage = new ObjectStorageService();
const FOLLOW_UP_DAYS_KEY = "followUpDays";
const STATUSES_KEY = "statuses";
const DEFAULT_FOLLOW_UP_DAYS = 3;
const DEFAULT_STATUSES = [
  "جديدة",
  "تحت الإجراء",
  "لدى الإدارة",
  "بانتظار مستند",
  "بانتظار رد",
  "متوقفة",
  "متأخرة",
  "مكتملة",
];
const COMPLETED_STATUS = "مكتملة";
const MAX_FILE_SIZE = 20 * 1024 * 1024;
const ALLOWED_FILE_TYPES = new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/webp",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
]);

type JoinedTransaction = {
  transaction: typeof transactionsTable.$inferSelect;
  employeeName: string;
  departmentName: string;
};

function riyadhDate(date: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function asIso(date: Date | null): string | null {
  return date ? date.toISOString() : null;
}

function validDate(value: string | Date): Date | null {
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function isTrue(value: unknown): boolean {
  return value === true || value === "true" || value === "1";
}

async function getSettingsValue(): Promise<{
  followUpDays: number;
  statuses: string[];
}> {
  const rows = await db
    .select()
    .from(settingsTable)
    .where(inArray(settingsTable.key, [FOLLOW_UP_DAYS_KEY, STATUSES_KEY]));
  const days = rows.find((row) => row.key === FOLLOW_UP_DAYS_KEY)?.value;
  const statuses = rows.find((row) => row.key === STATUSES_KEY)?.value;
  return {
    followUpDays:
      typeof days === "number" && days > 0 ? days : DEFAULT_FOLLOW_UP_DAYS,
    statuses:
      Array.isArray(statuses) &&
      statuses.every((value) => typeof value === "string")
        ? statuses
        : DEFAULT_STATUSES,
  };
}

function toTransaction(row: JoinedTransaction, followUpDays: number) {
  return {
    id: row.transaction.id,
    number: row.transaction.number,
    subject: row.transaction.subject,
    employeeId: row.transaction.employeeId,
    employeeName: row.employeeName,
    departmentId: row.transaction.departmentId,
    departmentName: row.departmentName,
    type: row.transaction.type,
    receivedAt: row.transaction.receivedAt.toISOString(),
    currentEntity: row.transaction.currentEntity,
    status: row.transaction.status,
    priority: row.transaction.priority as "normal" | "important" | "urgent",
    lastUpdatedAt: asIso(row.transaction.lastUpdatedAt),
    nextFollowUpAt: asIso(row.transaction.nextFollowUpAt),
    notes: row.transaction.notes,
    createdAt: row.transaction.createdAt.toISOString(),
    ...classifyFollowUp(row.transaction, followUpDays),
  };
}

async function getVisibleTransactions(
  req: Request,
): Promise<Awaited<ReturnType<typeof toTransaction>>[]> {
  const conditions: SQL[] = [];
  if (req.appUser?.role === "employee") {
    if (!req.appUser.employeeId) return [];
    conditions.push(eq(transactionsTable.employeeId, req.appUser.employeeId));
  }
  const rows = (await db
    .select({
      transaction: transactionsTable,
      employeeName: employeesTable.name,
      departmentName: departmentsTable.name,
    })
    .from(transactionsTable)
    .innerJoin(
      employeesTable,
      eq(transactionsTable.employeeId, employeesTable.id),
    )
    .innerJoin(
      departmentsTable,
      eq(transactionsTable.departmentId, departmentsTable.id),
    )
    .where(and(...conditions))) as JoinedTransaction[];
  const { followUpDays } = await getSettingsValue();
  return rows.map((row) => toTransaction(row, followUpDays));
}

function filterTransactions(
  transactions: Awaited<ReturnType<typeof getVisibleTransactions>>,
  query: Record<string, unknown>,
) {
  const search = String(query.search ?? "").trim().toLocaleLowerCase("ar");
  const from = typeof query.from === "string" ? query.from : "";
  const to = typeof query.to === "string" ? query.to : "";
  return transactions.filter((transaction) => {
    if (
      search &&
      ![
        transaction.number,
        transaction.subject,
        transaction.employeeName,
        transaction.currentEntity,
      ].some((value) => value.toLocaleLowerCase("ar").includes(search))
    ) {
      return false;
    }
    if (query.status && transaction.status !== query.status) return false;
    if (query.priority && transaction.priority !== query.priority) return false;
    if (
      query.employeeId &&
      transaction.employeeId !== Number(query.employeeId)
    ) {
      return false;
    }
    if (
      query.departmentId &&
      transaction.departmentId !== Number(query.departmentId)
    ) {
      return false;
    }
    if (isTrue(query.overdue) && !transaction.overdue) return false;
    if (isTrue(query.needsFollowUp) && !transaction.needsFollowUp) return false;
    if (isTrue(query.followUpMissed) && !transaction.followUpMissed) return false;
    if (isTrue(query.recentlyUpdated) && !transaction.recentlyUpdated) return false;
    if (
      isTrue(query.inProgress) &&
      (transaction.status === "جديدة" || transaction.status === COMPLETED_STATUS)
    ) {
      return false;
    }
    if (
      isTrue(query.followUpToday) &&
      !transaction.followUpToday
    ) {
      return false;
    }
    const receivedDate = transaction.receivedAt.slice(0, 10);
    if (from && receivedDate < from) return false;
    if (to && receivedDate > to) return false;
    return true;
  });
}

async function getEmployeeResponse(employeeId: number) {
  const [employee] = await db
    .select({
      id: employeesTable.id,
      name: employeesTable.name,
      email: employeesTable.email,
      departmentId: employeesTable.departmentId,
      departmentName: departmentsTable.name,
      active: employeesTable.active,
    })
    .from(employeesTable)
    .innerJoin(
      departmentsTable,
      eq(employeesTable.departmentId, departmentsTable.id),
    )
    .where(eq(employeesTable.id, employeeId))
    .limit(1);
  if (!employee) return null;

  const transactionRows = await db
    .select({
      status: transactionsTable.status,
      updatedAt: transactionsTable.lastUpdatedAt,
      nextFollowUpAt: transactionsTable.nextFollowUpAt,
    })
    .from(transactionsTable)
    .where(eq(transactionsTable.employeeId, employeeId));
  const completed = transactionRows.filter(
    (row) => row.status === COMPLETED_STATUS,
  ).length;
  const latest = transactionRows
    .map((row) => row.updatedAt)
    .filter((value): value is Date => Boolean(value))
    .sort((a, b) => b.getTime() - a.getTime())[0];
  return {
    ...employee,
    total: transactionRows.length,
    open: transactionRows.length - completed,
    completed,
    overdue: transactionRows.filter(
      (row) =>
        row.status === "متأخرة" ||
        (row.status !== COMPLETED_STATUS &&
          row.nextFollowUpAt !== null &&
          row.nextFollowUpAt.getTime() < Date.now()),
    ).length,
    lastUpdatedAt: asIso(latest ?? null),
  };
}

router.use(requireAppUser);

router.get("/auth/me", async (req, res): Promise<void> => {
  const user = req.appUser!;
  let departmentName: string | null = null;
  if (user.employeeId) {
    const [row] = await db
      .select({ name: departmentsTable.name })
      .from(employeesTable)
      .innerJoin(
        departmentsTable,
        eq(employeesTable.departmentId, departmentsTable.id),
      )
      .where(eq(employeesTable.id, user.employeeId))
      .limit(1);
    departmentName = row?.name ?? null;
  }
  const primarySupervisor = await canEditFooterCredit(user);
  res.json(
    GetCurrentUserResponse.parse({
      id: user.id,
      name: user.name,
      email: user.email ?? "",
      role: user.role,
      canEditFooterCredit: primarySupervisor,
      canRevokeSupervisors: primarySupervisor,
      employeeId: user.employeeId,
      departmentName,
    }),
  );
});

router.get("/transactions", async (req, res): Promise<void> => {
  const parsed = GetTransactionsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const visible = await getVisibleTransactions(req);
  res.json(
    GetTransactionsResponse.parse(
      filterTransactions(visible, parsed.data as Record<string, unknown>),
    ),
  );
});

router.post("/transactions", supervisorOnly, async (req, res): Promise<void> => {
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const body = parsed.data;
  const receivedAt = validDate(body.receivedAt);
  if (!receivedAt) {
    res.status(400).json({ error: "تاريخ الاستلام غير صالح" });
    return;
  }
  const [employee] = await db
    .select()
    .from(employeesTable)
    .where(eq(employeesTable.id, body.employeeId))
    .limit(1);
  if (
    !employee?.active ||
    employee.departmentId !== body.departmentId
  ) {
    res.status(400).json({ error: "تحقق من الموظف والقسم المحددين" });
    return;
  }
  const settings = await getSettingsValue();
  if (!settings.statuses.includes(body.status)) {
    res.status(400).json({ error: "الحالة المحددة غير موجودة في إعدادات النظام" });
    return;
  }
  const nextFollowUpAt = body.nextFollowUpAt
    ? validDate(body.nextFollowUpAt)
    : null;
  if (body.nextFollowUpAt && !nextFollowUpAt) {
    res.status(400).json({ error: "موعد المتابعة غير صالح" });
    return;
  }

  const created = await db.transaction(async (tx) => {
    const [transaction] = await tx
      .insert(transactionsTable)
      .values({
        number: body.number.trim(),
        subject: body.subject.trim(),
        employeeId: body.employeeId,
        departmentId: body.departmentId,
        type: body.type.trim(),
        receivedAt,
        currentEntity: body.currentEntity.trim(),
        status: body.status,
        priority: body.priority,
        nextFollowUpAt,
        notes: body.notes ?? "",
        lastUpdatedAt: new Date(),
      })
      .returning();
    await tx.insert(transactionUpdatesTable).values({
      transactionId: transaction.id,
      authorUserId: req.appUser!.id,
      previousStatus: null,
      newStatus: body.status,
      action: "تم إنشاء المعاملة وإسنادها",
      notes: body.notes ?? "",
    });
    const [employeeUser] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.employeeId, employee.id))
      .limit(1);
    if (employeeUser) {
      await tx.insert(notificationsTable).values({
        userId: employeeUser.id,
        type: "assigned",
        message: `أُسندت إليك المعاملة ${body.number}`,
        transactionId: transaction.id,
      });
    }
    return transaction;
  });
  await writeAudit(req.appUser!.id, "create", "transaction", created.id, {
    number: created.number,
    employeeId: created.employeeId,
  });
  const visible = await getVisibleTransactions(req);
  const [result] = visible.filter((transaction) => transaction.id === created.id);
  res.status(201).json(GetTransactionsResponse.element.parse(result));
});

router.get("/transactions/:id", async (req, res): Promise<void> => {
  const params = GetTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const visible = await getVisibleTransactions(req);
  const [transaction] = visible.filter((item) => item.id === params.data.id);
  if (!transaction) {
    res.status(404).json({ error: "المعاملة غير موجودة أو لا تملك صلاحية عرضها" });
    return;
  }
  const updates = await db
    .select({
      id: transactionUpdatesTable.id,
      transactionId: transactionUpdatesTable.transactionId,
      createdAt: transactionUpdatesTable.createdAt,
      employeeName: usersTable.name,
      previousStatus: transactionUpdatesTable.previousStatus,
      newStatus: transactionUpdatesTable.newStatus,
      action: transactionUpdatesTable.action,
      notes: transactionUpdatesTable.notes,
    })
    .from(transactionUpdatesTable)
    .innerJoin(
      usersTable,
      eq(transactionUpdatesTable.authorUserId, usersTable.id),
    )
    .where(eq(transactionUpdatesTable.transactionId, transaction.id))
    .orderBy(transactionUpdatesTable.createdAt);
  const updateIds = updates.map((update) => update.id);
  const attachmentRows = updateIds.length
    ? await db
        .select()
        .from(attachmentsTable)
        .where(inArray(attachmentsTable.transactionUpdateId, updateIds))
    : [];
  const detail = {
    ...transaction,
    updates: updates.map((update) => ({
      ...update,
      createdAt: update.createdAt.toISOString(),
      attachments: attachmentRows
        .filter((attachment) => attachment.transactionUpdateId === update.id)
        .map((attachment) => ({
          id: attachment.id,
          fileName: attachment.fileName,
          objectPath: attachment.objectPath,
          contentType: attachment.contentType,
          size: attachment.size,
        })),
    })),
  };
  res.json(GetTransactionResponse.parse(detail));
});

router.patch("/transactions/:id", supervisorOnly, async (req, res): Promise<void> => {
  const params = UpdateTransactionParams.safeParse(req.params);
  const parsed = UpdateTransactionBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: !params.success
        ? params.error.message
        : !parsed.success
          ? parsed.error.message
          : "بيانات غير صالحة",
    });
    return;
  }
  const id = params.data.id;
  const body = parsed.data;
  const receivedAt = validDate(body.receivedAt);
  if (!receivedAt) {
    res.status(400).json({ error: "تاريخ الاستلام غير صالح" });
    return;
  }
  const [previous] = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.id, id))
    .limit(1);
  if (!previous) {
    res.status(404).json({ error: "المعاملة غير موجودة" });
    return;
  }
  const [employee] = await db
    .select()
    .from(employeesTable)
    .where(eq(employeesTable.id, body.employeeId))
    .limit(1);
  const statuses = (await getSettingsValue()).statuses;
  if (
    !employee?.active ||
    employee.departmentId !== body.departmentId ||
    !statuses.includes(body.status)
  ) {
    res.status(400).json({ error: "تحقق من الموظف والقسم والحالة المحددين" });
    return;
  }
  const nextFollowUpAt = body.nextFollowUpAt
    ? validDate(body.nextFollowUpAt)
    : null;
  if (body.nextFollowUpAt && !nextFollowUpAt) {
    res.status(400).json({ error: "موعد المتابعة غير صالح" });
    return;
  }
  const [updated] = await db
    .update(transactionsTable)
    .set({
      number: body.number.trim(),
      subject: body.subject.trim(),
      employeeId: body.employeeId,
      departmentId: body.departmentId,
      type: body.type.trim(),
      receivedAt,
      currentEntity: body.currentEntity.trim(),
      status: body.status,
      priority: body.priority,
      nextFollowUpAt,
      notes: body.notes ?? "",
    })
    .where(eq(transactionsTable.id, id))
    .returning();

  if (previous.status !== updated.status) {
    await db.insert(transactionUpdatesTable).values({
      transactionId: updated.id,
      authorUserId: req.appUser!.id,
      previousStatus: previous.status,
      newStatus: updated.status,
      action: "عدّل المشرف بيانات المعاملة",
      notes: updated.notes,
    });
  }
  if (previous.employeeId !== updated.employeeId) {
    const [newOwner] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.employeeId, updated.employeeId))
      .limit(1);
    if (newOwner) {
      await db.insert(notificationsTable).values({
        userId: newOwner.id,
        type: "assigned",
        message: `أُسندت إليك المعاملة ${updated.number}`,
        transactionId: updated.id,
      });
    }
  }
  await writeAudit(req.appUser!.id, "update", "transaction", updated.id, {
    changedStatus: previous.status !== updated.status,
    oldEmployeeId: previous.employeeId,
    employeeId: updated.employeeId,
  });
  const visible = await getVisibleTransactions(req);
  const [result] = visible.filter((item) => item.id === updated.id);
  res.json(UpdateTransactionResponse.parse(result));
});

router.post("/transactions/:id/updates", async (req, res): Promise<void> => {
  const params = GetTransactionParams.safeParse(req.params);
  const parsed = AddTransactionUpdateBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: !params.success
        ? params.error.message
        : !parsed.success
          ? parsed.error.message
          : "بيانات غير صالحة",
    });
    return;
  }
  const id = params.data.id;
  const body = parsed.data;
  const [current] = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.id, id))
    .limit(1);
  if (
    !current ||
    (req.appUser!.role === "employee" &&
      current.employeeId !== req.appUser!.employeeId)
  ) {
    res.status(404).json({ error: "المعاملة غير موجودة أو لا تملك صلاحية تحديثها" });
    return;
  }
  const { statuses } = await getSettingsValue();
  if (!statuses.includes(body.status)) {
    res.status(400).json({ error: "الحالة المحددة غير موجودة في إعدادات النظام" });
    return;
  }
  const nextFollowUpAt = body.nextFollowUpAt
    ? validDate(body.nextFollowUpAt)
    : null;
  if (body.nextFollowUpAt && !nextFollowUpAt) {
    res.status(400).json({ error: "موعد المتابعة غير صالح" });
    return;
  }
  const attachments = body.attachments ?? [];
  const uniquePaths = [...new Set(attachments.map((item) => item.objectPath))];
  if (uniquePaths.length !== attachments.length) {
    res.status(400).json({ error: "يوجد مرفق مكرر" });
    return;
  }
  const pendingAttachments = uniquePaths.length
    ? await db
        .select()
        .from(attachmentsTable)
        .where(
          and(
            inArray(attachmentsTable.objectPath, uniquePaths),
            eq(attachmentsTable.uploadedBy, req.appUser!.id),
            isNull(attachmentsTable.transactionUpdateId),
          ),
        )
    : [];
  const allUploadsVerified = attachments.every((item) => {
    const saved = pendingAttachments.find(
      (attachment) => attachment.objectPath === item.objectPath,
    );
    return (
      saved &&
      saved.fileName === item.fileName &&
      saved.contentType === item.contentType &&
      saved.size === item.size
    );
  });
  if (!allUploadsVerified) {
    res.status(400).json({ error: "تعذر التحقق من ملكية أحد المرفقات" });
    return;
  }

  const update = await db.transaction(async (tx) => {
    const [created] = await tx
      .insert(transactionUpdatesTable)
      .values({
        transactionId: current.id,
        authorUserId: req.appUser!.id,
        previousStatus: current.status,
        newStatus: body.status,
        action: body.action.trim(),
        notes: body.notes ?? "",
      })
      .returning();
    await tx
      .update(transactionsTable)
      .set({
        status: body.status,
        lastUpdatedAt: created.createdAt,
        nextFollowUpAt:
          body.nextFollowUpAt === undefined
            ? current.nextFollowUpAt
            : nextFollowUpAt,
        notes: body.notes ?? current.notes,
      })
      .where(eq(transactionsTable.id, current.id));
    if (uniquePaths.length) {
      await tx
        .update(attachmentsTable)
        .set({ transactionUpdateId: created.id })
        .where(
          and(
            inArray(attachmentsTable.objectPath, uniquePaths),
            eq(attachmentsTable.uploadedBy, req.appUser!.id),
            isNull(attachmentsTable.transactionUpdateId),
          ),
        );
    }
    if (req.appUser!.role === "employee") {
      const supervisors = await tx
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(eq(usersTable.role, "supervisor"));
      if (supervisors.length) {
        await tx.insert(notificationsTable).values(
          supervisors.map((user) => ({
            userId: user.id,
            type: "transaction_updated",
            message: `حدّث ${req.appUser!.name} المعاملة ${current.number}`,
            transactionId: current.id,
          })),
        );
      }
    }
    return created;
  });
  await writeAudit(req.appUser!.id, "add_update", "transaction", current.id, {
    newStatus: body.status,
    attachments: attachments.length,
  });
  const attached = uniquePaths.length
    ? await db
        .select()
        .from(attachmentsTable)
        .where(eq(attachmentsTable.transactionUpdateId, update.id))
    : [];
  res.status(201).json({
    id: update.id,
    transactionId: update.transactionId,
    createdAt: update.createdAt.toISOString(),
    employeeName: req.appUser!.name,
    previousStatus: update.previousStatus,
    newStatus: update.newStatus,
    action: update.action,
    notes: update.notes,
    attachments: attached.map((attachment) => ({
      id: attachment.id,
      fileName: attachment.fileName,
      objectPath: attachment.objectPath,
      contentType: attachment.contentType,
      size: attachment.size,
    })),
  });
});

router.get("/dashboard", async (req, res): Promise<void> => {
  const transactions = await getVisibleTransactions(req);
  const dashboard = {
    total: transactions.length,
    new: transactions.filter((item) => item.status === "جديدة").length,
    inProgress: transactions.filter(
      (item) => item.status !== "جديدة" && item.status !== COMPLETED_STATUS,
    ).length,
    completed: transactions.filter(
      (item) => item.status === COMPLETED_STATUS,
    ).length,
    overdue: transactions.filter((item) => item.overdue).length,
    needsFollowUp: transactions.filter((item) => item.needsFollowUp).length,
    followUpToday: transactions.filter((item) => item.followUpToday).length,
    followUpMissed: transactions.filter((item) => item.followUpMissed).length,
    recentlyUpdated: transactions.filter((item) => item.recentlyUpdated).length,
    updates: transactions.filter((item) => item.lastUpdatedAt).length,
    transactions: [...transactions]
      .sort(
        (a, b) =>
          new Date(b.lastUpdatedAt ?? b.createdAt).getTime() -
          new Date(a.lastUpdatedAt ?? a.createdAt).getTime(),
      )
      .slice(0, 12),
  };
  res.json(GetDashboardResponse.parse(dashboard));
});

router.get("/employees", supervisorOnly, async (_req, res): Promise<void> => {
  const employees = await db
    .select({ id: employeesTable.id })
    .from(employeesTable)
    .orderBy(employeesTable.name);
  const result = (
    await Promise.all(
      employees.map((employee) => getEmployeeResponse(employee.id)),
    )
  ).filter(Boolean);
  res.json(GetEmployeesResponse.parse(result));
});

router.post("/employees", supervisorOnly, async (req, res): Promise<void> => {
  const parsed = CreateEmployeeBody.safeParse(normalizeEmployeeInput(req.body));
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const body = parsed.data;
  const [department] = await db
    .select()
    .from(departmentsTable)
    .where(eq(departmentsTable.id, body.departmentId))
    .limit(1);
  if (!department) {
    res.status(400).json({ error: "القسم المحدد غير موجود" });
    return;
  }
  try {
    const employee = await createEmployeeAccount(body, req.appUser!.id);
    res.status(201).json(
      GetEmployeesResponse.element.parse(
        await getEmployeeResponse(employee.id),
      ),
    );
  } catch (error) {
    if (isUniqueViolation(error)) {
      res.status(409).json({ error: "البريد الإلكتروني مستخدم مسبقًا" });
    } else {
      req.log.error({ err: error }, "Could not create employee");
      res.status(500).json({ error: "تعذر إضافة الموظف. أعد المحاولة." });
    }
  }
});

router.patch("/employees/:id", supervisorOnly, async (req, res): Promise<void> => {
  const params = UpdateEmployeeParams.safeParse(req.params);
  const parsed = UpdateEmployeeBody.safeParse(normalizeEmployeeInput(req.body));
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: !params.success
        ? params.error.message
        : !parsed.success
          ? parsed.error.message
          : "بيانات غير صالحة",
    });
    return;
  }
  const [department] = await db
    .select()
    .from(departmentsTable)
    .where(eq(departmentsTable.id, parsed.data.departmentId))
    .limit(1);
  if (!department) {
    res.status(400).json({ error: "القسم المحدد غير موجود" });
    return;
  }
  try {
    const updated = await updateEmployeeAccount(params.data.id, parsed.data, req.appUser!.id);
    if (!updated) {
      res.status(404).json({ error: "الموظف غير موجود" });
      return;
    }
    res.json(UpdateEmployeeResponse.parse(await getEmployeeResponse(updated.id)));
  } catch (error) {
    if (isUniqueViolation(error)) {
      res.status(409).json({ error: "البريد الإلكتروني مستخدم مسبقًا" });
    } else {
      req.log.error({ err: error }, "Could not update employee");
      res.status(500).json({ error: "تعذر تعديل الموظف. أعد المحاولة." });
    }
  }
});

router.get("/departments", async (_req, res): Promise<void> => {
  const departments = await db
    .select({ id: departmentsTable.id, name: departmentsTable.name })
    .from(departmentsTable)
    .orderBy(departmentsTable.name);
  res.json(GetDepartmentsResponse.parse(departments));
});

router.get("/notifications", async (req, res): Promise<void> => {
  await ensureFollowUpAlerts();
  const visible = new Map((await getVisibleTransactions(req)).map(item => [item.id, item]));
  const notifications = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, req.appUser!.id))
    .orderBy(notificationsTable.createdAt);
  res.json(
    GetNotificationsResponse.parse(
      notifications.filter(notification => {
        const flag = notification.type === "stale" ? "needsFollowUp" :
          notification.type === "overdue" ? "overdue" :
          notification.type === "follow_up_today" ? "followUpToday" :
          notification.type === "follow_up_missed" ? "followUpMissed" : undefined;
        if (!flag) return true;
        const transaction = visible.get(notification.transactionId ?? -1);
        return Boolean(transaction?.[flag] &&
          notification.createdAt.getTime() >= new Date(transaction.lastUpdatedAt ?? transaction.createdAt).getTime());
      })
        .reverse()
        .slice(0, 100)
        .map((notification) => ({
          ...notification,
          createdAt: notification.createdAt.toISOString(),
          readAt: asIso(notification.readAt),
        })),
    ),
  );
});

router.patch("/notifications/:id/read", async (req, res): Promise<void> => {
  const params = MarkNotificationReadParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [notification] = await db
    .update(notificationsTable)
    .set({ readAt: new Date() })
    .where(
      and(
        eq(notificationsTable.id, params.data.id),
        eq(notificationsTable.userId, req.appUser!.id),
      ),
    )
    .returning();
  if (!notification) {
    res.status(404).json({ error: "التنبيه غير موجود" });
    return;
  }
  res.json(
    MarkNotificationReadResponse.parse({
      ...notification,
      createdAt: notification.createdAt.toISOString(),
      readAt: asIso(notification.readAt),
    }),
  );
});

router.get("/settings", async (_req, res): Promise<void> => {
  res.json(GetSettingsResponse.parse(await getSettingsValue()));
});

router.patch("/settings", supervisorOnly, async (req, res): Promise<void> => {
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const body = parsed.data;
  if (
    body.statuses &&
    (body.statuses.length === 0 || !body.statuses.includes(COMPLETED_STATUS))
  ) {
    res.status(400).json({
      error: `يجب أن تتضمن الحالات "${COMPLETED_STATUS}"`,
    });
    return;
  }
  if (body.followUpDays !== undefined) {
    await db
      .insert(settingsTable)
      .values({ key: FOLLOW_UP_DAYS_KEY, value: body.followUpDays })
      .onConflictDoUpdate({
        target: settingsTable.key,
        set: { value: body.followUpDays, updatedAt: new Date() },
      });
  }
  if (body.statuses) {
    await db
      .insert(settingsTable)
      .values({ key: STATUSES_KEY, value: [...new Set(body.statuses)] })
      .onConflictDoUpdate({
        target: settingsTable.key,
        set: { value: [...new Set(body.statuses)], updatedAt: new Date() },
      });
  }
  await writeAudit(req.appUser!.id, "update", "settings", null, {
    followUpDays: body.followUpDays,
    statuses: body.statuses,
  });
  res.json(UpdateSettingsResponse.parse(await getSettingsValue()));
});

router.get("/reports", supervisorOnly, async (req, res): Promise<void> => {
  const parsed = GetReportsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const transactions = await getVisibleTransactions(req);
  res.json(
    GetReportsResponse.parse(
      filterTransactions(
        transactions,
        parsed.data as Record<string, unknown>,
      ),
    ),
  );
});

router.post(
  "/storage/uploads/request-url",
  async (req, res): Promise<void> => {
    const parsed = RequestUploadUrlBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const body = parsed.data;
    if (body.size > MAX_FILE_SIZE || !ALLOWED_FILE_TYPES.has(body.contentType)) {
      res.status(400).json({
        error: "الملف يتجاوز 20 ميجابايت أو نوعه غير مدعوم",
      });
      return;
    }
    const [transaction] = await db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.id, body.transactionId))
      .limit(1);
    if (
      !transaction ||
      (req.appUser!.role === "employee" &&
        transaction.employeeId !== req.appUser!.employeeId)
    ) {
      res.status(404).json({ error: "المعاملة غير موجودة أو لا تملك صلاحية رفع مرفق" });
      return;
    }
    const uploadURL = await storage.getObjectEntityUploadURL();
    const objectPath = storage.normalizeObjectEntityPath(uploadURL);
    if (!objectPath.startsWith("/objects/")) {
      req.log.error({ objectPath }, "Storage URL did not normalize to a private path");
      res.status(500).json({ error: "تعذر تجهيز رفع الملف" });
      return;
    }
    await db.insert(attachmentsTable).values({
      transactionUpdateId: null,
      uploadedBy: req.appUser!.id,
      fileName: body.name.slice(0, 255),
      objectPath,
      contentType: body.contentType,
      size: body.size,
    });
    res.json(
      RequestUploadUrlResponse.parse({
        uploadURL,
        objectPath,
      }),
    );
  },
);

router.get("/storage/objects/*objectPath", async (req, res): Promise<void> => {
  const rawPath = req.params.objectPath;
  const objectPath = `/objects/${Array.isArray(rawPath) ? rawPath.join("/") : rawPath}`;
  const parsed = GetStorageObjectParams.safeParse({ objectPath });
  if (!parsed.success) {
    res.status(404).json({ error: "الملف غير موجود" });
    return;
  }
  const conditions: SQL[] = [eq(attachmentsTable.objectPath, objectPath)];
  if (req.appUser!.role === "employee") {
    if (!req.appUser!.employeeId) {
      res.status(404).json({ error: "الملف غير موجود" });
      return;
    }
    conditions.push(
      eq(transactionsTable.employeeId, req.appUser!.employeeId),
    );
  }
  const [attachment] = await db
    .select({ objectPath: attachmentsTable.objectPath })
    .from(attachmentsTable)
    .innerJoin(
      transactionUpdatesTable,
      eq(attachmentsTable.transactionUpdateId, transactionUpdatesTable.id),
    )
    .innerJoin(
      transactionsTable,
      eq(transactionUpdatesTable.transactionId, transactionsTable.id),
    )
    .where(and(...conditions))
    .limit(1);
  if (!attachment) {
    res.status(404).json({ error: "الملف غير موجود" });
    return;
  }
  try {
    const file = await storage.getObjectEntityFile(objectPath);
    const response = await storage.downloadObject(file, 60);
    const bytes = Buffer.from(await response.arrayBuffer());
    res.setHeader(
      "Content-Type",
      response.headers.get("content-type") ?? "application/octet-stream",
    );
    res.setHeader(
      "Content-Disposition",
      `inline; filename*=UTF-8''${encodeURIComponent(objectPath.split("/").at(-1) ?? "file")}`,
    );
    res.send(bytes);
  } catch (error) {
    req.log.warn({ err: error }, "Could not read transaction attachment");
    res.status(404).json({ error: "الملف غير موجود" });
  }
});

export default router;
