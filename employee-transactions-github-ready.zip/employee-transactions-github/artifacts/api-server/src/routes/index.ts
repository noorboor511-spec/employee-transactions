import { Router, type IRouter } from "express";
import healthRouter from "./health";
import brandingRouter from "./branding";
import supervisorsRouter from "./supervisors";
import employeeTransactionsRouter from "./employee-transactions";
import productionCleanupRouter from "./production-cleanup";
import departmentsAdminRouter from "./departments-admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(brandingRouter);
router.use(supervisorsRouter);
router.use(productionCleanupRouter);
router.use(departmentsAdminRouter);
router.use(employeeTransactionsRouter);

export default router;
