import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, settingsTable, auditLogsTable } from "@workspace/db";
import { GetBrandingResponse, UpdateBrandingBody, UpdateBrandingResponse } from "@workspace/api-zod";
import { requireAppUser } from "../lib/auth";
import { primarySupervisorCreditOnly } from "../lib/footer-permissions";

const router: IRouter = Router();

// Public metadata only: never expose account or operational settings here.
router.get("/branding", async (_req, res) => {
  const [setting] = await db.select().from(settingsTable)
    .where(eq(settingsTable.key, "footer_credit")).limit(1);
  const footerCredit = setting ? setting.value : "م.وصل العتيبي";
  res.setHeader("Cache-Control", "no-store");
  res.json(GetBrandingResponse.parse({ footerCredit }));
});

router.patch("/branding", requireAppUser, primarySupervisorCreditOnly, async (req, res): Promise<void> => {
  const parsed = UpdateBrandingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "عبارة التوثيق يجب أن تكون نصًا لا يتجاوز 200 حرف." });
    return;
  }
  const footerCredit = parsed.data.footerCredit.trim();
  await db.transaction(async (tx) => {
    await tx.insert(settingsTable).values({ key: "footer_credit", value: footerCredit })
      .onConflictDoUpdate({
        target: settingsTable.key,
        set: { value: footerCredit, updatedAt: new Date() },
      });
    await tx.insert(auditLogsTable).values({
      userId: req.appUser!.id,
      action: "update",
      entity: "footer_credit",
      details: { removed: footerCredit === "" },
    });
  });
  res.setHeader("Cache-Control", "no-store");
  res.json(UpdateBrandingResponse.parse({ footerCredit }));
});

export default router;
