// Run: node scripts/test-branding.mjs
// The runner replaces auth/database imports with isolated test fixtures.
import test from "node:test";
import assert from "node:assert/strict";
import express from "express";
import brandingRouter from "./branding";
import { canEditFooterCredit } from "../lib/footer-permissions";
import * as database from "@workspace/db";

const { brandingTestState } = database as unknown as {
  brandingTestState: {
    audits: Array<{ userId: number }>;
    untouchedSettings: { followUpDays: number; statuses: string[] };
    primaryId: unknown;
    users: Array<{ id: number; role: string }>;
  };
};

test("footer attribution: public text, principal-only writes, and persistent removal", async () => {
  const app = express();
  app.use(express.json());
  app.use("/api", brandingRouter);
  const server = app.listen(0, "127.0.0.1");
  await new Promise<void>(resolve => server.once("listening", resolve));
  const address = server.address();
  assert.ok(address && typeof address !== "string");
  const url = `http://127.0.0.1:${address.port}/api/branding`;
  const patch = (footerCredit: unknown, role?: string, id = 901) => fetch(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", "x-test-id": String(id), ...(role ? { "x-test-role": role } : {}) },
    body: JSON.stringify({ footerCredit }),
  });
  try {
    assert.deepEqual(await (await fetch(url)).json(), { footerCredit: "م.وصل العتيبي" });
    assert.equal((await patch("unauthorized")).status, 401);
    assert.equal((await patch("unauthorized", "employee")).status, 403);
    // Another supervisor cannot claim ownership by making the first request.
    assert.equal((await patch("unauthorized", "supervisor", 902)).status, 403);
    assert.equal(brandingTestState.primaryId, 901);
    assert.equal(await canEditFooterCredit({ id: 901, role: "supervisor" }), true);
    assert.equal(await canEditFooterCredit({ id: 902, role: "supervisor" }), false);
    assert.equal(await canEditFooterCredit({ id: 901, role: "employee" }), false);
    assert.deepEqual(await (await fetch(url)).json(), { footerCredit: "م.وصل العتيبي" });
    assert.equal(brandingTestState.audits.length, 0);
    for (const invalid of [null, 5, "x".repeat(201)]) {
      assert.equal((await patch(invalid, "supervisor")).status, 400);
    }
    assert.equal(brandingTestState.audits.length, 0);
    assert.equal((await patch("  نص تجريبي  ", "supervisor")).status, 200);
    assert.deepEqual(await (await fetch(url)).json(), { footerCredit: "نص تجريبي" });
    assert.equal((await patch("", "supervisor")).status, 200);
    // Empty is saved, not deleted: reload must not restore the default credit.
    assert.deepEqual(await (await fetch(url)).json(), { footerCredit: "" });
    assert.equal((await patch("م.وصل العتيبي", "supervisor")).status, 200);
    assert.deepEqual(await (await fetch(url)).json(), { footerCredit: "م.وصل العتيبي" });
    assert.equal(brandingTestState.audits.length, 3);
    assert.deepEqual(brandingTestState.untouchedSettings, { followUpDays: 3, statuses: ["جديدة", "مكتملة"] });
    assert.ok(brandingTestState.audits.every((entry: { userId: number }) => entry.userId === 901));
    // Ownership stays pinned if the original supervisor is removed or another
    // earlier employee is promoted. Neither event silently transfers rights.
    brandingTestState.users = [{ id: 900, role: "supervisor" }, { id: 902, role: "supervisor" }];
    assert.equal(await canEditFooterCredit({ id: 900, role: "supervisor" }), false);
    assert.equal(await canEditFooterCredit({ id: 902, role: "supervisor" }), false);
    brandingTestState.primaryId = "901";
    assert.equal(await canEditFooterCredit({ id: 901, role: "supervisor" }), false);
  } finally {
    server.closeAllConnections();
    await new Promise<void>((resolve, reject) => server.close(err => err ? reject(err) : resolve()));
  }
});
