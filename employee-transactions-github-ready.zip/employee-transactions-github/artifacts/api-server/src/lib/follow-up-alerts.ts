import { and, eq, gte } from "drizzle-orm";
import { db, notificationsTable, settingsTable, transactionsTable, usersTable } from "@workspace/db";
import { classifyFollowUp } from "./follow-up";

let pending: Promise<void> | undefined;

// Single-flight protects against overlapping timer and browser polling scans.
export function ensureFollowUpAlerts(): Promise<void> {
  if (pending) return pending;
  pending = scan().finally(() => { pending = undefined; });
  return pending;
}

async function scan(): Promise<void> {
  const [setting] = await db.select().from(settingsTable).where(eq(settingsTable.key, "followUpDays"));
  const days = typeof setting?.value === "number" && setting.value > 0 ? setting.value : 3;
  const users = await db.select().from(usersTable);
  const supervisors = users.filter(user => user.role === "supervisor");
  const transactions = await db.select().from(transactionsTable);
  const now = new Date();
  for (const transaction of transactions) {
    if (transaction.status === "مكتملة") continue;
    const flags = classifyFollowUp(transaction, days, now);
    const candidates: Array<{ type: string; message: string }> = [];
    if (flags.needsFollowUp) candidates.push({
      type: "stale", message: `المعاملة ${transaction.number} تحتاج متابعة: لم تُحدّث منذ ${flags.daysSinceUpdate} أيام`,
    });
    if (transaction.status === "متأخرة") candidates.push({
      type: "overdue", message: `المعاملة ${transaction.number} متأخرة`,
    });
    if (flags.followUpToday) candidates.push({
      type: "follow_up_today", message: `موعد متابعة المعاملة ${transaction.number} اليوم`,
    });
    if (flags.followUpMissed) candidates.push({
      type: "follow_up_missed", message: `تم تجاوز موعد متابعة المعاملة ${transaction.number}`,
    });
    for (const candidate of candidates) {
      const recipients = [...supervisors];
      if (candidate.type === "stale") {
        recipients.push(...users.filter(user => user.role === "employee" && user.employeeId === transaction.employeeId));
      }
      for (const recipient of recipients) {
        const [existing] = await db.select({ id: notificationsTable.id }).from(notificationsTable).where(and(
          eq(notificationsTable.userId, recipient.id),
          eq(notificationsTable.transactionId, transaction.id),
          eq(notificationsTable.type, candidate.type),
          // A real update starts a new inactivity episode; merely opening does not.
          gte(notificationsTable.createdAt, transaction.lastUpdatedAt ?? transaction.createdAt),
        )).limit(1);
        if (!existing) await db.insert(notificationsTable).values({
          userId: recipient.id, transactionId: transaction.id,
          type: candidate.type,
          message: recipient.role === "employee"
            ? `يرجى تحديث المعاملة ${transaction.number}: مرّت ${flags.daysSinceUpdate} أيام دون تحديث`
            : candidate.message,
        });
      }
    }
  }
}
