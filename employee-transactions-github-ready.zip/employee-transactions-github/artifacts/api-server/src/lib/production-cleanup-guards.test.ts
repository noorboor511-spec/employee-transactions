import assert from "node:assert/strict";
import test from "node:test";
import {
  hasExactCleanupConfirmation,
  isProductionCleanupEnabled,
  isSafePrivateUploadPath,
} from "./production-cleanup-guards";

test("production cleanup is unavailable outside the production runtime", () => {
  assert.equal(isProductionCleanupEnabled("production"), true);
  assert.equal(isProductionCleanupEnabled("development"), false);
  assert.equal(isProductionCleanupEnabled(undefined), false);
});

test("cleanup confirmation must match the required Arabic phrase exactly", () => {
  assert.equal(hasExactCleanupConfirmation("حذف نهائي"), true);
  assert.equal(hasExactCleanupConfirmation(" حذف نهائي"), false);
  assert.equal(hasExactCleanupConfirmation("حذف"), false);
  assert.equal(hasExactCleanupConfirmation(undefined), false);
});

test("only generated private upload object paths are accepted", () => {
  assert.equal(
    isSafePrivateUploadPath("/objects/uploads/123e4567-e89b-12d3-a456-426614174000"),
    true,
  );
  assert.equal(isSafePrivateUploadPath("/objects/uploads/../../other-object"), false);
  assert.equal(isSafePrivateUploadPath("/objects/public/image.png"), false);
});
