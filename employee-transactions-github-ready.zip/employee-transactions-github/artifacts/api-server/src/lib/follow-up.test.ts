import assert from "node:assert/strict";
import { test } from "node:test";
import { classifyFollowUp } from "./follow-up";

const now = new Date("2026-10-08T10:00:00Z");
const transaction = (days: number, status = "تحت الإجراء", due: Date | null = null) => ({
  status, createdAt: new Date(now.getTime() - 10 * 86_400_000),
  lastUpdatedAt: new Date(now.getTime() - days * 86_400_000), nextFollowUpAt: due,
});

for (const days of [0, 2, 3, 5]) test(`inactivity ${days} days`, () => {
  const flags = classifyFollowUp(transaction(days), 3, now);
  assert.equal(flags.daysSinceUpdate, days);
  assert.equal(flags.needsFollowUp, days >= 3);
  assert.equal(flags.recentlyUpdated, days === 0);
});
test("completed is excluded from every follow-up classification", () => {
  const flags = classifyFollowUp(transaction(10, "مكتملة", new Date(now.getTime() - 1000)), 3, now);
  for (const key of ["needsFollowUp", "overdue", "followUpToday", "followUpMissed", "recentlyUpdated"] as const)
    assert.equal(flags[key], false);
});
test("due today uses Riyadh date; future due time is not missed", () => {
  const flags = classifyFollowUp(transaction(0, "جديدة", new Date("2026-10-08T20:59:59Z")), 3, now);
  assert.equal(flags.followUpToday, true);
  assert.equal(flags.followUpMissed, false);
});
test("past due is missed without changing transaction status", () => {
  const row = transaction(2, "تحت الإجراء", new Date("2026-10-07T20:59:59Z"));
  const flags = classifyFollowUp(row, 3, now);
  assert.equal(flags.followUpMissed, true);
  assert.equal(flags.overdue, true);
  assert.equal(row.status, "تحت الإجراء");
});
test("threshold is configurable and includes its exact boundary", () => {
  assert.equal(classifyFollowUp(transaction(3), 5, now).needsFollowUp, false);
  assert.equal(classifyFollowUp(transaction(5), 5, now).needsFollowUp, true);
});
test("missing initial update falls back to creation; reads never mutate timestamps", () => {
  const row = { ...transaction(0), lastUpdatedAt: null };
  const before = JSON.stringify(row);
  assert.equal(classifyFollowUp(row, 3, now).daysSinceUpdate, 10);
  assert.equal(JSON.stringify(row), before);
});
