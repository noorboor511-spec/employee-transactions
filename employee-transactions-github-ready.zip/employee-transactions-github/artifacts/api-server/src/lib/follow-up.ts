export function riyadhDay(date: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit",
  }).format(date);
}

export function classifyFollowUp(
  transaction: {
    status: string; lastUpdatedAt: Date | null; createdAt: Date;
    nextFollowUpAt: Date | null;
  },
  followUpDays = 3,
  now = new Date(),
) {
  const lastActivity = transaction.lastUpdatedAt ?? transaction.createdAt;
  const elapsed = Math.max(0, now.getTime() - lastActivity.getTime());
  const daysSinceUpdate = Math.floor(elapsed / 86_400_000);
  const open = transaction.status !== "مكتملة";
  const followUpMissed = open && transaction.nextFollowUpAt !== null &&
    transaction.nextFollowUpAt.getTime() < now.getTime();
  return {
    daysSinceUpdate,
    needsFollowUp: open && daysSinceUpdate >= followUpDays,
    overdue: open && (transaction.status === "متأخرة" || followUpMissed),
    followUpToday: open && transaction.nextFollowUpAt !== null &&
      riyadhDay(transaction.nextFollowUpAt) === riyadhDay(now),
    followUpMissed,
    recentlyUpdated: open && elapsed < 86_400_000,
  };
}
