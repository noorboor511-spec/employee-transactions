import { clerkClient, getAuth } from "@clerk/express";
import type { RequestHandler } from "express";
import { and, eq, isNull } from "drizzle-orm";
import { db, employeesTable, usersTable, type User } from "@workspace/db";
import { resolvePublishedAccount } from "./published-account";

declare global {
  namespace Express {
    interface Request {
      appUser?: User;
    }
  }
}

export const requireAppUser: RequestHandler = async (req, res, next) => {
  try {
    const clerkUserId = getAuth(req).userId;
    if (!clerkUserId) {
      res.status(401).json({ error: "يلزم تسجيل الدخول" });
      return;
    }

    const production = process.env.NODE_ENV === "production";
    const [initialUser] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.clerkUserId, clerkUserId))
      .limit(1);
    let user: User | undefined = initialUser;

    if (!user) {
      const clerkUser = await clerkClient.users.getUser(clerkUserId);
      const primaryEmail = clerkUser.emailAddresses.find(
        (item) => item.id === clerkUser.primaryEmailAddressId,
      );
      const emailAddress = primaryEmail?.emailAddress;
      if (!emailAddress) {
        res.status(403).json({ error: "لا يوجد بريد إلكتروني موثق لهذا الحساب" });
        return;
      }
      const email = emailAddress.trim().toLowerCase();
      const name =
        [clerkUser.firstName, clerkUser.lastName].filter(Boolean).join(" ") ||
        email;

      const [matchingAccount] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.email, email))
        .limit(1);

      if (matchingAccount && !matchingAccount.clerkUserId) {
        if (production && primaryEmail?.verification?.status !== "verified") {
          res.status(403).json({ error: "يجب توثيق البريد الإلكتروني قبل ربط الحساب" });
          return;
        }
        [user] = await db
          .update(usersTable)
          .set(production ? { clerkUserId } : { clerkUserId, name, updatedAt: new Date() })
          .where(
            and(
              eq(usersTable.id, matchingAccount.id),
              isNull(usersTable.clerkUserId),
            ),
          )
          .returning();
      } else if (
        matchingAccount &&
        matchingAccount.clerkUserId === clerkUserId
      ) {
        user = matchingAccount;
      } else if (matchingAccount && primaryEmail) {
        const legacyAccount = await resolvePublishedAccount(
          matchingAccount,
          primaryEmail,
          production,
          (id) => clerkClient.users.getUser(id),
        );
        if (legacyAccount?.clerkUserId && legacyAccount.email) {
          [user] = await db
            .update(usersTable)
            .set({ clerkUserId })
            .where(and(
              eq(usersTable.id, legacyAccount.id),
              eq(usersTable.email, legacyAccount.email),
              eq(usersTable.clerkUserId, legacyAccount.clerkUserId),
            ))
            .returning();

          // A concurrent request may already have completed this exact link.
          if (!user) {
            const [linked] = await db.select().from(usersTable)
              .where(and(
                eq(usersTable.id, legacyAccount.id),
                eq(usersTable.clerkUserId, clerkUserId),
              )).limit(1);
            user = linked;
          }
        }
      } else if (!matchingAccount && !production) {
        // The first authenticated account claims the pre-seeded, empty
        // supervisor account. The conditional update makes this one-time
        // bootstrap safe if two people sign in at the same time.
        [user] = await db
          .update(usersTable)
          .set({ clerkUserId, email, name, updatedAt: new Date() })
          .where(
            and(
              eq(usersTable.role, "supervisor"),
              isNull(usersTable.email),
              isNull(usersTable.clerkUserId),
            ),
          )
          .returning();
      }

      if (!user) {
        res.status(403).json({
          error: "هذا الحساب غير مضاف للنظام. تواصل مع المشرف لإضافته.",
        });
        return;
      }
    }

    if (user.role === "revoked") {
      res.status(403).json({ error: "أُلغيت صلاحية الإشراف لهذا الحساب ولا يوجد حساب موظف مرتبط به." });
      return;
    }

    if (user.role === "employee" && user.employeeId) {
      const [employee] = await db
        .select({ active: employeesTable.active })
        .from(employeesTable)
        .where(eq(employeesTable.id, user.employeeId))
        .limit(1);
      if (!employee?.active) {
        res.status(403).json({ error: "حساب الموظف غير نشط" });
        return;
      }
    }

    req.appUser = user;
    next();
  } catch (error) {
    req.log.error({ err: error }, "Failed to resolve signed-in user");
    res.status(500).json({ error: "تعذر التحقق من صلاحية الحساب" });
  }
};

export const supervisorOnly: RequestHandler = (req, res, next) => {
  if (req.appUser?.role !== "supervisor") {
    res.status(403).json({ error: "هذه الميزة متاحة للمشرف فقط" });
    return;
  }
  next();
};

export async function writeAudit(
  userId: number,
  action: string,
  entity: string,
  entityId: number | null,
  details: Record<string, unknown> = {},
): Promise<void> {
  const { auditLogsTable } = await import("@workspace/db");
  await db.insert(auditLogsTable).values({
    userId,
    action,
    entity,
    entityId,
    details,
  });
}
