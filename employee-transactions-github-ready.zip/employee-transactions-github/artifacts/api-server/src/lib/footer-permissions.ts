import type { RequestHandler } from "express";
import { eq } from "drizzle-orm";
import { db, settingsTable, usersTable } from "@workspace/db";

const PRIMARY_SUPERVISOR_KEY = "primary_supervisor_id";
const validId = (value: unknown): number | null =>
  typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : null;

async function primarySupervisorId(): Promise<number | null> {
  const [pinned] = await db.select({ value: settingsTable.value }).from(settingsTable)
    .where(eq(settingsTable.key, PRIMARY_SUPERVISOR_KEY)).limit(1);
  // Never silently transfer ownership if the pinned account disappears,
  // loses its role, or the stored setting is invalid.
  if (pinned) return validId(pinned.value);

  const [original] = await db.select({ id: usersTable.id }).from(usersTable)
    .where(eq(usersTable.role, "supervisor")).orderBy(usersTable.id).limit(1);
  if (!original) return null;
  // Pin the original application's account ID, not a Clerk ID (dev/prod differ).
  // Concurrent initialization must not overwrite an existing owner.
  const [inserted] = await db.insert(settingsTable)
    .values({ key: PRIMARY_SUPERVISOR_KEY, value: original.id })
    .onConflictDoNothing().returning({ value: settingsTable.value });
  if (inserted) return validId(inserted.value);
  const [winner] = await db.select({ value: settingsTable.value }).from(settingsTable)
    .where(eq(settingsTable.key, PRIMARY_SUPERVISOR_KEY)).limit(1);
  return validId(winner?.value);
}

export async function isPrimarySupervisor(user: { id: number; role: string }): Promise<boolean> {
  if (user.role !== "supervisor") return false;
  return user.id === await primarySupervisorId();
}

export const canEditFooterCredit = isPrimarySupervisor;

export const primarySupervisorCreditOnly: RequestHandler = async (req, res, next) => {
  try {
    if (!req.appUser || !await canEditFooterCredit(req.appUser)) {
      res.status(403).json({ error: "تعديل عبارة التوثيق متاح للمشرف الرئيس فقط." });
      return;
    }
    next();
  } catch (error) {
    req.log.error({ err: error }, "Could not verify footer editing permission");
    res.status(500).json({ error: "تعذر التحقق من صلاحية تعديل عبارة التوثيق." });
  }
};
