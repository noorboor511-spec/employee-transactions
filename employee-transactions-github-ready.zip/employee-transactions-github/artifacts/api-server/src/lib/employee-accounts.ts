import { eq } from "drizzle-orm";
import { auditLogsTable, db, employeesTable, usersTable } from "@workspace/db";

type EmployeeInput = {
  name: string; email: string; departmentId: number; active?: boolean;
};

export function normalizeEmployeeInput(input: unknown): unknown {
  if (!input || typeof input !== "object" || Array.isArray(input)) return input;
  const body = input as Record<string, unknown>;
  return { ...body, email: typeof body.email === "string" ? body.email.trim().toLowerCase() : body.email };
}

export function isUniqueViolation(error: unknown): boolean {
  for (let depth = 0; depth < 3 && error && typeof error === "object"; depth++) {
    if ("code" in error && error.code === "23505") return true;
    error = "cause" in error ? error.cause : null;
  }
  return false;
}

const employeeValues = (body: EmployeeInput) => ({
  name: body.name.trim(), email: body.email.trim().toLowerCase(),
  departmentId: body.departmentId, active: body.active ?? true,
});

export async function createEmployeeAccount(body: EmployeeInput, actorId: number) {
  return db.transaction(async tx => {
    const [employee] = await tx.insert(employeesTable).values(employeeValues(body)).returning();
    await tx.insert(usersTable).values({
      email: employee.email, name: employee.name, role: "employee", employeeId: employee.id,
    });
    await tx.insert(auditLogsTable).values({
      userId: actorId, action: "create", entity: "employee", entityId: employee.id,
    });
    return employee;
  });
}

export async function updateEmployeeAccount(id: number, body: EmployeeInput, actorId: number) {
  return db.transaction(async tx => {
    const [employee] = await tx.update(employeesTable).set(employeeValues(body))
      .where(eq(employeesTable.id, id)).returning();
    if (!employee) return null;
    // Identity, role, and Clerk binding stay intact. Both email changes are atomic.
    await tx.update(usersTable).set({
      name: employee.name, email: employee.email, updatedAt: new Date(),
    }).where(eq(usersTable.employeeId, id));
    await tx.insert(auditLogsTable).values({
      userId: actorId, action: "update", entity: "employee", entityId: id,
      details: { email: employee.email, active: employee.active },
    });
    return employee;
  });
}
