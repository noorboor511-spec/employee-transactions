type LinkedAccount = {
  email: string | null;
  clerkUserId: string | null;
};

type PrimaryEmail = {
  emailAddress: string;
  verification?: { status: string } | null;
};

/**
 * A copied development account can retain a Clerk ID from the test tenant.
 * Validate that it is a legacy binding before the caller links the production
 * ID. Never bypass a binding in the production tenant or an unverified email.
 */
export async function resolvePublishedAccount<T extends LinkedAccount>(
  account: T,
  primaryEmail: PrimaryEmail,
  production: boolean,
  lookupUser: (id: string) => Promise<unknown>,
): Promise<T | undefined> {
  if (
    !production ||
    !account.clerkUserId ||
    primaryEmail.verification?.status !== "verified" ||
    account.email?.trim().toLowerCase() !==
      primaryEmail.emailAddress.trim().toLowerCase()
  ) {
    return undefined;
  }

  try {
    await lookupUser(account.clerkUserId);
    // A real production binding must not be bypassed by a different identity.
    return undefined;
  } catch (error) {
    if (
      typeof error === "object" &&
      error !== null &&
      "status" in error &&
      error.status === 404
    ) {
      return account;
    }
    // An outage or invalid credentials are not evidence of a legacy binding.
    throw error;
  }
}
