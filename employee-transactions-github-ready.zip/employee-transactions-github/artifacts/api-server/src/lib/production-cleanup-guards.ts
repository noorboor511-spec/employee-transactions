export const PRODUCTION_CLEANUP_CONFIRMATION = "حذف نهائي";

const PRIVATE_UPLOAD_PATH =
  /^\/objects\/uploads\/[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function isProductionCleanupEnabled(nodeEnv: string | undefined): boolean {
  return nodeEnv === "production";
}

export function hasExactCleanupConfirmation(value: unknown): boolean {
  return value === PRODUCTION_CLEANUP_CONFIRMATION;
}

export function isSafePrivateUploadPath(value: string): boolean {
  return PRIVATE_UPLOAD_PATH.test(value);
}
