import assert from "node:assert/strict";
import { test } from "node:test";
import { resolvePublishedAccount } from "./published-account";

const account = {
  id: 7,
  email: "supervisor@example.com",
  clerkUserId: "user_development",
  role: "supervisor",
  employeeId: null,
};
const email = {
  emailAddress: "supervisor@example.com",
  verification: { status: "verified" },
};
const missing = async () => { throw { status: 404 }; };

test("verified production email resolves a legacy binding without mutating data or role", async () => {
  const before = JSON.stringify(account);
  let lookedUp: string | undefined;
  const result = await resolvePublishedAccount(account, email, true, async id => {
    lookedUp = id;
    return missing();
  });
  assert.strictEqual(result, account);
  assert.equal(lookedUp, account.clerkUserId);
  assert.equal(JSON.stringify(account), before);
  assert.equal(result?.role, "supervisor");
});

test("an employee retains the stored employee role and ownership", async () => {
  const employee = { ...account, role: "employee", employeeId: 12 };
  const result = await resolvePublishedAccount(employee, email, true, missing);
  assert.strictEqual(result, employee);
  assert.equal(result?.role, "employee");
  assert.equal(result?.employeeId, 12);
});

for (const [label, candidate, primary, production] of [
  ["development", account, email, false],
  ["unverified email", account, { ...email, verification: { status: "unverified" } }, true],
  ["missing verification", account, { emailAddress: email.emailAddress }, true],
  ["different email", account, { ...email, emailAddress: "other@example.com" }, true],
  ["unbound account", { ...account, clerkUserId: null }, email, true],
] as const) {
  test(`does not resolve ${label}`, async () => {
    let calls = 0;
    const result = await resolvePublishedAccount(candidate, primary, production, async () => {
      calls++;
      return missing();
    });
    assert.equal(result, undefined);
    assert.equal(calls, 0);
  });
}

test("never bypasses a binding that exists in production", async () => {
  assert.equal(await resolvePublishedAccount(account, email, true, async () => ({})), undefined);
});

for (const status of [401, 403, 429, 500]) {
  test(`fails closed for provider status ${status}`, async () => {
    const error = { status };
    await assert.rejects(
      resolvePublishedAccount(account, email, true, async () => { throw error; }),
      caught => caught === error,
    );
  });
}

test("case normalization does not change the stored email", async () => {
  assert.strictEqual(
    await resolvePublishedAccount(account, { ...email, emailAddress: "SUPERVISOR@example.com" }, true, missing),
    account,
  );
  assert.equal(account.email, "supervisor@example.com");
});
