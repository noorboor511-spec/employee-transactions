# نظام متابعة معاملات الموظفين (Employee Transactions)

تطبيق عربي متكامل لإسناد ومتابعة معاملات الموظفين، مع سجل تحديثات ثابت، تنبيهات تلقائية، تقارير، وإدارة صلاحيات دقيقة.

---

## المميزات الرئيسية

- **واجهة عربية كاملة (RTL)** مبنية بـ React + Vite + shadcn/ui
- **خادم API** بـ Express + TypeScript مع تفويض صارم على مستوى الخادم
- **مصادقة** عبر [Clerk](https://clerk.com)
- **قاعدة بيانات** PostgreSQL مع Drizzle ORM
- **مرفقات** تُرفع مباشرة إلى تخزين S3-compatible عبر روابط موقّعة
- **تنبيهات متابعة** تلقائية حسب مدة المتابعة المحددة لكل نوع معاملة
- **صلاحيات**:
  - الموظف يرى ويحدّث معاملاته فقط
  - المشرف يدير الفريق والمعاملات والتقارير
- سجل تحديثات **إضافي فقط** (لا يمكن حذف التحديثات السابقة)
- حزمة جاهزة للنشر على **Vercel** (مستقلة تماماً)

---

## هيكل المشروع (Monorepo)

```
employee-transactions/
├── artifacts/
│   ├── api-server/              # خادم Express API
│   ├── employee-transactions/   # واجهة React (الويب)
│   └── mockup-sandbox/          # بيئة تجريبية للمكونات
├── lib/
│   ├── api-spec/                # OpenAPI specification
│   ├── api-zod/                 # مخططات Zod المولّدة
│   ├── api-client-react/        # عميل API لـ React
│   └── db/                      # مخطط قاعدة البيانات (Drizzle)
├── distribution/
│   └── vercel/                  # حزمة النشر المستقلة على Vercel
├── scripts/                     # سكربتات مساعدة واختبارات
├── package.json
├── pnpm-workspace.yaml
└── tsconfig.base.json
```

---

## المتطلبات

- **Node.js** 22+
- **pnpm** 9+ (يُفضل استخدام Corepack)
- **PostgreSQL** 15+
- حساب **Clerk** (للتوثيق)
- تخزين **S3-compatible** (اختياري للتطوير المحلي، مطلوب للإنتاج)

```bash
# تفعيل pnpm عبر Corepack (موصى به)
corepack enable
corepack prepare pnpm@latest --activate
```

---

## التثبيت والتشغيل المحلي

```bash
# 1. استنساخ المستودع
git clone <رابط-المستودع>
cd employee-transactions

# 2. تثبيت الحزم
pnpm install

# 3. إعداد متغيرات البيئة (أنشئ ملف .env في الجذر أو داخل كل حزمة حسب الحاجة)
#    DATABASE_URL, CLERK_SECRET_KEY, CLERK_PUBLISHABLE_KEY, ...

# 4. تطبيق مخطط قاعدة البيانات
pnpm --filter @workspace/db run push

# 5. تشغيل خادم API
pnpm --filter @workspace/api-server run dev
# يعمل على المنفذ الافتراضي ويقدّم المسارات تحت /api

# 6. تشغيل الواجهة (في طرفية أخرى)
pnpm --filter @workspace/employee-transactions run dev
```

### أوامر مفيدة

| الأمر | الوصف |
|-------|--------|
| `pnpm run typecheck` | فحص الأنواع لجميع الحزم |
| `pnpm run build` | بناء كل الحزم |
| `pnpm --filter @workspace/employee-transactions run build` | بناء الواجهة فقط |
| `pnpm --filter @workspace/api-spec run codegen` | إعادة توليد عميل API ومخططات Zod بعد تعديل OpenAPI |
| `pnpm --filter @workspace/db run push` | تطبيق تغييرات المخطط على قاعدة التطوير |

---

## النشر على Vercel

يوجد دليل كامل في:

```
distribution/vercel/README-VERCEL.md
```

الخطوات المختصرة:

1. جهّز مصدر نظيف بدون أسرار:
   ```bash
   node distribution/vercel/prepare.mjs
   ```
2. أنشئ مشروع Vercel جديد + قاعدة PostgreSQL مستقلة + bucket مستقل + تطبيق Clerk **جديد ومستقل**.
3. اضبط متغيرات البيئة في Vercel (لا تضع أسراراً في Git).
4. انشر الحزمة الناتجة.

> **مهم**: لا تستخدم مفاتيح أو بيانات مشروع Replit الأصلي. كل شيء يجب أن يكون مستقلاً.

---

## مصادر الحقيقة في الكود

| الجزء | المسار |
|-------|--------|
| مخطط قاعدة البيانات | `lib/db/src/schema/` |
| عقد API (OpenAPI) | `lib/api-spec/openapi.yaml` |
| منطق الخادم + التفويض + التنبيهات | `artifacts/api-server/src/` |
| واجهة المستخدم (RTL) | `artifacts/employee-transactions/src/` |
| المصادقة (Clerk) | `artifacts/api-server/src/lib/auth.ts` |

---

## قواعد العمل الأساسية

- أنواع المعاملات وحالاتها ومدة المتابعة الافتراضية تُدار من الإعدادات (المدة الافتراضية 3 أيام).
- سجل تحديث المعاملة **إضافي فقط** — لا توجد واجهة أو مسار لحذف التحديثات السابقة.
- الموظف يرى ويحدّث معاملات إسناده فقط. فحوصات الصلاحية تتم في الـ API.
- المرفقات تُرفع مباشرة إلى التخزين باستخدام رابط موقّع؛ PostgreSQL يحتفظ بالبيانات الوصفية فقط.
- بيانات البداية تشمل مشرفاً غير مربوط، وموظفين تجريبيين، ومعاملات تجريبية.

---

## الترخيص

MIT

---

## ملاحظات أمنية

- لا ترفع أي ملف `.env` أو مفاتيح سرية إلى Git.
- تأكد أن `.gitignore` يستبعد `node_modules` و`dist` و`.env*` و`generated-artifacts`.
- صلاحيات الوصول تُفرض دائماً في الخادم وليس في الواجهة فقط.
