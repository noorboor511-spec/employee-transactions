"""Package the tested source tree, never dependencies, runtime configuration or data."""
import hashlib
import html
import json
import pathlib
import re
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[2]
SOURCE = ROOT / "generated-artifacts/tabe-vercel"
OUT = ROOT / "generated-artifacts/vercel-deliverables"
OUT.mkdir(parents=True, exist_ok=True)
for name in ["README-VERCEL.md", "TEST-REPORT.md"]:
    # Documentation is generated from the maintained distribution source.
    (SOURCE / name).write_bytes((ROOT / "distribution/vercel" / name).read_bytes())
EXCLUDED = {"node_modules", ".vercel", "dist", ".git", ".local", ".agents", "database", "backups"}
SECRET = re.compile(rb"\b(?:sk|pk)_(?:live|test)_[A-Za-z0-9]{20,}")
files = {}
for file in sorted(SOURCE.rglob("*")):
    rel = file.relative_to(SOURCE)
    if (any(part in EXCLUDED for part in rel.parts) or file.is_symlink() or not file.is_file()
            or file.name.startswith(".env") or file.name in {"integration-results.json", ".tsbuildinfo", ".test-server.mjs"}
            or file.suffix in {".tsbuildinfo", ".dump", ".log", ".pem", ".key", ".zip"}):
        continue
    # The ONLY SQL is the synthetic, explicitly authored test schema.
    if file.suffix == ".sql" and rel.as_posix() != "tests/schema.sql":
        raise SystemExit(f"Unexpected SQL in package: {rel}")
    content = file.read_bytes()
    if SECRET.search(content):
        raise SystemExit(f"Credential-like value in {rel}")
    files[rel.as_posix()] = content
assert json.loads(files["PACKAGE-SCOPE.json"])["dataIncluded"] is False
for required in ["pnpm-lock.yaml", "README-VERCEL.md", "TEST-REPORT.md", "vercel.json",
                 "vercel-tools/build.mjs", "vercel-tools/prepare-database.ts"]:
    assert required in files, required
hashes = {name: hashlib.sha256(content).hexdigest() for name, content in files.items()}
files["FILES-SHA256.json"] = json.dumps(hashes, indent=2).encode()
archive = OUT / "tabe-vercel-independent.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
    for name, content in files.items():
        output.writestr(f"tabe-vercel/{name}", content)
guide = """<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>تابع — دليل نسخة Vercel المستقلة</title><style>
body{max-width:960px;margin:24px auto;padding:24px;background:#f6f3eb;color:#263f35;font-family:Tahoma,Arial,sans-serif}
pre{white-space:pre-wrap;overflow-wrap:anywhere;font:15px/1.9 Tahoma,Arial,sans-serif;background:white;padding:24px;border-radius:12px}
h1{color:#1d5a4d}</style><h1>تابع — نسخة Vercel المستقلة</h1><pre>"""
guide += html.escape(files["README-VERCEL.md"].decode()) + "</pre><h2>تقرير الاختبار</h2><pre>"
guide += html.escape(files["TEST-REPORT.md"].decode()) + "</pre></html>"
(OUT / "tabe-vercel-guide.html").write_text(guide)
print(json.dumps({"archive": str(archive.relative_to(ROOT)), "files": len(files),
                  "bytes": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                  "dataIncluded": False, "credentialsIncluded": False}, indent=2))
