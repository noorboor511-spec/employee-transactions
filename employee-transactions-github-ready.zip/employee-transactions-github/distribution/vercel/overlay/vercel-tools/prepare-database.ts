import { createRequire } from "node:module";
const require = createRequire(new URL("../lib/db/package.json", import.meta.url));
const { Client } = require("pg");

// This utility NEVER exports, restores, truncates, or creates real accounts.
// Default mode is read-only. Writes require deliberate independent-copy confirmation.
const apply = process.argv.includes("--confirm-independent-copy");
const idArgument = process.argv.find(arg => arg.startsWith("--primary-user-id="))?.split("=")[1];
const primaryId = Number(idArgument);
const installation = process.env.TABE_INSTALLATION_ID;
if (!process.env.DATABASE_URL) throw new Error("Configure DATABASE_URL securely for the independent target only");
if (apply && (!Number.isSafeInteger(primaryId) || primaryId < 1 || !installation ||
  !/^[0-9a-f-]{36}$/i.test(installation))) {
  throw new Error("Set TABE_INSTALLATION_ID to a new UUID and supply --primary-user-id=<existing original account number>");
}
const client = new Client({ connectionString: process.env.DATABASE_URL, connectionTimeoutMillis: 10000 });
await client.connect();
try {
  await client.query(apply ? "BEGIN" : "BEGIN READ ONLY");
  const duplicates = await client.query(`SELECT lower(btrim(email)) FROM users WHERE email IS NOT NULL
    GROUP BY lower(btrim(email)) HAVING count(*) > 1`);
  if (duplicates.rowCount) throw new Error("Duplicate normalized account emails; resolve on the independent copy first");
  const employeeDuplicates = await client.query(`SELECT lower(btrim(email)) FROM employees
    GROUP BY lower(btrim(email)) HAVING count(*) > 1`);
  if (employeeDuplicates.rowCount) throw new Error("Duplicate normalized employee emails; resolve on the independent copy first");
  const owner = await client.query("SELECT value FROM settings WHERE key='primary_supervisor_id'");
  const previous = await client.query("SELECT value FROM settings WHERE key='vercel_installation_id'");
  if (previous.rowCount && previous.rows[0].value !== installation) {
    throw new Error("This database belongs to another installation; refusing to adopt it");
  }
  if (apply) {
    const account = await client.query("SELECT role, email FROM users WHERE id=$1", [primaryId]);
    if (account.rows[0]?.role !== "supervisor" || !account.rows[0]?.email?.trim()) {
      throw new Error("Primary supervisor must be an existing supervisor with an email");
    }
    if (owner.rowCount && owner.rows[0].value !== primaryId) {
      throw new Error("Existing primary supervisor differs; refusing ownership transfer");
    }
    await client.query(`CREATE TABLE IF NOT EXISTS vercel_identity_links (
      user_id integer PRIMARY KEY REFERENCES users(id),
      clerk_subject text NOT NULL UNIQUE, created_at timestamptz NOT NULL DEFAULT now()
    )`);
    await client.query(`INSERT INTO settings(key,value) VALUES ('primary_supervisor_id',$1::jsonb)
      ON CONFLICT (key) DO NOTHING`, [JSON.stringify(primaryId)]);
    await client.query(`INSERT INTO settings(key,value) VALUES ('vercel_installation_id',$1::jsonb)
      ON CONFLICT (key) DO NOTHING`, [JSON.stringify(installation)]);
  }
  await client.query("COMMIT");
  console.log(apply ? "Independent copy prepared. Account IDs, profiles, roles, history and old Clerk bindings unchanged."
    : "Read-only preflight passed. No data was exported or modified.");
} catch (error) {
  await client.query("ROLLBACK");
  throw error;
} finally {
  await client.end();
}
