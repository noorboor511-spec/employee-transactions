import { mkdir, rm, cp, writeFile, readFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { build } from "esbuild";

// Only this public Clerk key is allowed into Vite. Never inline process.env.
const key = process.env.VITE_CLERK_PUBLISHABLE_KEY;
if (!key || !/^pk_(test|live)_/.test(key)) throw new Error("Set the independent VITE_CLERK_PUBLISHABLE_KEY before building");
if (process.env.CLERK_PUBLISHABLE_KEY && process.env.CLERK_PUBLISHABLE_KEY !== key) {
  throw new Error("Frontend and backend Clerk publishable keys must match");
}
const output = ".vercel/output";
await rm(output, { recursive: true, force: true });
const result = spawnSync("pnpm", ["--filter", "@workspace/employee-transactions", "run", "build"], {
  stdio: "inherit", env: { ...process.env, NODE_ENV: "production" },
});
if (result.status !== 0) process.exit(result.status ?? 1);
await mkdir(`${output}/functions/api.func`, { recursive: true });
await cp("artifacts/employee-transactions/dist/public", `${output}/static`, { recursive: true });
await build({
  entryPoints: ["artifacts/api-server/src/app.ts"],
  outfile: `${output}/functions/api.func/index.mjs`,
  bundle: true, platform: "node", target: "node22", format: "esm",
  // pg-native is an optional pg backend, not used by this application.
  external: ["pg-native"],
  define: { "process.env.NODE_ENV": '"production"' },
  banner: { js: 'import { createRequire as __createRequire } from "node:module"; const require = __createRequire(import.meta.url);' },
});
await writeFile(`${output}/functions/api.func/.vc-config.json`, JSON.stringify({
  runtime: "nodejs22.x", handler: "index.mjs", launcherType: "Nodejs",
  maxDuration: 60, supportsResponseStreaming: true,
}, null, 2));
// Route before the SPA fallback so API errors are never replaced by index.html.
await writeFile(`${output}/config.json`, JSON.stringify({
  version: 3,
  routes: [
    { src: "/api(?:/.*)?", dest: "/api" },
    { src: "/assets/(.*)", headers: { "Cache-Control": "public, max-age=31536000, immutable" }, continue: true },
    { handle: "filesystem" },
    { src: "/.*", dest: "/index.html" },
  ],
  crons: [{ path: "/api/cron/follow-up", schedule: "0 21 * * *" }],
}, null, 2));
// Fail if the server bundle accidentally imports an unavailable private sidecar.
const bundle = await readFile(`${output}/functions/api.func/index.mjs`, "utf8");
if (bundle.includes("127.0.0.1:1106")) throw new Error("Replit sidecar leaked into the Vercel function");
console.log("Built static frontend and standalone Vercel Node.js function; no deployment performed.");
