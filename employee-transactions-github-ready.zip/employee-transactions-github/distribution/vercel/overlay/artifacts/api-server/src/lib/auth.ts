import { clerkClient, getAuth } from "@clerk/express";
import type { RequestHandler } from "express";
import { eq, sql } from "drizzle-orm";
import { db, employeesTable, usersTable, vercelIdentityLinksTable, type User } from "@workspace/db";
import { verifiedEmail } from "./vercel-identity";

declare global {
  namespace Express {
    interface Request { appUser?: User }
  }
}

export const requireAppUser: RequestHandler = async (req, res, next) => {
  try {
    const subject = getAuth(req).userId;
    if (!subject) {
      res.status(401).json({ error: "يلزم تسجيل الدخول" });
      return;
    }
    let [linked] = await db.select({ user: usersTable }).from(vercelIdentityLinksTable)
      .innerJoin(usersTable, eq(usersTable.id, vercelIdentityLinksTable.userId))
      .where(eq(vercelIdentityLinksTable.clerkSubject, subject)).limit(1);
    if (!linked) {
      const profile = await clerkClient.users.getUser(subject);
      const email = verifiedEmail(profile);
      if (!email) {
        res.status(403).json({ error: "يجب توثيق البريد الإلكتروني الأساسي قبل ربط حسابك" });
        return;
      }
      // Serialized per-account linking; unique constraints also protect cross-instance races.
      await db.transaction(async tx => {
        const [account] = await tx.select().from(usersTable)
          .where(sql`lower(btrim(${usersTable.email})) = ${email}`).limit(1).for("update");
        if (!account || account.role === "revoked") return;
        await tx.insert(vercelIdentityLinksTable).values({ userId: account.id, clerkSubject: subject })
          .onConflictDoNothing();
      });
      [linked] = await db.select({ user: usersTable }).from(vercelIdentityLinksTable)
        .innerJoin(usersTable, eq(usersTable.id, vercelIdentityLinksTable.userId))
        .where(eq(vercelIdentityLinksTable.clerkSubject, subject)).limit(1);
    }
    const user = linked?.user;
    if (!user || user.role === "revoked" ||
      !["supervisor", "employee"].includes(user.role)) {
      res.status(403).json({ error: "هذا الحساب غير مضاف للنظام أو غير مخوّل بالدخول. تواصل مع المشرف." });
      return;
    }
    if (user.role === "employee") {
      const [employee] = user.employeeId ? await db.select().from(employeesTable)
        .where(eq(employeesTable.id, user.employeeId)).limit(1) : [];
      if (!employee?.active) {
        res.status(403).json({ error: "حساب الموظف غير نشط" });
        return;
      }
    }
    req.appUser = user;
    next();
  } catch (error) {
    req.log.error({ err: error }, "Failed to resolve independent Clerk identity");
    res.status(500).json({ error: "تعذر التحقق من صلاحية الحساب" });
  }
};

export const supervisorOnly: RequestHandler = (req, res, next) => {
  if (req.appUser?.role !== "supervisor") {
    res.status(403).json({ error: "هذه الميزة متاحة للمشرف فقط" });
    return;
  }
  next();
};

export async function writeAudit(
  userId: number, action: string, entity: string, entityId: number | null,
  details: Record<string, unknown> = {},
): Promise<void> {
  const { auditLogsTable } = await import("@workspace/db");
  await db.insert(auditLogsTable).values({ userId, action, entity, entityId, details });
}
