import express, { type ErrorRequestHandler, type RequestHandler } from "express";
import { timingSafeEqual } from "node:crypto";
import { clerkMiddleware } from "@clerk/express";
import pinoHttp from "pino-http";
import { eq } from "drizzle-orm";
import { db, settingsTable } from "@workspace/db";
import router from "./routes";
import { logger } from "./lib/logger";
import { appOrigin, required } from "./lib/vercel-config";
import { ensureFollowUpAlerts } from "./lib/follow-up-alerts";

const app = express();
app.disable("x-powered-by");
const origin = appOrigin();
app.use(pinoHttp({
  logger,
  serializers: {
    req: req => ({ id: req.id, method: req.method, url: req.url?.split("?")[0] }),
    res: res => ({ statusCode: res.statusCode }),
  },
}));
app.use("/api", (_req, res, next) => {
  res.setHeader("Cache-Control", "private, no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  next();
});
const installationGuard: RequestHandler = async (_req, res, next) => {
  const [setting] = await db.select().from(settingsTable)
    .where(eq(settingsTable.key, "vercel_installation_id")).limit(1);
  if (setting?.value !== required("TABE_INSTALLATION_ID")) {
    res.status(503).json({ error: "قاعدة البيانات غير مهيأة لنسخة Vercel المستقلة" });
    return;
  }
  next();
};
app.use("/api", installationGuard);
app.get("/api/cron/follow-up", async (req, res) => {
  const expected = `Bearer ${required("CRON_SECRET")}`;
  const received = req.get("authorization") ?? "";
  if (received.length !== expected.length ||
    !timingSafeEqual(Buffer.from(received), Buffer.from(expected))) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  await ensureFollowUpAlerts();
  res.json({ ok: true });
});
app.use("/api", (req, res, next) => {
  // No cross-origin cookie writes, no wildcard credentialed CORS.
  if (!["GET", "HEAD", "OPTIONS"].includes(req.method) && req.get("origin") !== origin) {
    res.status(403).json({ error: "مصدر الطلب غير مسموح" });
    return;
  }
  next();
});
app.use(express.json({ limit: "256kb" }));
app.use(clerkMiddleware({
  publishableKey: required("CLERK_PUBLISHABLE_KEY"),
  secretKey: required("CLERK_SECRET_KEY"),
  authorizedParties: [origin],
}));
app.use("/api", router);
app.use((_req, res) => { res.status(404).json({ error: "Not found" }); });
const errorHandler: ErrorRequestHandler = (err, req, res, _next) => {
  req.log.error({ err }, "Request failed");
  if (!res.headersSent) res.status(500).json({ error: "تعذر تنفيذ الطلب" });
};
app.use(errorHandler);
export default app;
