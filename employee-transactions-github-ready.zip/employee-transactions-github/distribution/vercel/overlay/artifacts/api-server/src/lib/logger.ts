import pino from "pino";

// No worker-thread transports in a serverless function; never log signed URLs.
export const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  redact: ["req.headers.authorization", "req.headers.cookie", "res.headers.location",
    "res.headers['set-cookie']"],
});
