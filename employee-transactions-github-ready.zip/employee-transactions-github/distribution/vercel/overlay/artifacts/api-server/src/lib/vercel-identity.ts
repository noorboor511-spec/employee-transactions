// Pure, independently testable linking rules. Clerk is identity, not authorization.
export function verifiedEmail(profile: {
  primaryEmailAddressId: string | null;
  emailAddresses: Array<{ id: string; emailAddress: string; verification: { status: string } | null }>;
}): string | null {
  const primary = profile.emailAddresses.find(item => item.id === profile.primaryEmailAddressId);
  if (primary?.verification?.status !== "verified") return null;
  return primary.emailAddress.trim().toLowerCase() || null;
}
