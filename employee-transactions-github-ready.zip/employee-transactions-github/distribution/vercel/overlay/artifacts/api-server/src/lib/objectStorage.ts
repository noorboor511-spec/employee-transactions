import { randomUUID } from "node:crypto";
import { S3Client, PutObjectCommand, GetObjectCommand, HeadObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { required } from "./vercel-config";

export function objectKey(objectPath: string): string {
  if (!/^\/objects\/uploads\/[a-zA-Z0-9_-]+$/.test(objectPath)) throw new Error("Invalid private object path");
  return objectPath.slice("/objects/".length);
}

export class ObjectStorageService {
  private client?: S3Client;
  private getClient(): S3Client {
    return this.client ??= new S3Client({
      endpoint: required("TABE_S3_ENDPOINT"),
      region: required("TABE_S3_REGION"),
      // A presigned PUT has no body yet. Do not sign a checksum for an empty
      // body: browsers will upload the real bytes later.
      requestChecksumCalculation: "WHEN_REQUIRED",
      credentials: {
        accessKeyId: required("TABE_S3_ACCESS_KEY_ID"),
        secretAccessKey: required("TABE_S3_SECRET_ACCESS_KEY"),
      },
    });
  }
  private bucket(): string { return required("TABE_S3_BUCKET"); }
  async getObjectEntityUploadURL(contentType: string, size: number): Promise<string> {
    return getSignedUrl(this.getClient(), new PutObjectCommand({
      Bucket: this.bucket(), Key: `uploads/${randomUUID()}`,
      ContentType: contentType, ContentLength: size,
      // Immutable key: a signed URL cannot overwrite an already attached file.
      IfNoneMatch: "*",
    }), { expiresIn: 300, signableHeaders: new Set(["content-type", "content-length", "if-none-match"]),
      unhoistableHeaders: new Set(["if-none-match"]) });
  }
  normalizeObjectEntityPath(uploadURL: string): string {
    const url = new URL(uploadURL);
    const match = url.pathname.match(/\/(uploads\/[a-zA-Z0-9_-]+)$/);
    if (!match) throw new Error("Invalid upload path");
    return `/objects/${match[1]}`;
  }
  async verifyUpload(objectPath: string, contentType: string, size: number): Promise<boolean> {
    try {
      const head = await this.getClient().send(new HeadObjectCommand({
        Bucket: this.bucket(), Key: objectKey(objectPath),
      }));
      return head.ContentLength === size && head.ContentType === contentType;
    } catch (error) {
      if ((error as { $metadata?: { httpStatusCode?: number } }).$metadata?.httpStatusCode === 404) return false;
      throw error;
    }
  }
  async getDownloadURL(objectPath: string, fileName: string, contentType: string): Promise<string> {
    return getSignedUrl(this.getClient(), new GetObjectCommand({
      Bucket: this.bucket(), Key: objectKey(objectPath),
      ResponseContentType: contentType,
      ResponseContentDisposition: `attachment; filename*=UTF-8''${encodeURIComponent(fileName)}`,
      ResponseCacheControl: "private, no-store",
    }), { expiresIn: 60 });
  }
}
