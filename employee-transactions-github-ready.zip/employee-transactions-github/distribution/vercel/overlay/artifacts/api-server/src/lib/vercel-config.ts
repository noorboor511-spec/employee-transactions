export function required(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`Missing configuration: ${name}`);
  return value;
}

export function appOrigin(): string {
  const origin = required("APP_ORIGIN");
  const url = new URL(origin);
  if (url.origin !== origin || url.protocol !== "https:") {
    throw new Error("APP_ORIGIN must be one exact HTTPS origin without a trailing slash");
  }
  return origin;
}
