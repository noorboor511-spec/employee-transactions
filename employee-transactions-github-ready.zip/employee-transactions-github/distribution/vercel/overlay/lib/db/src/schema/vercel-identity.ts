import { integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { usersTable } from "./employee-transactions";

// Separate bindings: never overwrite the Replit Clerk subjects in a copied database.
export const vercelIdentityLinksTable = pgTable("vercel_identity_links", {
  userId: integer("user_id").primaryKey().references(() => usersTable.id),
  clerkSubject: text("clerk_subject").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
