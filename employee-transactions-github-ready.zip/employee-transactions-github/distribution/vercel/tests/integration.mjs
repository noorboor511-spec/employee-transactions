import assert from "node:assert/strict";
import { readFile, writeFile, rm } from "node:fs/promises";
import { createRequire } from "node:module";
import { createServer } from "node:http";
import { spawnSync } from "node:child_process";
import { build } from "esbuild";
import { profiles, token } from "./context.mjs";

// This suite may only use a new loopback fixture PostgreSQL supplied by run-tests.sh.
const url = process.env.TABE_TEST_DATABASE_URL;
assert.match(url ?? "", /^postgresql:\/\/runner@127\.0\.0\.1:\d+\/tabe_vercel_fixture$/);
process.env.DATABASE_URL = url;
process.env.NODE_ENV = "production";
process.env.APP_ORIGIN = "https://tabe.fixture.invalid";
process.env.TABE_INSTALLATION_ID = "6710917a-8343-488a-a567-837280a15312";
process.env.CLERK_PUBLISHABLE_KEY = `pk_test_${Buffer.from("clerk.fixture.invalid$").toString("base64")}`;
process.env.CLERK_SECRET_KEY = "sk_test_synthetic_fixture_only";
process.env.CRON_SECRET = "synthetic-fixture-cron-authorization-only";
process.env.LOG_LEVEL = "silent";
process.env.TABE_S3_BUCKET = "fixture-bucket";
process.env.TABE_S3_REGION = "us-east-1";
process.env.TABE_S3_ACCESS_KEY_ID = "synthetic-fixture-access";
process.env.TABE_S3_SECRET_ACCESS_KEY = "synthetic-fixture-secret";

const require = createRequire(new URL("../artifacts/api-server/package.json", import.meta.url));
const { Client } = createRequire(new URL("../lib/db/package.json", import.meta.url))("pg");
const client = new Client({ connectionString: url });
await client.connect();
const files = new Map();
const storage = createServer(async (req, res) => {
  const parsed = new URL(req.url, "http://fixture.invalid");
  const key = parsed.pathname.replace(/^\/fixture-bucket/, "");
  if (req.method === "PUT") {
    assert.match(parsed.searchParams.get("X-Amz-SignedHeaders"), /content-type/);
    assert.equal(req.headers["if-none-match"], "*");
    if (files.has(key)) { res.writeHead(412).end(); return; }
    const bytes = Buffer.concat(await Array.fromAsync(req));
    files.set(key, { bytes, type: req.headers["content-type"] });
    res.writeHead(200).end();
    return;
  }
  const file = files.get(key);
  if (!file) { res.writeHead(404).end(); return; }
  res.writeHead(200, { "content-type": file.type, "content-length": file.bytes.length });
  res.end(req.method === "HEAD" ? undefined : file.bytes);
});
await new Promise(resolve => storage.listen(0, "127.0.0.1", resolve));
process.env.TABE_S3_ENDPOINT = `http://127.0.0.1:${storage.address().port}`;
let server, replica, production;
const checks = [];
const ok = message => { checks.push(message); console.log(`PASS ${message}`); };
try {
  await client.query(await readFile(new URL("./schema.sql", import.meta.url), "utf8"));
  await client.query(`
    INSERT INTO departments(id,name) VALUES (1,'fixture department');
    INSERT INTO employees(id,name,email,department_id) VALUES
      (11,'fixture employee','employee@example.com',1),
      (12,'fixture other','other@example.com',1);
    INSERT INTO users(id,clerk_user_id,email,name,role,employee_id) VALUES
      (41,'legacy_owner','owner@example.com','Original name','supervisor',NULL),
      (42,'legacy_employee','employee@example.com','Employee original','employee',11),
      (43,NULL,'assistant@example.com','Supervisor original','supervisor',NULL),
      (44,NULL,'revoked@example.com','Revoked original','revoked',NULL),
      (45,NULL,'other@example.com','Other original','employee',12);
    SELECT setval('users_id_seq',45);
    INSERT INTO settings(key,value) VALUES ('primary_supervisor_id','41'), ('followUpDays','3'),
      ('statuses','["قيد الإجراء","مكتملة","متأخرة"]');
    INSERT INTO employee_transactions(id,number,subject,employee_id,department_id,type,received_at,current_entity,status,created_at) VALUES
      (101,'F-101','fixture own',11,1,'خطاب',now(),'fixture','قيد الإجراء',now()-interval '4 days'),
      (102,'F-102','fixture other',12,1,'خطاب',now(),'fixture','قيد الإجراء',now()-interval '4 days'),
      (103,'F-103','fixture completed',11,1,'خطاب',now(),'fixture','مكتملة',now()-interval '9 days');
  `);
  const baseline = (await client.query("SELECT * FROM users ORDER BY id")).rows;
  const prepare = args => spawnSync(process.execPath, ["--import", "tsx", "vercel-tools/prepare-database.ts", ...args], {
    env: process.env, encoding: "utf8",
  });
  assert.equal(prepare([]).status, 0);
  assert.equal((await client.query("SELECT * FROM settings WHERE key='vercel_installation_id'")).rowCount, 0);
  assert.equal(prepare(["--confirm-independent-copy", "--primary-user-id=43"]).status, 1);
  const prepared = prepare(["--confirm-independent-copy", "--primary-user-id=41"]);
  assert.equal(prepared.status, 0, prepared.stderr);
  assert.equal(prepare(["--confirm-independent-copy", "--primary-user-id=41"]).status, 0);
  assert.deepEqual((await client.query("SELECT * FROM users ORDER BY id")).rows, baseline);
  ok("Read-only preflight, explicit copy setup, idempotency and original owner/IDs/profile/roles/legacy Clerk preservation");
  const fixture = new URL("./clerk-fixture.ts", import.meta.url).pathname;
  const realClerk = require.resolve("@clerk/express");
  await build({
    entryPoints: ["artifacts/api-server/src/app.ts"], outfile: "tests/.test-server.mjs",
    bundle: true, platform: "node", format: "esm", target: "node22", external: ["pg-native"],
    banner: { js: 'import {createRequire as __cr} from "node:module"; const require=__cr(import.meta.url);' },
    plugins: [{
      name: "synthetic-clerk-profiles-real-jwt",
      setup(build) {
        build.onResolve({ filter: /^@clerk\/express$/ }, () => ({ path: fixture }));
        build.onResolve({ filter: /^clerk-real$/ }, () => ({ path: realClerk }));
        build.onResolve({ filter: /\/?context\.mjs$/ }, () => ({
          path: new URL("./context.mjs", import.meta.url).pathname, external: true,
        }));
      },
    }],
  });
  for (const [subject, email, status] of [
    ["user_owner", "owner@example.com", "verified"],
    ["user_employee", " EMPLOYEE@Example.Com ", "verified"],
    ["user_assistant", "assistant@example.com", "verified"],
    ["user_other", "other@example.com", "verified"],
    ["user_unverified", "owner@example.com", "unverified"],
    ["user_stranger", "stranger@example.com", "verified"],
    ["user_revoked", "revoked@example.com", "verified"],
    ["user_duplicate", "owner@example.com", "verified"],
  ]) profiles.set(subject, { primaryEmailAddressId: "email", emailAddresses: [
    { id: "email", emailAddress: email, verification: { status } },
  ] });
  const { default: app } = await import("./.test-server.mjs");
  server = createServer(app);
  await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const request = async (route, { subject, jwt, method = "GET", data, origin = process.env.APP_ORIGIN, headers = {} } = {}) => {
    const response = await fetch(base + "/api" + route, {
      method, redirect: "manual",
      headers: { origin, ...(subject ? { authorization: `Bearer ${token(subject)}` } : {}),
        ...(jwt ? { authorization: `Bearer ${jwt}` } : {}),
        ...(data ? { "content-type": "application/json" } : {}), ...headers },
      ...(data ? { body: JSON.stringify(data) } : {}),
    });
    const text = await response.text();
    let body; try { body = JSON.parse(text); } catch { body = text; }
    return { status: response.status, body, headers: response.headers };
  };
  assert.equal((await request("/auth/me")).status, 401);
  assert.equal((await request("/auth/me", { subject: "user_unverified" })).status, 403);
  assert.equal((await request("/auth/me", { subject: "user_stranger" })).status, 403);
  assert.equal((await request("/auth/me", { subject: "user_revoked" })).status, 403);
  const owner = await request("/auth/me", { subject: "user_owner" });
  assert.equal(owner.status, 200, JSON.stringify(owner.body));
  assert.equal(owner.body.id, 41);
  assert.equal(owner.body.name, "Original name");
  assert.equal(owner.body.role, "supervisor");
  assert.equal((await request("/auth/me", { jwt: token("user_owner", { azp: "https://attacker.invalid" }) })).status, 401);
  const expired = await request("/auth/me", { jwt: token("user_owner", { exp: 1 }) });
  assert.equal(expired.status, 401);
  assert.equal((await request("/auth/me", { subject: "user_duplicate" })).status, 403);
  const concurrent = await Promise.all(Array.from({ length: 5 }, () => request("/auth/me", { subject: "user_employee" })));
  for (const result of concurrent) {
    assert.equal(result.status, 200, JSON.stringify(result.body));
    assert.equal(result.body.id, 42);
    assert.equal(result.body.role, "employee");
  }
  assert.deepEqual((await client.query("SELECT * FROM users ORDER BY id")).rows, baseline);
  ok("Real RSA Clerk JWT verification, expiry/origin rejection, verified email linking, unknown/revoked denial and concurrent linking without changing accounts");
  const employee = { subject: "user_employee" };
  assert.equal((await request("/transactions/102", employee)).status, 404);
  assert.equal((await request("/reports", employee)).status, 403);
  assert.equal((await request("/transactions/102/updates", { ...employee, method: "POST", data: { status: "مكتملة", action: "forbidden" } })).status, 404);
  const beforeOpen = (await client.query("SELECT last_updated_at FROM employee_transactions WHERE id=101")).rows[0];
  assert.equal((await request("/transactions/101", employee)).status, 200);
  assert.deepEqual((await client.query("SELECT last_updated_at FROM employee_transactions WHERE id=101")).rows[0], beforeOpen);
  const assistant = { subject: "user_assistant" };
  assert.equal((await request("/branding", { ...assistant, method: "PATCH", data: { footerCredit: "blocked" } })).status, 403);
  assert.equal((await request("/branding", { subject: "user_owner", method: "PATCH", data: { footerCredit: "fixture credit" } })).status, 200);
  assert.equal((await request("/supervisors/41", { ...assistant, method: "DELETE" })).status, 403);
  assert.equal((await request("/supervisors/41", { subject: "user_owner", method: "DELETE" })).status, 409);
  const promote = await request("/supervisors", { ...assistant, method: "POST", data: { name: "fixture new supervisor", email: "promoted@example.com" } });
  assert.equal(promote.status, 201, JSON.stringify(promote.body));
  assert.equal((await request("/supervisors", { ...assistant, method: "POST", origin: "https://attacker.invalid",
    data: { name: "blocked", email: "blocked@example.com" } })).status, 403);
  ok("Employee transaction isolation, opening does not update timestamp, secondary supervisor can appoint but cannot revoke, primary stays protected, cross-origin writes denied");
  const bytes = Buffer.alloc(5 * 1024 * 1024, 65);
  const contentType = "application/pdf";
  const pending = await request("/storage/uploads/request-url", { ...employee, method: "POST",
    data: { transactionId: 101, name: "synthetic-large.pdf", size: bytes.length, contentType } });
  assert.equal(pending.status, 200, JSON.stringify(pending.body));
  const uploadURL = new URL(pending.body.uploadURL);
  assert.match(uploadURL.searchParams.get("X-Amz-SignedHeaders"), /content-length/);
  assert.match(uploadURL.searchParams.get("X-Amz-SignedHeaders"), /if-none-match/);
  assert.equal(uploadURL.searchParams.has("x-amz-checksum-crc32"), false);
  const attachment = { objectPath: pending.body.objectPath, fileName: "synthetic-large.pdf", size: bytes.length, contentType };
  assert.equal((await request("/transactions/101/updates", { ...employee, method: "POST",
    data: { status: "قيد الإجراء", action: "not uploaded", attachments: [attachment] } })).status, 400);
  const uploaded = await fetch(pending.body.uploadURL, { method: "PUT",
    headers: { "content-type": contentType, "if-none-match": "*" }, body: bytes });
  assert.equal(uploaded.status, 200);
  assert.equal((await fetch(pending.body.uploadURL, { method: "PUT",
    headers: { "content-type": contentType, "if-none-match": "*" }, body: bytes })).status, 412);
  const saved = await request("/transactions/101/updates", { ...employee, method: "POST",
    data: { status: "قيد الإجراء", action: "real synthetic update", attachments: [attachment] } });
  assert.equal(saved.status, 201, JSON.stringify(saved.body));
  const downloadPath = "/storage" + attachment.objectPath;
  assert.equal((await request(downloadPath)).status, 401);
  assert.equal((await request(downloadPath, { subject: "user_other" })).status, 404);
  const download = await request(downloadPath, employee);
  assert.equal(download.status, 302);
  assert.equal(download.headers.get("cache-control"), "private, no-store");
  const signed = new URL(download.headers.get("location"));
  assert.equal(signed.searchParams.get("X-Amz-Expires"), "60");
  assert.equal(Buffer.compare(Buffer.from(await (await fetch(signed)).arrayBuffer()), bytes), 0);
  const oversized = await request("/storage/uploads/request-url", { ...employee, method: "POST",
    data: { transactionId: 101, name: "too-big.pdf", size: 21 * 1024 * 1024, contentType } });
  assert.equal(oversized.status, 400);
  assert.equal((await request("/storage/uploads/request-url", { ...employee, method: "POST",
    data: { transactionId: 102, name: "forbidden.pdf", size: 30, contentType } })).status, 404);
  ok("Private 5 MB direct upload/download, immutable upload key, missing-upload rejection, 20 MB limit and unauthorized/other-employee download rejection");
  assert.equal((await request("/cron/follow-up")).status, 401);
  const cron = { headers: { authorization: `Bearer ${process.env.CRON_SECRET}` } };
  // Importing another bundle instance creates its own pool and in-memory state.
  // The PostgreSQL lock must serialize this process-independent scanner too.
  const { default: replicaApp } = await import("./.test-server.mjs?replica=2");
  replica = createServer(replicaApp);
  await new Promise(resolve => replica.listen(0, "127.0.0.1", resolve));
  const replicaScan = async () => fetch(`http://127.0.0.1:${replica.address().port}/api/cron/follow-up`, {
    headers: cron.headers,
  });
  const scans = await Promise.all(Array.from({ length: 6 }, (_, index) =>
    index % 2 ? replicaScan() : request("/cron/follow-up", cron)));
  scans.forEach(scan => assert.equal(scan.status, 200));
  await request("/notifications", { subject: "user_owner" });
  await request("/cron/follow-up", cron);
  const duplicateAlerts = await client.query(`SELECT user_id,transaction_id,type,count(*) FROM notifications
    WHERE type IN ('stale','overdue','follow_up_today','follow_up_missed')
    GROUP BY user_id,transaction_id,type HAVING count(*)>1`);
  assert.equal(duplicateAlerts.rowCount, 0);
  assert.equal((await client.query("SELECT * FROM notifications WHERE transaction_id=103")).rowCount, 0);
  assert.equal((await client.query("SELECT * FROM notifications WHERE transaction_id=102 AND type='stale'")).rowCount > 0, true);
  await client.query("UPDATE employees SET active=false WHERE id=11");
  assert.equal((await request("/auth/me", employee)).status, 403);
  await client.query("UPDATE settings SET value='\"different-installation\"' WHERE key='vercel_installation_id'");
  assert.equal((await request("/auth/me", { subject: "user_owner" })).status, 503);
  ok("Authorized Cron, repeated/concurrent notification scans do not duplicate, completed excluded, live deactivation and independent installation marker enforced");
  await client.query("UPDATE settings SET value=$1::jsonb WHERE key='vercel_installation_id'",
    [JSON.stringify(process.env.TABE_INSTALLATION_ID)]);
  // The actual standalone deployment bundle, with no SDK substitution, must load
  // without a workspace node_modules tree and serve public/unauthenticated API.
  const { default: productionApp } = await import("../.vercel/output/functions/api.func/index.mjs");
  production = createServer(productionApp);
  await new Promise(resolve => production.listen(0, "127.0.0.1", resolve));
  const productionBase = `http://127.0.0.1:${production.address().port}`;
  assert.equal((await fetch(productionBase + "/api/healthz")).status, 200);
  assert.equal((await fetch(productionBase + "/api/auth/me")).status, 401);
  const routing = JSON.parse(await readFile(".vercel/output/config.json", "utf8"));
  assert.equal(routing.version, 3);
  assert.match("/api/transactions/101", new RegExp(`^${routing.routes[0].src}$`));
  assert.equal(routing.routes[0].dest, "/api");
  assert.equal(routing.routes.at(-1).dest, "/index.html");
  assert.equal(routing.crons[0].schedule, "0 21 * * *");
  ok("Actual standalone production bundle cold-loads and serves health/401; API-first and SPA routing plus Hobby-compatible daily Cron output verified");
  await writeFile("tests/integration-results.json", JSON.stringify({ checks, externalServicesTested: false }, null, 2));
} finally {
  await new Promise(resolve => storage.close(resolve));
  if (server) await new Promise(resolve => server.close(resolve));
  if (replica) await new Promise(resolve => replica.close(resolve));
  if (production) await new Promise(resolve => production.close(resolve));
  await client.end();
  await rm("tests/.test-server.mjs", { force: true });
}
