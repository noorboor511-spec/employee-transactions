-- Synthetic schema only. Never extracted from a running application database.
CREATE TABLE departments(id serial PRIMARY KEY, name text NOT NULL UNIQUE, created_at timestamptz DEFAULT now() NOT NULL);
CREATE TABLE employees(id serial PRIMARY KEY, name text NOT NULL, email text NOT NULL UNIQUE,
  department_id integer NOT NULL REFERENCES departments(id), active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now());
CREATE UNIQUE INDEX employees_email_normalized_unique ON employees(lower(btrim(email)));
CREATE TABLE users(id serial PRIMARY KEY, clerk_user_id text UNIQUE, email text UNIQUE, name text NOT NULL,
  role text NOT NULL, employee_id integer REFERENCES employees(id), created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
CREATE UNIQUE INDEX users_email_normalized_unique ON users(lower(btrim(email)));
CREATE TABLE employee_transactions(id serial PRIMARY KEY, number text NOT NULL UNIQUE, subject text NOT NULL,
  employee_id integer NOT NULL REFERENCES employees(id), department_id integer NOT NULL REFERENCES departments(id),
  type text NOT NULL, received_at timestamptz NOT NULL, current_entity text NOT NULL, status text NOT NULL,
  priority text NOT NULL DEFAULT 'normal', last_updated_at timestamptz, next_follow_up_at timestamptz,
  notes text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE transaction_updates(id serial PRIMARY KEY, transaction_id integer NOT NULL REFERENCES employee_transactions(id),
  author_user_id integer NOT NULL REFERENCES users(id), previous_status text, new_status text NOT NULL, action text NOT NULL,
  notes text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE attachments(id serial PRIMARY KEY, transaction_update_id integer REFERENCES transaction_updates(id),
  uploaded_by integer NOT NULL REFERENCES users(id), file_name text NOT NULL, object_path text NOT NULL,
  content_type text NOT NULL, size integer NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE notifications(id serial PRIMARY KEY, user_id integer NOT NULL REFERENCES users(id), type text NOT NULL,
  message text NOT NULL, transaction_id integer REFERENCES employee_transactions(id), created_at timestamptz NOT NULL DEFAULT now(), read_at timestamptz);
CREATE TABLE settings(key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE audit_logs(id serial PRIMARY KEY, user_id integer REFERENCES users(id), action text NOT NULL,
  entity text NOT NULL, entity_id integer, details jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now());
