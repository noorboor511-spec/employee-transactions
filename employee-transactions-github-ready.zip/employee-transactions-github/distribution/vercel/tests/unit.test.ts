import assert from "node:assert/strict";
import { test } from "node:test";
import { verifiedEmail } from "../artifacts/api-server/src/lib/vercel-identity";
import { objectKey } from "../artifacts/api-server/src/lib/objectStorage";
import { classifyFollowUp } from "../artifacts/api-server/src/lib/follow-up";

test("independent identities require a verified PRIMARY email", () => {
  const profile = { primaryEmailAddressId: "primary", emailAddresses: [
    { id: "primary", emailAddress: " USER@Example.COM ", verification: { status: "verified" } },
    { id: "other", emailAddress: "other@example.com", verification: { status: "verified" } },
  ] };
  assert.equal(verifiedEmail(profile), "user@example.com");
  profile.emailAddresses[0].verification.status = "unverified";
  assert.equal(verifiedEmail(profile), null);
  profile.primaryEmailAddressId = "missing";
  assert.equal(verifiedEmail(profile), null);
});

test("private paths reject traversal, URL injection and foreign prefixes", () => {
  assert.equal(objectKey("/objects/uploads/f1-abc_12"), "uploads/f1-abc_12");
  for (const path of ["/objects/../settings", "/objects/uploads/../key", "/uploads/key",
    "https://attacker.invalid/file", "/objects/uploads/key?x=1", "/objects/uploads/%2fkey"]) {
    assert.throws(() => objectKey(path));
  }
});

test("follow-up includes full three-day boundary and excludes completed", () => {
  const now = new Date("2026-10-20T12:00:00Z");
  const t = { status: "قيد الإجراء", createdAt: new Date("2026-10-17T12:00:00Z"),
    lastUpdatedAt: null, nextFollowUpAt: null };
  assert.equal(classifyFollowUp(t, 3, now).needsFollowUp, true);
  assert.equal(classifyFollowUp(t, 3, new Date(now.getTime() - 1)).needsFollowUp, false);
  assert.equal(classifyFollowUp({ ...t, status: "مكتملة" }, 3, now).needsFollowUp, false);
});
