// Real JWT verification and getAuth; only the remote user-profile API is replaced.
import { clerkMiddleware as realMiddleware, getAuth } from "clerk-real";
import { publicKey, profiles } from "./context.mjs";
export { getAuth };
export const clerkClient = { users: {
  async getUser(subject: string) {
    const profile = profiles.get(subject);
    if (!profile) throw new Error("Missing synthetic profile");
    return profile;
  },
} };
export const clerkMiddleware = (options: object) => realMiddleware({ ...options, jwtKey: publicKey });
