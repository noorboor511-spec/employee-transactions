import { generateKeyPairSync, sign } from "node:crypto";
const keys = generateKeyPairSync("rsa", { modulusLength: 2048 });
export const publicKey = keys.publicKey.export({ type: "spki", format: "pem" });
export const profiles = new Map();
export function token(subject, overrides = {}) {
  const now = Math.floor(Date.now() / 1000);
  const encode = value => Buffer.from(JSON.stringify(value)).toString("base64url");
  const payload = {
    iss: "https://clerk.fixture.invalid", sub: subject, sid: "sess_fixture",
    azp: "https://tabe.fixture.invalid", iat: now, nbf: now - 10, exp: now + 300,
    v: 2, sts: "active", fva: [0, -1], ...overrides,
  };
  const data = `${encode({ alg: "RS256", typ: "JWT", kid: "fixture" })}.${encode(payload)}`;
  return `${data}.${sign("RSA-SHA256", Buffer.from(data), keys.privateKey).toString("base64url")}`;
}
