#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
PACKAGE="$ROOT/generated-artifacts/tabe-vercel"
PGROOT="$(mktemp -d /tmp/tabe-vercel-fixture.XXXXXX)"
PORT=55446
cleanup() {
  pg_ctl -D "$PGROOT/data" -m immediate stop >/dev/null 2>&1 || true
  rm -rf "$PGROOT"
}
trap cleanup EXIT
initdb -D "$PGROOT/data" -U runner -A trust --no-locale >/dev/null
pg_ctl -D "$PGROOT/data" -l "$PGROOT/postgres.log" -o "-h 127.0.0.1 -p $PORT -k $PGROOT" start >/dev/null
createdb -h 127.0.0.1 -p "$PORT" -U runner tabe_vercel_fixture
cd "$PACKAGE"
pnpm test
TABE_TEST_DATABASE_URL="postgresql://runner@127.0.0.1:$PORT/tabe_vercel_fixture" node tests/integration.mjs
