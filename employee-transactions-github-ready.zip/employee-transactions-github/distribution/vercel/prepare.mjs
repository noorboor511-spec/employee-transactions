import { cp, mkdir, readFile, writeFile, lstat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(here, "../..");
// Never copy a database, .env, generated bundle, backup, or node_modules.
const target = path.join(repo, "generated-artifacts/tabe-vercel");
try {
  await lstat(target);
  throw new Error("Destination already exists; move it aside before preparing a new package.");
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
await mkdir(target, { recursive: true });
const excluded = new Set(["node_modules", "dist", ".replit-artifact", ".tsbuildinfo"]);
const filter = (file) => !excluded.has(path.basename(file)) &&
  !path.basename(file).startsWith(".env") && !file.endsWith(".tsbuildinfo");
for (const relative of [
  "artifacts/api-server/src", "artifacts/api-server/tsconfig.json",
  "artifacts/api-server/package.json",
  "artifacts/employee-transactions/src", "artifacts/employee-transactions/public",
  "artifacts/employee-transactions/index.html", "artifacts/employee-transactions/package.json",
  "artifacts/employee-transactions/tsconfig.json",
  "lib/db", "lib/api-zod", "lib/api-client-react",
  "tsconfig.json", "tsconfig.base.json", ".npmrc",
]) {
  await cp(path.join(repo, relative), path.join(target, relative), { recursive: true, filter });
}
await cp(path.join(here, "overlay"), target, { recursive: true });
await cp(path.join(here, "README-VERCEL.md"), path.join(target, "README-VERCEL.md"));
await cp(path.join(here, "TEST-REPORT.md"), path.join(target, "TEST-REPORT.md"));
await cp(path.join(here, "pnpm-lock.yaml"), path.join(target, "pnpm-lock.yaml"));
await cp(path.join(here, "tests"), path.join(target, "tests"), { recursive: true });
const json = async (relative, change) => {
  const filename = path.join(target, relative);
  const value = JSON.parse(await readFile(filename, "utf8"));
  await writeFile(filename, JSON.stringify(change(value), null, 2) + "\n");
};
const replace = async (relative, before, after) => {
  const filename = path.join(target, relative);
  const source = await readFile(filename, "utf8");
  if (source.split(before).length !== 2) throw new Error(`Source changed; inspect adaptation: ${relative}`);
  await writeFile(filename, source.replace(before, after));
};

// Keep shared business logic, role checks, IDs, frontend and API contracts.
await json("artifacts/api-server/package.json", (pkg) => {
  for (const dep of ["@google-cloud/storage", "google-auth-library", "http-proxy-middleware"]) delete pkg.dependencies[dep];
  pkg.dependencies["@aws-sdk/client-s3"] = "^3.922.0";
  pkg.dependencies["@aws-sdk/s3-request-presigner"] = "^3.922.0";
  pkg.dependencies["@vercel/functions"] = "^3.3.0";
  pkg.scripts = { typecheck: "tsc -p tsconfig.json --noEmit" };
  return pkg;
});
// Unused Replit-specific modules must not import unavailable sidecar dependencies.
for (const file of ["artifacts/api-server/src/lib/objectAcl.ts",
  "artifacts/api-server/src/middlewares/clerkProxyMiddleware.ts",
  "artifacts/api-server/src/index.ts"]) {
  const { unlink } = await import("node:fs/promises");
  await unlink(path.join(target, file));
}
await json("artifacts/employee-transactions/package.json", (pkg) => {
  for (const dep of Object.keys(pkg.devDependencies)) if (dep.startsWith("@replit/")) delete pkg.devDependencies[dep];
  pkg.scripts.build = "vite build --config vite.config.ts";
  return pkg;
});
await json("lib/db/package.json", (pkg) => {
  pkg.dependencies["@vercel/functions"] = "^3.3.0";
  return pkg;
});
await writeFile(path.join(target, "lib/db/src/schema/index.ts"),
  (await readFile(path.join(target, "lib/db/src/schema/index.ts"), "utf8")) +
  '\nexport * from "./vercel-identity";\n');
await replace("artifacts/employee-transactions/src/App.tsx",
  "import { publishableKeyFromHost } from '@clerk/react/internal';", "");
await replace("artifacts/employee-transactions/src/App.tsx",
  "const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);",
  "const clerkPubKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;");
await replace("artifacts/employee-transactions/src/App.tsx",
  "const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;", "");
await replace("artifacts/employee-transactions/src/App.tsx", " proxyUrl={clerkProxyUrl}", "");
await replace("artifacts/employee-transactions/src/App.tsx",
  "headers:{'Content-Type':file.type||'application/octet-stream'},body:file",
  "headers:{'Content-Type':file.type||'application/octet-stream','If-None-Match':'*'},body:file");
await replace("artifacts/api-server/src/routes/employee-transactions.ts",
  "await storage.getObjectEntityUploadURL()", "await storage.getObjectEntityUploadURL(body.contentType, body.size)");
await replace("artifacts/api-server/src/routes/employee-transactions.ts",
  "  const update = await db.transaction(async (tx) => {",
  `  for (const attachment of pendingAttachments) {
    if (!await storage.verifyUpload(attachment.objectPath, attachment.contentType, attachment.size)) {
      res.status(400).json({ error: "لم يكتمل رفع المرفق أو لا يطابق حجمه ونوعه المصرح بهما" });
      return;
    }
  }
  const update = await db.transaction(async (tx) => {`);
await replace("artifacts/api-server/src/routes/employee-transactions.ts",
  `.select({ objectPath: attachmentsTable.objectPath })`,
  `.select({ objectPath: attachmentsTable.objectPath, fileName: attachmentsTable.fileName, contentType: attachmentsTable.contentType })`);
await replace("artifacts/api-server/src/routes/employee-transactions.ts",
  `    const file = await storage.getObjectEntityFile(objectPath);
    const response = await storage.downloadObject(file, 60);
    const bytes = Buffer.from(await response.arrayBuffer());
    res.setHeader(
      "Content-Type",
      response.headers.get("content-type") ?? "application/octet-stream",
    );
    res.setHeader(
      "Content-Disposition",
      \`inline; filename*=UTF-8''\${encodeURIComponent(objectPath.split("/").at(-1) ?? "file")}\`,
    );
    res.send(bytes);`,
  `    // Authorization above remains mandatory; file bytes bypass Vercel's 4.5 MB limit.
    const downloadURL = await storage.getDownloadURL(objectPath, attachment.fileName, attachment.contentType);
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.redirect(302, downloadURL);`);

// Lock across function instances, not just overlapping calls in one process.
await replace("artifacts/api-server/src/lib/follow-up-alerts.ts",
  'import { and, eq, gte }', 'import { and, eq, gte, sql }');
await replace("artifacts/api-server/src/lib/follow-up-alerts.ts",
  `async function scan(): Promise<void> {`,
  `async function scan(): Promise<void> {
  await db.transaction(async (tx) => {
    await tx.execute(sql\`SET LOCAL statement_timeout = '40000'\`);
    const lock = await tx.execute(sql\`SELECT pg_try_advisory_xact_lock(82741062) AS acquired\`);
    if (!lock.rows[0]?.acquired) return;
    await scanLocked(tx);
  });
}
type ScanTransaction = Parameters<Parameters<typeof db.transaction>[0]>[0];
async function scanLocked(db: ScanTransaction): Promise<void> {`);
// In the copy only: refuse silent ownership reassignment if setup is incomplete.
const footerFile = "artifacts/api-server/src/lib/footer-permissions.ts";
const footer = await readFile(path.join(target, footerFile), "utf8");
const start = footer.indexOf("  const [original]");
const end = footer.indexOf("\n}\n", start);
if (start < 0 || end < start) throw new Error("Primary supervisor adaptation needs inspection");
await writeFile(path.join(target, footerFile), footer.slice(0, start) + "  return null;" + footer.slice(end));
// Record only that no export is included, never real account counts or identifiers.
await writeFile(path.join(target, "PACKAGE-SCOPE.json"), JSON.stringify({
  dataIncluded: false, attachmentsIncluded: false, credentialsIncluded: false,
  independentClerk: true, sourceApplicationModified: false,
}, null, 2));
// Include portable catalog pins, but none of the host-specific native-package exclusions.
const workspace = await readFile(path.join(repo, "pnpm-workspace.yaml"), "utf8");
const catalog = workspace.slice(workspace.indexOf("catalog:"), workspace.indexOf("\nautoInstallPeers:"));
await writeFile(path.join(target, "pnpm-workspace.yaml"),
  `minimumReleaseAge: 1440\nmanagePackageManagerVersions: false\npackages:\n  - artifacts/*\n  - lib/*\n\n${catalog}\nautoInstallPeers: false\nonlyBuiltDependencies:\n  - esbuild\n`);
console.log("Prepared source-only Vercel package at generated-artifacts/tabe-vercel");
