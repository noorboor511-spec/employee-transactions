import { build } from "../artifacts/api-server/node_modules/esbuild/lib/main.js";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";

const dir = await mkdtemp(join(tmpdir(), "department-admin-tests-"));
const outfile = join(dir, "departments-admin.test.mjs");

try {
  await build({
    entryPoints: ["artifacts/api-server/src/routes/departments-admin.test.ts"],
    outfile,
    bundle: true,
    platform: "node",
    format: "esm",
    banner: { js: "import {createRequire} from 'node:module'; const require=createRequire(import.meta.url);" },
    plugins: [{
      name: "isolated-department-admin-fixtures",
      setup(builder) {
        builder.onResolve({ filter: /^@workspace\/db$/ }, () => ({ path: "db", namespace: "fixture" }));
        builder.onResolve({ filter: /^drizzle-orm$/ }, () => ({ path: "drizzle", namespace: "fixture" }));
        builder.onResolve({ filter: /^\.\.\/lib\/auth$/ }, () => ({ path: "auth", namespace: "fixture" }));
        builder.onLoad({ filter: /.*/, namespace: "fixture" }, (args) => ({
          loader: "js",
          contents: args.path === "drizzle" ? `
            export const eq=(column,value)=>({kind:'eq',column,value});
            export const sql=()=>({kind:'sql'});
          ` : args.path === "auth" ? `
            export const requireAppUser=(req,res,next)=>{
              const role=req.headers['x-test-role'];
              if(!role) return res.status(401).json({error:'Not signed in'});
              req.appUser={id:Number(req.headers['x-test-id']||901),role};
              next();
            };
          ` : `
            export const departmentsTable={
              __table:'departments',
              id:{__table:'departments',field:'id'},
              name:{__table:'departments',field:'name'}
            };
            export const employeesTable={
              __table:'employees',
              id:{__table:'employees',field:'id'},
              departmentId:{__table:'employees',field:'departmentId'}
            };
            export const transactionsTable={
              __table:'transactions',
              id:{__table:'transactions',field:'id'},
              departmentId:{__table:'transactions',field:'departmentId'}
            };
            export const settingsTable={
              __table:'settings',
              key:{__table:'settings',field:'key'},
              value:{__table:'settings',field:'value'}
            };
            export const usersTable={
              __table:'users',
              id:{__table:'users',field:'id'},
              role:{__table:'users',field:'role'}
            };
            export const auditLogsTable={__table:'audits'};
            export const departmentManagementTestState={
              departments:[], employees:[], transactions:[], audits:[],
              lockCount:0, nextDepartmentId:1, primaryId:901
            };
            const state=departmentManagementTestState;
            const tableRows=(table)=>{
              if(table===departmentsTable) return state.departments;
              if(table===employeesTable) return state.employees;
              if(table===transactionsTable) return state.transactions;
              if(table===settingsTable) return [{key:'primary_supervisor_id',value:state.primaryId}];
              return [];
            };
            const matches=(row,condition)=>{
              if(!condition) return true;
              return condition.kind==='eq' && row[condition.column.field]===condition.value;
            };
            const makeSelect=(columns)=>{
              let table, condition, take=Infinity;
              const query={
                from(value){table=value;return query;},
                where(value){condition=value;return query;},
                limit(value){take=value;return query;},
                for(){return query;},
                orderBy(){return query;},
                then(resolve,reject){
                  return Promise.resolve(tableRows(table).filter(row=>matches(row,condition)).slice(0,take))
                    .then(resolve,reject);
                }
              };
              return query;
            };
            const makeExecutor=()=>({
              execute:async()=>{state.lockCount++;return {rows:[]};},
              select:makeSelect,
              insert(table){
                return {values(value){
                  if(table===departmentsTable){
                    const row={id:state.nextDepartmentId++,name:value.name};
                    state.departments.push(row);
                    return {returning:async()=>[row]};
                  }
                  if(table===auditLogsTable) state.audits.push(value);
                  return {};
                }};
              },
              update(table){
                return {set(values){
                  return {where(condition){
                    return {returning:async()=>{
                      const row=tableRows(table).find(item=>matches(item,condition));
                      if(!row) return [];
                      Object.assign(row,values);
                      return [row];
                    }};
                  }};
                }};
              },
              delete(table){
                return {where(condition){
                  const rows=tableRows(table);
                  const index=rows.findIndex(row=>matches(row,condition));
                  if(index>=0) rows.splice(index,1);
                  return {};
                }};
              }
            });
            const db=makeExecutor();
            db.transaction=async(callback)=>callback(makeExecutor());
            export {db};
          `,
        }));
      },
    }],
  });
  const result = spawnSync(process.execPath, ["--test", outfile], { stdio: "inherit" });
  process.exitCode = result.status ?? 1;
} finally {
  await rm(dir, { recursive: true, force: true });
}
