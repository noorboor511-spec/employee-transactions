// Exercise the actual router and auth middleware against an isolated in-memory DB.
// No real users, Clerk identities, database rows or transaction records are touched.
import { build } from "../artifacts/api-server/node_modules/esbuild/lib/main.js";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const dir = await mkdtemp(join(tmpdir(), "supervisor-tests-"));
try {
  const outfile = join(dir, "supervisors.test.mjs");
  await build({
    stdin: {
      resolveDir: resolve("artifacts/api-server"),
      sourcefile: "supervisors.test.ts", loader: "ts",
      contents: `
        import test from 'node:test';
        import assert from 'node:assert/strict';
        import express from 'express';
        import router from './src/routes/supervisors';
        import {requireAppUser,supervisorOnly} from './src/lib/auth';
        import {state} from '@workspace/db';
        process.env.NODE_ENV='production';
        test('only the original supervisor can revoke; identities and history survive',async()=>{
          const app=express(); app.use(express.json());
          app.use((req,res,next)=>{req.log={error(){}};next();});
          app.use('/api',router);
          app.get('/api/me',requireAppUser,(req,res)=>res.json(req.appUser));
          app.get('/api/admin',requireAppUser,supervisorOnly,(req,res)=>res.json({ok:true}));
          app.use((err,req,res,next)=>res.status(500).json({error:'test failure'}));
          const server=app.listen(0,'127.0.0.1');
          await new Promise(resolve=>server.once('listening',resolve));
          const url='http://127.0.0.1:'+server.address().port;
          const request=async(path,subject,method='GET',body)=>{
            const response=await fetch(url+path,{method,headers:{...(subject?{'x-test-sub':subject}:{}),'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});
            return {status:response.status,body:await response.json()};
          };
          const baseline=structuredClone(state.history);
          try {
            assert.equal((await request('/api/supervisors/902',null,'DELETE')).status,401);
            assert.equal((await request('/api/supervisors/902','staff','DELETE')).status,403);
            assert.equal((await request('/api/supervisors/902','unlinked','DELETE',{role:'supervisor',canRevoke:true})).status,403);
            assert.equal((await request('/api/supervisors/901','primary','DELETE')).status,409);
            assert.equal((await request('/api/supervisors/0','primary','DELETE')).status,400);
            assert.equal((await request('/api/supervisors/902abc','primary','DELETE')).status,400);
            assert.equal((await request('/api/supervisors/9999','primary','DELETE')).status,404);
            const principalList=await request('/api/supervisors','primary');
            assert.equal(principalList.body.find(u=>u.id===901).canRevoke,false);
            assert.equal(principalList.body.find(u=>u.id===902).canRevoke,true);
            assert.ok((await request('/api/supervisors','unlinked')).body.every(u=>!u.canRevoke));

            const linked=structuredClone(state.users.find(u=>u.id===902));
            assert.deepEqual((await request('/api/supervisors/902','primary','DELETE')).body,{id:902,role:'employee'});
            const updated=state.users.find(u=>u.id===902);
            for(const field of ['id','name','email','clerkUserId','employeeId','createdAt'])
              assert.equal(updated[field],linked[field],field+' must be preserved');
            assert.equal((await request('/api/me','linked')).body.role,'employee');
            assert.equal((await request('/api/admin','linked')).status,403);
            assert.equal((await request('/api/supervisors/903','linked','DELETE')).status,403);
            assert.equal((await request('/api/supervisors/902','primary','DELETE')).status,404);

            const standalone=structuredClone(state.users.find(u=>u.id===903));
            assert.deepEqual((await request('/api/supervisors/903','primary','DELETE')).body,{id:903,role:'revoked'});
            for(const field of ['id','name','email','clerkUserId','employeeId','createdAt'])
              assert.equal(state.users.find(u=>u.id===903)[field],standalone[field]);
            assert.equal((await request('/api/me','unlinked')).status,403);
            assert.equal((await request('/api/admin','unlinked')).status,403);
            assert.deepEqual((await request('/api/supervisors','primary')).body.map(u=>u.id),[901]);
            assert.equal(state.users.length,4);
            assert.deepEqual(state.history,baseline);
            assert.deepEqual(state.audits.map(a=>[a.userId,a.action,a.entityId,a.details.role]),[
              [901,'revoke_supervisor',902,'employee'],[901,'revoke_supervisor',903,'revoked']
            ]);
            // Existing appointment flow still allows another supervisor to appoint.
            state.users[2].role='supervisor';
            const promoted=await request('/api/supervisors','unlinked','POST',{name:'Ignored',email:'linked@example.com'});
            assert.equal(promoted.status,201);
            assert.equal(promoted.body.name,linked.name);
            assert.equal(promoted.body.canRevoke,false);
            assert.equal((await request('/api/admin','linked')).status,200);
            // A failed audit must not leave a half-applied role change.
            state.failAudit=true;
            assert.equal((await request('/api/supervisors/902','primary','DELETE')).status,500);
            assert.equal(state.users.find(u=>u.id===902).role,'supervisor');
            assert.deepEqual(state.history,baseline);
          } finally {
            server.closeAllConnections();
            await new Promise(resolve=>server.close(resolve));
          }
        });
      `,
    },
    outfile, bundle: true, platform: "node", format: "esm",
    banner: { js: "import {createRequire} from 'node:module'; const require=createRequire(import.meta.url);" },
    plugins: [{
      name: "isolated-auth-and-db",
      setup(builder) {
        builder.onResolve({ filter: /^(@workspace\/db|@clerk\/express|drizzle-orm)$/ }, args =>
          ({ path: args.path, namespace: "fixture" }));
        builder.onLoad({ filter: /.*/, namespace: "fixture" }, args => ({
          loader: "js",
          contents: args.path === "drizzle-orm" ? `
            export const eq=(field,value)=>row=>row[field.split('.').pop()]===value;
            export const and=(...predicates)=>row=>predicates.every(p=>p(row));
            export const isNull=field=>row=>row[field.split('.').pop()]==null;
          ` : args.path === "@clerk/express" ? `
            export const getAuth=req=>({userId:req.headers['x-test-sub']});
            export const clerkClient={users:{getUser(){throw new Error('Unexpected external Clerk request');}}};
          ` : `
            const table=(name,keys)=>Object.fromEntries([['table',name],...keys.map(k=>[k,name+'.'+k])]);
            export const usersTable=table('users',['id','name','email','role','clerkUserId','employeeId']);
            export const settingsTable=table('settings',['key','value']);
            export const employeesTable=table('employees',['id','active']);
            export const auditLogsTable=table('audits',[]);
            export const state={
              users:[
                {id:901,name:'Principal',email:'primary@example.com',role:'supervisor',clerkUserId:'primary',employeeId:null,createdAt:'baseline'},
                {id:902,name:'Linked',email:'linked@example.com',role:'supervisor',clerkUserId:'linked',employeeId:501,createdAt:'baseline'},
                {id:903,name:'Unlinked',email:'unlinked@example.com',role:'supervisor',clerkUserId:'unlinked',employeeId:null,createdAt:'baseline'},
                {id:904,name:'Staff',email:'staff@example.com',role:'employee',clerkUserId:'staff',employeeId:502,createdAt:'baseline'}
              ],
              settings:[{key:'primary_supervisor_id',value:901}],
              employees:[{id:501,active:true},{id:502,active:true}],
              audits:[],failAudit:false,
              history:{transactions:[{id:41,employeeId:501}],updates:[{authorUserId:902,text:'Original update'},{authorUserId:903,text:'Original update'}],attachments:[{uploadedBy:903,path:'untouched'}]}
            };
            const project=(row,columns)=>!columns?{...row}:Object.fromEntries(Object.entries(columns).map(([key,field])=>[key,row[field.split('.').pop()]]));
            export const db={
              select:columns=>({from:table=>{
                let predicate=()=>true,limit=Infinity;
                const rows=()=>state[table.table].filter(predicate).slice(0,limit).map(row=>project(row,columns));
                const query={
                  where(p){predicate=p;return query;},orderBy(){return query;},
                  limit(n){limit=n;return query;},for(){return query;},
                  then(resolve,reject){return Promise.resolve(rows()).then(resolve,reject);}
                };return query;
              }}),
              update:table=>({set:values=>({where:predicate=>{
                const execute=()=>state[table.table].filter(predicate).map(row=>{Object.assign(row,values);return {...row};});
                return {returning:async()=>execute(),then:(resolve,reject)=>Promise.resolve(execute()).then(resolve,reject)};
              }})}),
              insert:table=>({values:value=>{
                if(table===auditLogsTable){
                  if(state.failAudit) return Promise.reject(new Error('Isolated audit failure'));
                  state.audits.push(value);return Promise.resolve();
                }
                return {onConflictDoUpdate:({set})=>({returning:async columns=>{
                  let row=state.users.find(u=>u.email===value.email);
                  if(row) Object.assign(row,set);
                  else {row={...value,id:1000,employeeId:null,clerkUserId:null};state.users.push(row);}
                  return [project(row,columns)];
                }})};
              }}),
              transaction:async callback=>{
                const backup=structuredClone({users:state.users,audits:state.audits});
                try{return await callback(db);}catch(error){Object.assign(state,backup);throw error;}
              }
            };
          `,
        }));
      },
    }],
  });
  const result = spawnSync(process.execPath, ["--test", outfile], { stdio: "inherit" });
  process.exitCode = result.status ?? 1;
} finally {
  await rm(dir, { recursive: true, force: true });
}
