#Requires -Version 7.2
<#
Backs up the Taabi' Production PostgreSQL database and its attachment files.
This script does not change the Production database. It performs SELECT queries,
pg_dump, encryption, and a restore into a disposable localhost-only PostgreSQL
cluster under %TEMP%.

Before running:
  1. Check PowerShell with:
       pwsh.exe -NoProfile -Command '$PSVersionTable.PSVersion; $PSVersionTable.PSEdition'
     It must report version 7.2 or later and edition Core.
  2. Add the existing PostgreSQL 18.6 bin folder and age to PATH.
     After reading Production's actual server version, provide a separate
     PostgreSQL bin folder of that exact version for the dump and isolated restore.
     Do not install a service or point initdb at an existing database directory.
   3. Download each attachment through the link for its exact attachment record
      in the published app, then name the local file attachment-<id>.bin.
      The application schema has no source-side file checksum; the user must
      confirm the per-record link mapping. SHA-256 checks protect later copies.
  4. Run with pwsh.exe, not powershell.exe:
       pwsh.exe -NoProfile -File .\scripts\backup-production-windows.ps1
     Use a new terminal without PowerShell transcripts.

The Production connection URL is entered as a hidden SecureString prompt. The
age passphrase is entered by age itself (hidden, never passed on the command line).
No credentials or passphrases are written to the project or backup files.
Temporary files are normally deleted, not securely erased; encrypted volumes
are required before any Production connection.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:ProjectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..')).TrimEnd('\', '/')
$script:ExpectedProductionDatabase = 'neondb'
$script:KnownDevelopmentDatabase = 'heliumdb'
$originalPgEnvironment = @{}
$processPgKeys = @(
  [Environment]::GetEnvironmentVariables('Process').Keys |
    Where-Object { [string]$_ -like 'PG*' } |
    ForEach-Object { [string]$_ }
)
$script:PgEnvironmentKeys = @(
  $processPgKeys + @(
    'PGHOST', 'PGPORT', 'PGDATABASE', 'PGUSER', 'PGPASSWORD',
    'PGSSLMODE', 'PGSSLROOTCERT', 'PGSSLCERT', 'PGSSLKEY', 'PGSSLCRL',
    'PGSSLCRLDIR', 'PGSSLMINPROTOCOLVERSION', 'PGSSLMAXPROTOCOLVERSION',
    'PGCHANNELBINDING'
  ) | Sort-Object -Unique
)
foreach ($key in $processPgKeys) {
  $existingValue = [Environment]::GetEnvironmentVariable($key, 'Process')
  if ($null -ne $existingValue) { $originalPgEnvironment[$key] = $existingValue }
}

function Assert-PowerShellCore {
  if ($PSVersionTable.PSEdition -ne 'Core' -or
      $PSVersionTable.PSVersion -lt [Version]'7.2') {
    throw 'Run this file with pwsh.exe version 7.2 or later. No database action was started.'
  }
}

function Get-ExecutablePath {
  param([Parameter(Mandatory)][string]$Name)
  $command = Get-Command "$Name.exe" -CommandType Application -ErrorAction SilentlyContinue
  if (-not $command) { throw "Required tool is missing from PATH: $Name.exe" }
  return $command.Source
}

function Get-PlainTextFromSecureString {
  param([Parameter(Mandatory)][Security.SecureString]$Value)
  $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
  try {
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
  }
  finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
  }
}

function Parse-PostgresUri {
  param([Parameter(Mandatory)][string]$Value)

  try {
    $uri = [Uri]::new($Value)
    if ($uri.Scheme -notin @('postgres', 'postgresql')) { throw 'scheme' }

    $encodedUserInfo = $uri.GetComponents([UriComponents]::UserInfo, [UriFormat]::UriEscaped)
    $separator = $encodedUserInfo.IndexOf(':')
    if ($separator -lt 1) { throw 'userinfo' }

    $username = [Uri]::UnescapeDataString($encodedUserInfo.Substring(0, $separator))
    $password = [Uri]::UnescapeDataString($encodedUserInfo.Substring($separator + 1))
    $database = [Uri]::UnescapeDataString($uri.AbsolutePath.Trim('/'))
    if ($database.Contains('/')) { $database = $database.Split('/')[0] }
    if ([string]::IsNullOrWhiteSpace($username) -or
        [string]::IsNullOrWhiteSpace($database) -or
        [string]::IsNullOrWhiteSpace($uri.Host)) {
      throw 'missing'
    }

    $query = @{}
    foreach ($part in ($uri.Query.TrimStart('?') -split '&')) {
      if ([string]::IsNullOrWhiteSpace($part)) { continue }
      $pair = $part -split '=', 2
      $key = [Uri]::UnescapeDataString($pair[0]).ToLowerInvariant()
      if ($query.ContainsKey($key)) { throw 'duplicate query parameter' }
      $query[$key] = if ($pair.Count -gt 1) {
        [Uri]::UnescapeDataString($pair[1])
      } else {
        ''
      }
    }

    $sslMode = if ($query.ContainsKey('sslmode')) {
      $query['sslmode'].ToLowerInvariant()
    } elseif (-not [string]::IsNullOrWhiteSpace($env:PGSSLMODE)) {
      $env:PGSSLMODE.ToLowerInvariant()
    } else {
      throw 'An explicit TLS mode is required.'
    }
    if ($sslMode -cne 'verify-full') {
      throw 'verify-full is required.'
    }

    return [pscustomobject]@{
      Host = $uri.Host
      Port = if ($uri.IsDefaultPort) { 5432 } else { $uri.Port }
      Database = $database
      Username = $username
      Password = $password
      SslMode = $sslMode
      SslRootCert = if ($query.ContainsKey('sslrootcert')) { [string]$query['sslrootcert'] } else { [string]$env:PGSSLROOTCERT }
      SslCert = if ($query.ContainsKey('sslcert')) { [string]$query['sslcert'] } else { [string]$env:PGSSLCERT }
      SslKey = if ($query.ContainsKey('sslkey')) { [string]$query['sslkey'] } else { [string]$env:PGSSLKEY }
      SslCrl = if ($query.ContainsKey('sslcrl')) { [string]$query['sslcrl'] } else { [string]$env:PGSSLCRL }
      SslCrlDir = if ($query.ContainsKey('sslcrldir')) { [string]$query['sslcrldir'] } else { [string]$env:PGSSLCRLDIR }
      SslMinProtocolVersion = if ($query.ContainsKey('ssl_min_protocol_version')) { [string]$query['ssl_min_protocol_version'] } else { [string]$env:PGSSLMINPROTOCOLVERSION }
      SslMaxProtocolVersion = if ($query.ContainsKey('ssl_max_protocol_version')) { [string]$query['ssl_max_protocol_version'] } else { [string]$env:PGSSLMAXPROTOCOLVERSION }
      ChannelBinding = if ($query.ContainsKey('channel_binding')) { [string]$query['channel_binding'] } else { [string]$env:PGCHANNELBINDING }
    }
  }
  catch {
    throw 'The supplied connection URL or TLS settings are invalid or incomplete. No value was printed.'
  }
}

function Invoke-NativeQuietly {
  param(
    [Parameter(Mandatory)][string]$Executable,
    [Parameter(Mandatory)][string[]]$Arguments,
    [Parameter(Mandatory)][string]$FailureMessage
  )

  & $Executable @Arguments *> $null
  if ($LASTEXITCODE -ne 0) { throw $FailureMessage }
}

function Get-PostgresToolchain {
  param([string]$BinDirectory)

  $names = @(
    'pg_dump', 'pg_restore', 'psql', 'initdb', 'pg_ctl', 'postgres', 'createdb'
  )
  $paths = @{}
  $versions = @{}
  if (-not [string]::IsNullOrWhiteSpace($BinDirectory)) {
    if (-not (Test-Path -LiteralPath $BinDirectory -PathType Container)) {
      throw 'The selected PostgreSQL bin folder was not found.'
    }
    $BinDirectory = (Resolve-Path -LiteralPath $BinDirectory).Path
  }
  foreach ($name in $names) {
    if ([string]::IsNullOrWhiteSpace($BinDirectory)) {
      $paths[$name] = Get-ExecutablePath $name
    } else {
      $candidate = Join-Path $BinDirectory "$name.exe"
      if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
        throw 'The selected PostgreSQL installation is missing a required executable.'
      }
      $paths[$name] = (Resolve-Path -LiteralPath $candidate).Path
    }
    $versionLines = & $paths[$name] --version 2>$null
    if ($LASTEXITCODE -ne 0) {
      throw "Could not safely verify the version of $name.exe. No database action was started."
    }
    $versionText = ($versionLines -join ' ').Trim()
    if ($versionText -notmatch '\(PostgreSQL\)\s+(\d+\.\d+(?:\.\d+)?)\b') {
      throw "Could not safely verify the version of $name.exe. No database action was started."
    }
    $versions[$name] = $Matches[1]
  }

  $uniqueVersions = @($versions.Values | Sort-Object -Unique)
  if ($uniqueVersions.Count -ne 1) {
    throw 'PostgreSQL tools do not have one matching version. Align the tools before continuing.'
  }
  $binDirectories = @(
    $paths.Values | ForEach-Object { [IO.Path]::GetDirectoryName($_) } | Sort-Object -Unique
  )
  if ($binDirectories.Count -ne 1) {
    throw 'PostgreSQL tools resolve to different installation folders. Align PATH before continuing.'
  }

  $toolVersion = $uniqueVersions[0]
  return [pscustomobject]@{
    Paths = $paths
    Version = $toolVersion
    Major = [int]($toolVersion.Split('.')[0])
    BinDirectory = $binDirectories[0]
  }
}

function Resolve-LocalFilePath {
  param(
    [Parameter(Mandatory)][string]$Value,
    [Parameter(Mandatory)][string]$ParameterName,
    [switch]$Directory
  )

  $expanded = [Environment]::ExpandEnvironmentVariables($Value)
  if (-not [IO.Path]::IsPathRooted($expanded)) {
    throw "$ParameterName must be an absolute local path."
  }
  $kind = if ($Directory) { 'Container' } else { 'Leaf' }
  if (-not (Test-Path -LiteralPath $expanded -PathType $kind)) {
    throw "$ParameterName does not exist. TLS settings were not weakened."
  }
  return (Resolve-Path -LiteralPath $expanded).Path
}

function Set-PostgresSslEnvironment {
  param([Parameter(Mandatory)][pscustomobject]$Database)

  if ($Database.SslMode -cne 'verify-full') {
    throw 'TLS certificate and hostname verification require verify-full.'
  }

  $sslEnvironment = @{
    PGSSLMODE = $null
    PGSSLROOTCERT = $null
    PGSSLCERT = $null
    PGSSLKEY = $null
    PGSSLCRL = $null
    PGSSLCRLDIR = $null
    PGSSLMINPROTOCOLVERSION = $null
    PGSSLMAXPROTOCOLVERSION = $null
  }

  $rootCert = $Database.SslRootCert
  if ([string]::IsNullOrWhiteSpace($rootCert)) {
    if ([string]::IsNullOrWhiteSpace($env:APPDATA)) {
      throw 'Certificate verification was requested, but no trusted root certificate location is available.'
    }
    $rootCert = Join-Path $env:APPDATA 'postgresql\root.crt'
  }
  if (-not [string]::IsNullOrWhiteSpace($rootCert)) {
    $sslEnvironment.PGSSLROOTCERT = Resolve-LocalFilePath `
      -Value $rootCert -ParameterName 'sslrootcert'
  }
  if ([string]::IsNullOrWhiteSpace($sslEnvironment.PGSSLROOTCERT)) {
    throw 'Certificate verification was requested, but no trusted root certificate is available.'
  }

  foreach ($setting in @(
    @{ Value = $Database.SslCert; Name = 'sslcert'; Env = 'PGSSLCERT' },
    @{ Value = $Database.SslKey; Name = 'sslkey'; Env = 'PGSSLKEY' },
    @{ Value = $Database.SslCrl; Name = 'sslcrl'; Env = 'PGSSLCRL' }
  )) {
    if (-not [string]::IsNullOrWhiteSpace($setting.Value)) {
      $sslEnvironment[$setting.Env] = Resolve-LocalFilePath `
        -Value $setting.Value -ParameterName $setting.Name
    }
  }
  if (-not [string]::IsNullOrWhiteSpace($Database.SslCrlDir)) {
    $sslEnvironment.PGSSLCRLDIR = Resolve-LocalFilePath `
      -Value $Database.SslCrlDir -ParameterName 'sslcrldir' -Directory
  }

  $allowedTlsVersions = @('TLSv1', 'TLSv1.1', 'TLSv1.2', 'TLSv1.3')
  foreach ($setting in @(
    @{ Value = $Database.SslMinProtocolVersion; Name = 'ssl_min_protocol_version'; Env = 'PGSSLMINPROTOCOLVERSION' },
    @{ Value = $Database.SslMaxProtocolVersion; Name = 'ssl_max_protocol_version'; Env = 'PGSSLMAXPROTOCOLVERSION' }
  )) {
    if (-not [string]::IsNullOrWhiteSpace($setting.Value)) {
      if ($setting.Value -notin $allowedTlsVersions) {
        throw "$($setting.Name) is unsupported. TLS settings were not weakened."
      }
      $sslEnvironment[$setting.Env] = $setting.Value
    }
  }

  $sslEnvironment.PGSSLMODE = $Database.SslMode
  foreach ($key in $sslEnvironment.Keys) {
    if ($null -eq $sslEnvironment[$key]) {
      Remove-Item "Env:$key" -ErrorAction SilentlyContinue
    } else {
      Set-Item "Env:$key" $sslEnvironment[$key]
    }
  }
  if (-not [string]::IsNullOrWhiteSpace($Database.ChannelBinding)) {
    Set-Item Env:PGCHANNELBINDING $Database.ChannelBinding
  } else {
    Remove-Item Env:PGCHANNELBINDING -ErrorAction SilentlyContinue
  }
}

function Assert-BitLockerProtected {
  param([Parameter(Mandatory)][string]$Path)

  $root = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($Path))
  $mountPoint = $root.TrimEnd('\')
  if ([string]::IsNullOrWhiteSpace($mountPoint)) {
    throw 'Could not identify the storage volume for the sensitive files.'
  }
  if (-not (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue)) {
    try { Import-Module BitLocker -ErrorAction Stop } catch {
      throw 'BitLocker status cannot be verified. No Production connection will be made.'
    }
  }
  try {
    $volumes = @(Get-BitLockerVolume -MountPoint $mountPoint -ErrorAction Stop)
  }
  catch {
    throw 'BitLocker status cannot be verified. No Production connection will be made.'
  }
  if ($volumes.Count -ne 1 -or
      [string]$volumes[0].VolumeStatus -ne 'FullyEncrypted' -or
      [string]$volumes[0].ProtectionStatus -ne 'On' -or
      [int]$volumes[0].EncryptionPercentage -ne 100) {
    throw 'The backup, attachment, or temporary-file volume is not confirmed fully protected by BitLocker. No Production connection will be made.'
  }
}

function Invoke-PsqlJson {
  param(
    [Parameter(Mandatory)][string]$Psql,
    [Parameter(Mandatory)][string]$Sql
  )

  $arguments = @(
    '--no-psqlrc', '--no-password', '--quiet', '--tuples-only', '--no-align',
    '--host', $env:PGHOST, '--port', $env:PGPORT, '--username', $env:PGUSER,
    '--dbname', $env:PGDATABASE, '--command', $Sql
  )
  $output = & $Psql @arguments 2>$null
  $exitCode = $LASTEXITCODE
  if ($exitCode -ne 0) { throw 'A read-only Production verification query failed.' }

  $json = ($output -join "`n").Trim()
  try { return ($json | ConvertFrom-Json -AsHashtable) }
  catch { throw 'A database verification query returned an invalid result.' }
}

function Get-SchemaValidationSql {
  # Names are derived from lib/db/src/schema/employee-transactions.ts.
  return @'
WITH expected(table_name, column_name) AS (
  VALUES
    ('departments', 'id'),
    ('employees', 'id'),
    ('users', 'id'),
    ('users', 'role'),
    ('employee_transactions', 'id'),
    ('transaction_updates', 'id'),
    ('attachments', 'id'),
    ('attachments', 'transaction_update_id'),
    ('attachments', 'uploaded_by'),
    ('attachments', 'file_name'),
    ('attachments', 'object_path'),
    ('attachments', 'content_type'),
    ('attachments', 'size'),
    ('notifications', 'id'),
    ('settings', 'key'),
    ('settings', 'value'),
    ('audit_logs', 'id')
),
missing AS (
  SELECT e.table_name, e.column_name
  FROM expected e
  LEFT JOIN information_schema.columns c
    ON c.table_schema = 'public'
   AND c.table_name = e.table_name
   AND c.column_name = e.column_name
  WHERE c.column_name IS NULL
)
SELECT json_build_object(
  'missingCount', (SELECT count(*) FROM missing),
  'missing', COALESCE(
    (SELECT json_agg(table_name || '.' || column_name ORDER BY table_name, column_name)
       FROM missing),
    '[]'::json
  )
)::text;
'@
}

function Assert-PostgresSchema {
  param([Parameter(Mandatory)][string]$Psql)
  $schemaResult = Invoke-PsqlJson -Psql $Psql -Sql (Get-SchemaValidationSql)
  if ([int]$schemaResult.missingCount -ne 0) {
    throw 'The Production schema does not match the project schema. Nothing was dumped.'
  }
}

function Assert-OutsideProject {
  param([Parameter(Mandatory)][string]$Path)

  $target = [IO.Path]::GetFullPath($Path).TrimEnd('\', '/')
  $root = $script:ProjectRoot.TrimEnd('\', '/')
  if ($root.Length -eq 2 -and $root[1] -eq ':') { $root += '\' }
  $rootPrefix = $root
  if (-not $rootPrefix.EndsWith('\') -and -not $rootPrefix.EndsWith('/')) {
    $rootPrefix += [IO.Path]::DirectorySeparatorChar
  }
  if ($target.Equals($root, [StringComparison]::OrdinalIgnoreCase) -or
      $target.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Choose a backup or temporary directory outside the project folder.'
  }
}

function Assert-NoReparsePoints {
  param([Parameter(Mandatory)][string]$Path)

  $fullPath = [IO.Path]::GetFullPath($Path)
  $current = [IO.Path]::GetPathRoot($fullPath)
  $relativePath = $fullPath.Substring($current.Length)
  foreach ($segment in ($relativePath -split '[\\/]')) {
    if ([string]::IsNullOrWhiteSpace($segment)) { continue }
    $current = Join-Path $current $segment
    if (-not (Test-Path -LiteralPath $current)) { continue }
    $item = Get-Item -LiteralPath $current -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
      throw 'Backup and temporary paths must not pass through junctions or symbolic links.'
    }
  }
}

function Assert-DirectoryWritable {
  param([Parameter(Mandatory)][string]$Path)

  $probe = Join-Path $Path ('.backup-write-test-' + [Guid]::NewGuid().ToString('N'))
  try {
    $stream = [IO.File]::Open(
      $probe, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None
    )
    $stream.Dispose()
    Remove-Item -LiteralPath $probe -Force
  }
  catch {
    if (Test-Path -LiteralPath $probe) {
      Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
    }
    throw 'The selected folder is not writable. No database dump was started.'
  }
}

function Get-DriveFreeBytes {
  param([Parameter(Mandatory)][string]$Path)

  $fullPath = [IO.Path]::GetFullPath($Path)
  $root = [IO.Path]::GetPathRoot($fullPath)
  try {
    return [IO.DriveInfo]::new($root).AvailableFreeSpace
  }
  catch {
    throw 'Could not verify free disk space for a backup location.'
  }
}

function Assert-EnoughDiskSpace {
  param(
    [Parameter(Mandatory)][string]$OutputPath,
    [Parameter(Mandatory)][string]$TemporaryPath,
    [Parameter(Mandatory)][long]$DatabaseBytes,
    [Parameter(Mandatory)][long]$AttachmentBytes
  )

  $payloadBytes = [decimal]$DatabaseBytes + [decimal]$AttachmentBytes
  $outputRequired = [long][Math]::Ceiling(($payloadBytes * 1.25) + 268435456)
  $temporaryRequired = [long][Math]::Ceiling(($payloadBytes * 5) + 1073741824)
  $checks = @(
    [pscustomobject]@{ Path = $OutputPath; Required = $outputRequired },
    [pscustomobject]@{ Path = $TemporaryPath; Required = $temporaryRequired }
  )
  $requiredByRoot = @{}
  foreach ($check in $checks) {
    $root = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($check.Path))
    if ($requiredByRoot.ContainsKey($root)) {
      $requiredByRoot[$root] += $check.Required
    } else {
      $requiredByRoot[$root] = $check.Required
    }
  }
  foreach ($root in $requiredByRoot.Keys) {
    $freeBytes = Get-DriveFreeBytes -Path $root
    if ($freeBytes -lt [long]$requiredByRoot[$root]) {
      throw 'Insufficient free space at the selected backup locations. No dump was started.'
    }
  }
}

function Set-PrivateDirectoryAcl {
  param([Parameter(Mandatory)][string]$Path)

  $identity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
  $acl = Get-Acl -LiteralPath $Path
  $acl.SetAccessRuleProtection($true, $false)
  $rule = [Security.AccessControl.FileSystemAccessRule]::new(
    $identity,
    [Security.AccessControl.FileSystemRights]::FullControl,
    [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor
      [Security.AccessControl.InheritanceFlags]::ObjectInherit,
    [Security.AccessControl.PropagationFlags]::None,
    [Security.AccessControl.AccessControlType]::Allow
  )
  $acl.SetAccessRule($rule)
  Set-Acl -LiteralPath $Path -AclObject $acl
}

function Get-DatabaseSnapshotSql {
  return @'
WITH selected_primary AS (
  SELECT COALESCE(
    (SELECT NULLIF(value #>> '{}', '')::integer
       FROM public.settings WHERE key = 'primary_supervisor_id'),
    (SELECT min(id) FROM public.users WHERE role = 'supervisor')
  ) AS id
)
SELECT json_build_object(
  'databaseName', current_database(),
  'serverVersionName', current_setting('server_version'),
  'serverVersion', current_setting('server_version_num')::integer,
  'databaseBytes', pg_database_size(current_database()),
  'attachmentBytes', (
    SELECT COALESCE(sum(size), 0)::bigint FROM public.attachments
  ),
  'users', (SELECT count(*) FROM public.users),
  'employees', (SELECT count(*) FROM public.employees),
  'supervisors', (SELECT count(*) FROM public.users WHERE role = 'supervisor'),
  'primarySupervisorId', (SELECT id FROM selected_primary),
  'primarySupervisorPresent', (
    SELECT count(*) FROM public.users u
    JOIN selected_primary p ON p.id = u.id
    WHERE u.role = 'supervisor'
  ),
  'primarySupervisorSha256', (
    SELECT encode(sha256(convert_to(to_jsonb(u)::text, 'UTF8')), 'hex')
    FROM public.users u JOIN selected_primary p ON p.id = u.id
  ),
  'usersSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(u) ORDER BY u.id), '[]'::jsonb)::text, 'UTF8'
    )), 'hex')
    FROM public.users u
  ),
  'employeesSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(e) ORDER BY e.id), '[]'::jsonb)::text, 'UTF8'
    )), 'hex')
    FROM public.employees e
  ),
  'transactionsSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(t) ORDER BY t.id), '[]'::jsonb)::text, 'UTF8'
    )), 'hex')
    FROM public.employee_transactions t
  ),
  'updatesSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(u) ORDER BY u.id), '[]'::jsonb)::text, 'UTF8'
    )), 'hex')
    FROM public.transaction_updates u
  ),
  'notificationsSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(n) ORDER BY n.id), '[]'::jsonb)::text, 'UTF8'
    )), 'hex')
    FROM public.notifications n
  ),
  'auditLogsSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(a) ORDER BY a.id), '[]'::jsonb)::text, 'UTF8'
    )), 'hex')
    FROM public.audit_logs a
  ),
  'transactions', (SELECT count(*) FROM public.employee_transactions),
  'updates', (SELECT count(*) FROM public.transaction_updates),
  'attachments', (SELECT count(*) FROM public.attachments),
  'notifications', (SELECT count(*) FROM public.notifications),
  'auditLogs', (SELECT count(*) FROM public.audit_logs),
  'departments', (SELECT count(*) FROM public.departments),
  'settings', (SELECT count(*) FROM public.settings),
  'departmentsSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(d) ORDER BY d.id), '[]'::jsonb)::text,
      'UTF8'
    )), 'hex')
    FROM public.departments d
  ),
  'settingsSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(s) ORDER BY s.key), '[]'::jsonb)::text,
      'UTF8'
    )), 'hex')
    FROM public.settings s
  ),
  'attachmentsMetadataSha256', (
    SELECT encode(sha256(convert_to(
      COALESCE(jsonb_agg(to_jsonb(a) ORDER BY a.id), '[]'::jsonb)::text,
      'UTF8'
    )), 'hex')
    FROM public.attachments a
  )
)::text;
'@
}

function Test-SnapshotsEqual {
  param(
    [Parameter(Mandatory)][System.Collections.IDictionary]$Expected,
    [Parameter(Mandatory)][System.Collections.IDictionary]$Actual,
    [string[]]$IgnoreKeys = @()
  )

  foreach ($key in $Expected.Keys) {
    if ($IgnoreKeys -contains $key) { continue }
    if ([string]$Expected[$key] -cne [string]$Actual[$key]) { return $false }
  }
  return $true
}

$workDirectory = $null
$clusterStarted = $false
$clusterDataDirectory = $null
$clusterLog = $null
$connectionPlainText = $null
$originalPath = $env:PATH
$scriptExitCode = 0

try {
  Assert-PowerShellCore
  $sourceTools = Get-PostgresToolchain
  $sourcePsql = $sourceTools.Paths['psql']
  $age = Get-ExecutablePath 'age'

  $outputDirectory = Read-Host 'Backup destination folder (outside the project)'
  if ([string]::IsNullOrWhiteSpace($outputDirectory)) {
    throw 'A backup destination folder is required.'
  }
  $outputDirectory = [IO.Path]::GetFullPath($outputDirectory)
  Assert-OutsideProject -Path $outputDirectory
  Assert-NoReparsePoints -Path $outputDirectory
  if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
  }
  $outputDirectory = (Resolve-Path -LiteralPath $outputDirectory).Path
  Assert-OutsideProject -Path $outputDirectory
  Assert-NoReparsePoints -Path $outputDirectory
  Assert-DirectoryWritable -Path $outputDirectory

  if ([string]::IsNullOrWhiteSpace($env:TEMP)) {
    throw 'Windows TEMP is not configured. No database action was started.'
  }
  $temporaryRoot = [IO.Path]::GetFullPath($env:TEMP)
  if (-not (Test-Path -LiteralPath $temporaryRoot -PathType Container)) {
    throw 'The Windows temporary directory is unavailable. No database action was started.'
  }
  Assert-OutsideProject -Path $temporaryRoot
  Assert-NoReparsePoints -Path $temporaryRoot
  Assert-DirectoryWritable -Path $temporaryRoot

  $attachmentDirectory = Read-Host 'Folder containing all files downloaded from the published Production app'
  if ([string]::IsNullOrWhiteSpace($attachmentDirectory) -or
      -not (Test-Path -LiteralPath $attachmentDirectory -PathType Container)) {
    throw 'The local folder of Production attachments was not found.'
  }
  $attachmentDirectory = [IO.Path]::GetFullPath($attachmentDirectory)

  Assert-BitLockerProtected -Path $outputDirectory
  Assert-BitLockerProtected -Path $temporaryRoot
  Assert-BitLockerProtected -Path $attachmentDirectory

  $confirmation = Read-Host 'Type PRODUCTION to confirm the connection URL will come from Database > Production > Settings'
  if ($confirmation -cne 'PRODUCTION') { throw 'Production confirmation was not provided.' }

  $secureExpectedHost = Read-Host 'Expected Production hostname only (hidden; verify it from the Production settings)' -AsSecureString
  $expectedHost = Get-PlainTextFromSecureString $secureExpectedHost
  $secureExpectedHost.Dispose()
  $expectedHost = $expectedHost.Trim().TrimEnd('.').ToLowerInvariant()
  if ([string]::IsNullOrWhiteSpace($expectedHost) -or
      $expectedHost.Contains('://') -or $expectedHost.Contains('@') -or
      $expectedHost.Contains('/') -or $expectedHost.Contains(':') -or
      [Uri]::CheckHostName($expectedHost) -ne [UriHostNameType]::Dns) {
    $expectedHost = $null
    throw 'A valid Production hostname was not provided. No connection was made.'
  }

  $secureConnectionUrl = Read-Host 'Production DATABASE_URL (hidden input)' -AsSecureString
  $connectionPlainText = Get-PlainTextFromSecureString $secureConnectionUrl
  $secureConnectionUrl.Dispose()
  $database = Parse-PostgresUri $connectionPlainText
  $connectionPlainText = $null

  if ($database.Host.TrimEnd('.').ToLowerInvariant() -cne $expectedHost) {
    $database.Password = $null
    $database = $null
    $expectedHost = $null
    throw 'The connection host did not match the separately confirmed Production hostname. No connection was made.'
  }
  $expectedHost = $null

  if ($database.Database -cne $script:ExpectedProductionDatabase -or
      $database.Database -ceq $script:KnownDevelopmentDatabase) {
    throw 'The database name does not match the verified Production database. Nothing was dumped.'
  }

  $env:PGHOST = $database.Host
  $env:PGPORT = [string]$database.Port
  $env:PGDATABASE = $database.Database
  $env:PGUSER = $database.Username
  $env:PGPASSWORD = $database.Password
  Set-PostgresSslEnvironment -Database $database
  $database.Password = $null
  $database = $null

  $productionVersionQuery = @'
SELECT json_build_object(
  'serverVersionName', current_setting('server_version'),
  'serverVersion', current_setting('server_version_num')::integer
)::text;
'@
  $productionVersion = Invoke-PsqlJson -Psql $sourcePsql -Sql $productionVersionQuery
  $productionMajor = [int][Math]::Floor([int]$productionVersion.serverVersion / 10000)
  if ($sourceTools.Major -lt $productionMajor) {
    throw 'The available connection tools are older than the Production server; no dump was started.'
  }

  $targetBinDirectory = Read-Host "Path to a separate PostgreSQL $($productionVersion.serverVersionName) bin folder for backup and isolated restore"
  if ([string]::IsNullOrWhiteSpace($targetBinDirectory)) {
    throw 'A PostgreSQL tool folder matching the Production version is required. No dump was started.'
  }
  $postgresTools = Get-PostgresToolchain -BinDirectory $targetBinDirectory
  if ($postgresTools.Version -cne [string]$productionVersion.serverVersionName) {
    throw 'The selected PostgreSQL tools do not match the actual Production server version. No dump was started.'
  }
  $pgDump = $postgresTools.Paths['pg_dump']
  $pgRestore = $postgresTools.Paths['pg_restore']
  $psql = $postgresTools.Paths['psql']
  $initdb = $postgresTools.Paths['initdb']
  $pgCtl = $postgresTools.Paths['pg_ctl']
  $createdb = $postgresTools.Paths['createdb']

  Assert-PostgresSchema -Psql $psql
  $snapshotSql = Get-DatabaseSnapshotSql
  $productionSnapshot = Invoke-PsqlJson -Psql $psql -Sql $snapshotSql
  if ([string]$productionSnapshot.databaseName -cne $script:ExpectedProductionDatabase) {
    throw 'The connected database did not identify as the verified Production database.'
  }
  if ([string]$productionSnapshot.serverVersionName -cne [string]$productionVersion.serverVersionName) {
    throw 'The Production server version changed during preflight. No dump was started.'
  }

  $attachmentsSql = @'
SELECT COALESCE(
  json_agg(json_build_object(
    'id', id,
    'transactionUpdateId', transaction_update_id,
    'fileName', file_name,
    'objectPath', object_path,
    'contentType', content_type,
    'size', size
  ) ORDER BY id),
  '[]'::json
)::text
FROM public.attachments;
'@
  $attachmentRowsResult = Invoke-PsqlJson -Psql $psql -Sql $attachmentsSql
  if ($null -eq $attachmentRowsResult) {
    $attachmentRows = @()
  } else {
    $attachmentRows = @($attachmentRowsResult)
  }

  foreach ($row in $attachmentRows) {
    if ($null -eq $row.transactionUpdateId) {
      throw 'An attachment is not linked to a saved transaction update and cannot be verified through the app.'
    }
    $objectPath = [string]$row.objectPath
    if (-not $objectPath.StartsWith('/objects/', [StringComparison]::Ordinal)) {
      throw 'An attachment path does not match the application storage format.'
    }
    if ([string]::IsNullOrWhiteSpace([IO.Path]::GetFileName($objectPath))) {
      throw 'An attachment path has no file component. No attachment backup was started.'
    }
  }

  $localFiles = @(Get-ChildItem -LiteralPath $attachmentDirectory -File -Recurse -Force)
  if ($localFiles.Count -ne [int]$productionSnapshot.attachments -or
      $localFiles.Count -ne $attachmentRows.Count) {
    throw 'The downloaded attachment count does not match Production. No dump was started.'
  }
  $attachmentConfirmation = Read-Host 'Type ATTACHMENTS to confirm each file came from that record ID’s own link and is named attachment-<id>.bin'
  if ($attachmentConfirmation -cne 'ATTACHMENTS') {
    throw 'Per-record attachment download confirmation was not provided. No dump was started.'
  }

  Assert-EnoughDiskSpace `
    -OutputPath $outputDirectory `
    -TemporaryPath $temporaryRoot `
    -DatabaseBytes ([long]$productionSnapshot.databaseBytes) `
    -AttachmentBytes ([long]$productionSnapshot.attachmentBytes)

  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $backupName = "taabi-production-$stamp"
  $encryptedBackup = Join-Path $outputDirectory "$backupName.zip.age"
  $checksumPath = "$encryptedBackup.sha256"
  if ((Test-Path -LiteralPath $encryptedBackup) -or (Test-Path -LiteralPath $checksumPath)) {
    throw 'A backup with this name already exists.'
  }

  $workDirectory = Join-Path $env:TEMP ("taabi-backup-" + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $workDirectory | Out-Null
  Set-PrivateDirectoryAcl -Path $workDirectory
  $packageDirectory = Join-Path $workDirectory 'package'
  $packageAttachments = Join-Path $packageDirectory 'attachments'
  New-Item -ItemType Directory -Path $packageAttachments -Force | Out-Null

  $attachmentManifest = @()
  foreach ($row in $attachmentRows) {
    $expectedName = "attachment-$([int]$row.id).bin"
    $matches = @($localFiles | Where-Object { $_.Name -ceq $expectedName })
    if ($matches.Count -ne 1) {
      throw 'Each attachment needs exactly one local file named for its database record ID.'
    }
    if ($matches[0].Length -ne [int64]$row.size) {
      throw 'A downloaded attachment size does not match its Production record.'
    }

    $destinationName = "attachment-$([int]$row.id).bin"
    $destination = Join-Path $packageAttachments $destinationName
    Copy-Item -LiteralPath $matches[0].FullName -Destination $destination
    $attachmentManifest += [pscustomobject]@{
      id = [int]$row.id
      transactionUpdateId = [int]$row.transactionUpdateId
      archivedAs = "attachments/$destinationName"
      originalFileName = [string]$row.fileName
      objectPath = [string]$row.objectPath
      localRecordFileName = $expectedName
      contentType = [string]$row.contentType
      size = [int64]$row.size
      sha256 = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
      sourceChecksumAvailable = $false
    }
  }

  $databaseDump = Join-Path $packageDirectory 'production.dump'
  Invoke-NativeQuietly -Executable $pgDump -Arguments @(
    '--no-password', '--format=custom', '--blobs', '--file', $databaseDump
  ) -FailureMessage 'Production pg_dump failed. No data was changed.'
  if (-not (Test-Path -LiteralPath $databaseDump -PathType Leaf) -or
      (Get-Item -LiteralPath $databaseDump).Length -le 0) {
    throw 'The database dump is missing or empty.'
  }

  $attachmentArchive = Join-Path $packageDirectory 'attachments.zip'
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [IO.Compression.ZipFile]::CreateFromDirectory(
    $packageAttachments, $attachmentArchive, [IO.Compression.CompressionLevel]::Optimal, $false
  )
  Remove-Item -LiteralPath $packageAttachments -Recurse -Force

  $postDumpSnapshot = Invoke-PsqlJson -Psql $psql -Sql $snapshotSql
  if (-not (Test-SnapshotsEqual -Expected $productionSnapshot -Actual $postDumpSnapshot)) {
    throw 'Production counts changed during the backup window. The temporary backup was discarded; rerun later.'
  }

  $manifest = [ordered]@{
    format = 'Taabi production backup package v1'
    createdUtc = [DateTime]::UtcNow.ToString('o')
    databaseName = [string]$productionSnapshot.databaseName
    postgresqlToolchain = @{
      version = $postgresTools.Version
      productionServerMajor = $productionMajor
      productionServerVersion = [string]$productionVersion.serverVersionName
    }
    databaseSnapshot = $productionSnapshot
    databaseDump = @{
      file = 'production.dump'
      sha256 = (Get-FileHash -LiteralPath $databaseDump -Algorithm SHA256).Hash
      bytes = (Get-Item -LiteralPath $databaseDump).Length
    }
    attachmentsArchive = @{
      file = 'attachments.zip'
      sha256 = (Get-FileHash -LiteralPath $attachmentArchive -Algorithm SHA256).Hash
      bytes = (Get-Item -LiteralPath $attachmentArchive).Length
      files = $attachmentManifest
    }
    note = 'Credentials and encryption passphrase are intentionally excluded. Attachment files are mapped by record ID based on user confirmation; the app stores no source-side checksum.'
  }
  $manifestPath = Join-Path $packageDirectory 'manifest.json'
  $manifest | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $manifestPath -Encoding utf8

  $packageZip = Join-Path $workDirectory 'backup-package.zip'
  [IO.Compression.ZipFile]::CreateFromDirectory(
    $packageDirectory, $packageZip, [IO.Compression.CompressionLevel]::Optimal, $false
  )

  $encryptedCreated = $false
  $decryptionVerified = $false
  $restoreVerified = $false
  try {
    Write-Host 'age will request the backup passphrase without echoing it. Keep it outside the project.'
    & $age --passphrase --output $encryptedBackup $packageZip
    if ($LASTEXITCODE -ne 0) { throw 'age encryption failed.' }
    $encryptedCreated = $true

    $roundTripPackage = Join-Path $workDirectory 'roundtrip.zip'
    Write-Host 'Enter the same passphrase once more to verify decryption and test restoration.'
    & $age --decrypt --output $roundTripPackage $encryptedBackup
    if ($LASTEXITCODE -ne 0) { throw 'Encrypted backup verification failed.' }
    $originalPackageHash = (Get-FileHash -LiteralPath $packageZip -Algorithm SHA256).Hash
    $roundTripHash = (Get-FileHash -LiteralPath $roundTripPackage -Algorithm SHA256).Hash
    if ($originalPackageHash -cne $roundTripHash) {
      throw 'Encrypted backup did not decrypt to the original package.'
    }
    $decryptionVerified = $true

    $restoredPackage = Join-Path $workDirectory 'restored-package'
    [IO.Compression.ZipFile]::ExtractToDirectory($roundTripPackage, $restoredPackage)
    $restoredDump = Join-Path $restoredPackage 'production.dump'
    $restoredAttachmentsZip = Join-Path $restoredPackage 'attachments.zip'

    $dumpList = Join-Path $workDirectory 'dump-contents.txt'
    Invoke-NativeQuietly -Executable $pgRestore -Arguments @(
      '--list', '--file', $dumpList, $restoredDump
    ) -FailureMessage 'The encrypted database archive failed its integrity listing check.'
    if (-not (Test-Path -LiteralPath $dumpList -PathType Leaf) -or
        (Get-Item -LiteralPath $dumpList).Length -le 0) {
      throw 'The database archive contains no restorable entries.'
    }
    if ((Get-FileHash -LiteralPath $restoredDump -Algorithm SHA256).Hash -cne
        [string]$manifest.databaseDump.sha256) {
      throw 'The database dump checksum did not match the manifest.'
    }
    if ((Get-FileHash -LiteralPath $restoredAttachmentsZip -Algorithm SHA256).Hash -cne
        [string]$manifest.attachmentsArchive.sha256) {
      throw 'The attachment archive checksum did not match the manifest.'
    }

    $attachmentTest = Join-Path $workDirectory 'attachment-restore-test'
    [IO.Compression.ZipFile]::ExtractToDirectory($restoredAttachmentsZip, $attachmentTest)
    $restoredAttachmentFiles = @(Get-ChildItem -LiteralPath $attachmentTest -File -Recurse -Force)
    if ($restoredAttachmentFiles.Count -ne $attachmentManifest.Count) {
      throw 'Attachment archive restore count did not match.'
    }
    foreach ($item in $attachmentManifest) {
      $file = Join-Path $attachmentTest ([string]$item.archivedAs -replace '^attachments/', '')
      if (-not (Test-Path -LiteralPath $file -PathType Leaf) -or
          (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -cne [string]$item.sha256) {
        throw 'An attachment failed its SHA-256 restore check.'
      }
    }

    # Do not pass Production connection details into any local PostgreSQL process.
    foreach ($key in $script:PgEnvironmentKeys) {
      Remove-Item "Env:$key" -ErrorAction SilentlyContinue
    }
    $env:PATH = "$($postgresTools.BinDirectory);$originalPath"

    $clusterDataDirectory = Join-Path $workDirectory 'isolated-postgres'
    $clusterLog = Join-Path $workDirectory 'isolated-postgres.log'
    Invoke-NativeQuietly -Executable $initdb -Arguments @(
      '--pgdata', $clusterDataDirectory,
      '--username', 'backup_restore_test',
      '--encoding', 'UTF8',
      '--auth-local', 'trust',
      '--auth-host', 'trust'
    ) -FailureMessage 'Could not initialize the temporary isolated PostgreSQL cluster.'

    $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $restorePort = $listener.LocalEndpoint.Port
    $listener.Stop()

    Invoke-NativeQuietly -Executable $pgCtl -Arguments @(
      '--pgdata', $clusterDataDirectory,
      '--log', $clusterLog,
      '--wait',
      '--options', "-h 127.0.0.1 -p $restorePort -c listen_addresses=127.0.0.1",
      'start'
    ) -FailureMessage 'Could not start the temporary local-only PostgreSQL cluster.'
    $clusterStarted = $true

    $localVersionArguments = @(
      '--no-psqlrc', '--no-password', '--quiet', '--tuples-only', '--no-align',
      '--host', '127.0.0.1', '--port', [string]$restorePort,
      '--username', 'backup_restore_test', '--dbname', 'postgres',
      '--command', "SELECT current_setting('server_version')"
    )
    $localVersionText = & $psql @localVersionArguments 2>$null
    if ($LASTEXITCODE -ne 0) {
      throw 'Could not verify the isolated PostgreSQL server version.'
    }
    $localServerVersion = ($localVersionText -join '').Trim()
    if ($localServerVersion -cne [string]$productionVersion.serverVersionName) {
      throw 'The isolated server version does not exactly match the Production version.'
    }

    Invoke-NativeQuietly -Executable $createdb -Arguments @(
      '--host', '127.0.0.1', '--port', [string]$restorePort,
      '--username', 'backup_restore_test', 'backup_restore_check'
    ) -FailureMessage 'Could not create the isolated restore-test database.'

    Invoke-NativeQuietly -Executable $pgRestore -Arguments @(
      '--host', '127.0.0.1', '--port', [string]$restorePort,
      '--username', 'backup_restore_test', '--dbname', 'backup_restore_check',
      '--no-owner', '--no-privileges', '--exit-on-error', $restoredDump
    ) -FailureMessage 'The database restore into the isolated cluster failed.'

    $restoreSnapshotSql = $snapshotSql
    $restoreArguments = @(
      '--no-psqlrc', '--no-password', '--quiet', '--tuples-only', '--no-align',
      '--host', '127.0.0.1', '--port', [string]$restorePort,
      '--username', 'backup_restore_test', '--dbname', 'backup_restore_check',
      '--command', $restoreSnapshotSql
    )
    $restoredCountsText = & $psql @restoreArguments 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'The isolated restore verification query failed.' }
    $restoredCounts = (($restoredCountsText -join "`n").Trim() | ConvertFrom-Json -AsHashtable)
    $restoredServerMajor = [int][Math]::Floor([int]$restoredCounts.serverVersion / 10000)
    if ($restoredServerMajor -ne $postgresTools.Major -or
        [string]$restoredCounts.serverVersionName -cne [string]$productionVersion.serverVersionName) {
      throw 'The restored database is not running on the isolated PostgreSQL toolchain version.'
    }
    if (-not (Test-SnapshotsEqual -Expected $productionSnapshot -Actual $restoredCounts `
        -IgnoreKeys @('databaseName', 'serverVersion', 'databaseBytes'))) {
      throw 'Restored table counts or supervisor/settings/departments verification did not match Production.'
    }
    $restoreVerified = $true

    $finalHash = (Get-FileHash -LiteralPath $encryptedBackup -Algorithm SHA256).Hash
    "$finalHash  $(Split-Path -Leaf $encryptedBackup)" |
      Set-Content -LiteralPath $checksumPath -Encoding ascii

    Write-Host ''
    Write-Host 'Backup and isolated restore test succeeded.'
    Write-Host "Encrypted backup: $encryptedBackup"
    Write-Host "SHA-256: $finalHash"
    Write-Host "PostgreSQL tools: $($postgresTools.Version); Production server: $($productionVersion.serverVersionName)"
    Write-Host 'Attachment files are mapped by record ID using your confirmation; the app has no source-side checksum for independent origin verification.'
    Write-Host "Verified Production snapshot: users=$($productionSnapshot.users), employees=$($productionSnapshot.employees), supervisors=$($productionSnapshot.supervisors), transactions=$($productionSnapshot.transactions), updates=$($productionSnapshot.updates), attachments=$($productionSnapshot.attachments), notifications=$($productionSnapshot.notifications), auditLogs=$($productionSnapshot.auditLogs), departments=$($productionSnapshot.departments), settings=$($productionSnapshot.settings), primarySupervisorId=$($productionSnapshot.primarySupervisorId)"
    Write-Host 'The backup passphrase was not saved. Store it separately to restore this archive later.'
  }
  catch {
    if (Test-Path -LiteralPath $encryptedBackup) {
      if ($encryptedCreated -and $decryptionVerified -and -not $restoreVerified) {
        [Console]::Error.WriteLine('Encrypted archive retained, but isolated restore validation failed or did not finish. Do not treat it as a verified backup.')
      } elseif ($encryptedCreated -and -not $decryptionVerified) {
        [Console]::Error.WriteLine('Encrypted archive retained, but decryption validation did not pass. Do not treat it as a verified backup.')
      } elseif ($restoreVerified) {
        [Console]::Error.WriteLine('Encrypted archive passed restore validation and was retained, but a later finalization step failed.')
      } else {
        [Console]::Error.WriteLine('Output archive retained, but validation did not complete. Do not treat it as a verified backup.')
      }
    }
    throw $_.Exception.Message
  }
}
catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  $scriptExitCode = 1
}
finally {
  if ($clusterStarted -and $clusterDataDirectory -and $pgCtl) {
    & $pgCtl --pgdata $clusterDataDirectory --wait stop *> $null
  }
  $env:PATH = $originalPath
  foreach ($key in $script:PgEnvironmentKeys) {
    if ($originalPgEnvironment.ContainsKey($key)) {
      [Environment]::SetEnvironmentVariable($key, $originalPgEnvironment[$key], 'Process')
    } else {
      [Environment]::SetEnvironmentVariable($key, $null, 'Process')
    }
  }
  $connectionPlainText = $null
  if ($workDirectory -and (Test-Path -LiteralPath $workDirectory)) {
    Remove-Item -LiteralPath $workDirectory -Recurse -Force -ErrorAction SilentlyContinue
  }
}

if ($scriptExitCode -ne 0) { exit $scriptExitCode }
