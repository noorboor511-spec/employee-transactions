// Real PostgreSQL checks using temporary tables and a rolled-back transaction.
// No current employees, accounts, history, or sequences are modified.
import { build } from "../artifacts/api-server/node_modules/esbuild/lib/main.js";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const dir = await mkdtemp(join(tmpdir(), "employee-email-tests-"));
try {
  const outfile = join(dir, "employee-email.test.mjs");
  await build({
    stdin: {
      resolveDir: resolve("artifacts/api-server"), sourcefile: "employee-email.test.ts", loader: "ts",
      contents: `
        import test from 'node:test';
        import assert from 'node:assert/strict';
        import {sql,eq} from 'drizzle-orm';
        import {fixtureLiveDb,installTestDb,pool,usersTable,employeesTable,auditLogsTable} from '@workspace/db';
        import {CreateEmployeeBody,UpdateEmployeeBody} from '@workspace/api-zod';
        import {createEmployeeAccount,updateEmployeeAccount,normalizeEmployeeInput,isUniqueViolation} from './src/lib/employee-accounts';
        test('canonical email uniqueness and atomic create/edit against real PostgreSQL',async()=>{
          const rollback=new Error('Intentional test rollback');
          try {
            const before=await fixtureLiveDb.select().from(usersTable);
            const employeeCount=(await fixtureLiveDb.select().from(employeesTable)).length;
            await assert.rejects(fixtureLiveDb.transaction(async tx=>{
              installTestDb(tx);
              await tx.execute(sql.raw(\`
                CREATE TEMP TABLE employees (LIKE public.employees INCLUDING ALL) ON COMMIT DROP;
                CREATE TEMP TABLE users (LIKE public.users INCLUDING ALL) ON COMMIT DROP;
                CREATE TEMP TABLE audit_logs (LIKE public.audit_logs INCLUDING ALL) ON COMMIT DROP;
                CREATE TEMP SEQUENCE employee_fixture_sequence;
                CREATE TEMP SEQUENCE user_fixture_sequence;
                CREATE TEMP SEQUENCE audit_fixture_sequence;
                ALTER TABLE pg_temp.employees ALTER COLUMN id SET DEFAULT nextval('pg_temp.employee_fixture_sequence');
                ALTER TABLE pg_temp.users ALTER COLUMN id SET DEFAULT nextval('pg_temp.user_fixture_sequence');
                ALTER TABLE pg_temp.audit_logs ALTER COLUMN id SET DEFAULT nextval('pg_temp.audit_fixture_sequence');
                SET LOCAL search_path=pg_temp,public;
              \`));
              await tx.insert(usersTable).values({id:901,name:'Principal',email:'supervisor@example.com',role:'supervisor',clerkUserId:'preserved-primary'});
              const body=(email,name='Fixture')=>CreateEmployeeBody.parse(normalizeEmployeeInput({email,name,departmentId:1,active:true}));
              const first=await createEmployeeAccount(body('  ALICE@EXAMPLE.COM  '),901);
              const second=await createEmployeeAccount(body('bob@example.com'),901);
              assert.equal(first.email,'alice@example.com');
              assert.equal((await tx.select().from(usersTable).where(eq(usersTable.employeeId,first.id)))[0].email,first.email);
              const stable=async()=>({
                employees:await tx.select().from(employeesTable).orderBy(employeesTable.id),
                users:await tx.select().from(usersTable).orderBy(usersTable.id),
                audits:await tx.select().from(auditLogsTable).orderBy(auditLogsTable.id)
              });
              let snapshot=await stable();
              for(const email of ['alice@example.com','ALICE@EXAMPLE.COM','  Alice@Example.com ']){
                await assert.rejects(createEmployeeAccount(body(email),901),isUniqueViolation);
                assert.deepEqual(await stable(),snapshot);
              }
              await assert.rejects(createEmployeeAccount(body('SUPERVISOR@example.com'),901),isUniqueViolation);
              assert.deepEqual(await stable(),snapshot,'account collision cannot leave an orphan employee');
              await assert.rejects(updateEmployeeAccount(second.id,UpdateEmployeeBody.parse(body(first.email)),901),isUniqueViolation);
              assert.deepEqual(await stable(),snapshot,'employee duplicate edit must roll back');
              await assert.rejects(updateEmployeeAccount(second.id,body('supervisor@example.com'),901),isUniqueViolation);
              assert.deepEqual(await stable(),snapshot,'user-email conflict cannot leave employee email partly changed');
              assert.equal(await updateEmployeeAccount(9999,body('missing@example.com'),901),null);
              assert.deepEqual(await stable(),snapshot);
              await tx.update(usersTable).set({role:'supervisor',clerkUserId:'fixture-identity'}).where(eq(usersTable.employeeId,first.id));
              const updated=await updateEmployeeAccount(first.id,body('  ALICE@example.com  ','Renamed'),901);
              assert.equal(updated.email,first.email);
              const linked=(await tx.select().from(usersTable).where(eq(usersTable.employeeId,first.id)))[0];
              assert.equal(linked.role,'supervisor');
              assert.equal(linked.clerkUserId,'fixture-identity');
              assert.equal(linked.name,'Renamed');
              // Direct writes bypassing API normalization still cannot duplicate email.
              await assert.rejects(tx.transaction(async savepoint=>{
                await savepoint.insert(employeesTable).values({name:'Duplicate',email:'  ALICE@EXAMPLE.COM ',departmentId:1});
              }),isUniqueViolation);
              await assert.rejects(tx.transaction(async savepoint=>{
                await savepoint.insert(usersTable).values({name:'Duplicate',email:' ALICE@EXAMPLE.COM ',role:'employee'});
              }),isUniqueViolation);
              throw rollback;
            }),error=>error===rollback);
            assert.deepEqual(await fixtureLiveDb.select().from(usersTable),before,'real accounts unchanged');
            assert.equal((await fixtureLiveDb.select().from(employeesTable)).length,employeeCount,'no test employees left behind');
          } finally { await pool.end(); }
        });
      `,
    },
    outfile, bundle: true, platform: "node", format: "esm", external: ["pg-native"],
    banner: { js: "import {createRequire} from 'node:module'; const require=createRequire(import.meta.url);" },
    plugins: [{
      name: "transaction-only-test-db",
      setup(builder) {
        builder.onResolve({ filter: /^@workspace\/db$/ }, () => ({ path: "test-db", namespace: "fixture" }));
        builder.onLoad({ filter: /.*/, namespace: "fixture" }, () => ({
          loader: "ts", resolveDir: process.cwd(), contents: `
            export * from ${JSON.stringify(resolve("lib/db/src/index.ts"))};
            import {db as liveDb} from ${JSON.stringify(resolve("lib/db/src/index.ts"))};
            export const fixtureLiveDb=liveDb;
            export let db;
            export const installTestDb=transaction=>{db=transaction;};
          `,
        }));
      },
    }],
  });
  const result = spawnSync(process.execPath, ["--test", outfile], { stdio: "inherit" });
  process.exitCode = result.status ?? 1;
} finally {
  await rm(dir, { recursive: true, force: true });
}
