// Isolated HTTP integration test: no real accounts, credentials or DB writes.
import { build } from "../artifacts/api-server/node_modules/esbuild/lib/main.js";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const dir = await mkdtemp(join(tmpdir(), "branding-tests-"));
const outfile = join(dir, "branding.test.mjs");
try {
  await build({
    entryPoints: ["artifacts/api-server/src/routes/branding.test.ts"],
    outfile, bundle: true, platform: "node", format: "esm",
    banner: { js: "import {createRequire} from 'node:module'; const require=createRequire(import.meta.url);" },
    plugins: [{
      name: "isolated-branding-fixtures",
      setup(builder) {
        builder.onResolve({ filter: /^@workspace\/db$/ }, () => ({ path: "db", namespace: "fixture" }));
        builder.onResolve({ filter: /^\.\.\/lib\/auth$/ }, () => ({ path: "auth", namespace: "fixture" }));
        builder.onLoad({ filter: /.*/, namespace: "fixture" }, args => ({
          loader: "js",
          contents: args.path === "auth" ? `
            export const requireAppUser = (req,res,next) => {
              const role=req.headers['x-test-role'];
              if (!role) return res.status(401).json({error:'Not signed in'});
              req.appUser={id:Number(req.headers['x-test-id']||901),role}; next();
            };
            export const supervisorOnly = (req,res,next) =>
              req.appUser.role==='supervisor' ? next() : res.status(403).json({error:'Forbidden'});
          ` : `
            export const settingsTable={key:'key',value:'value'};
            export const usersTable={id:'id',role:'role'};
            export const auditLogsTable={};
            export const brandingTestState={
              row:undefined, primaryId:undefined, audits:[],
              users:[{id:901,role:'supervisor'},{id:902,role:'supervisor'},{id:903,role:'employee'}],
              untouchedSettings:{followUpDays:3,statuses:['جديدة','مكتملة']}
            };
            const tx={
              insert(table) {
                return {values(value) {
                  if (table===auditLogsTable) {
                    brandingTestState.audits.push(value); return Promise.resolve();
                  }
                  return {onConflictDoNothing() {
                    return {returning:async()=> {
                      if (value.key!=='primary_supervisor_id') throw new Error('Unexpected ownership write');
                      if (brandingTestState.primaryId!==undefined) return [];
                      brandingTestState.primaryId=value.value;
                      return [{value:value.value}];
                    }};
                  }, onConflictDoUpdate() {
                    if (value.key!=='footer_credit') throw new Error('Unexpected setting write');
                    brandingTestState.row=value; return Promise.resolve();
                  }};
                }};
              }
            };
            export const db={
              insert:tx.insert,
              select:columns=>({from:table=>({where:()=>{
                const query={limit:async()=> {
                  if (table===usersTable)
                    return brandingTestState.users.filter(u=>u.role==='supervisor').sort((a,b)=>a.id-b.id).slice(0,1);
                  if (columns?.value)
                    return brandingTestState.primaryId===undefined?[]:[{value:brandingTestState.primaryId}];
                  return brandingTestState.row?[brandingTestState.row]:[];
                },orderBy:()=>query};
                return query;
              }})}),
              transaction:async callback=>callback(tx)
            };
          `,
        }));
      },
    }],
  });
  const result = spawnSync(process.execPath, ["--test", outfile], { stdio: "inherit" });
  process.exitCode = result.status ?? 1;
  if (process.exitCode === 0) {
    const uiFile = join(dir, "attribution-ui.test.mjs");
    await build({
      stdin: {
        resolveDir: resolve("artifacts/employee-transactions"),
        sourcefile: "attribution-ui.test.tsx", loader: "tsx",
        contents: `
          import test from 'node:test';
          import assert from 'node:assert/strict';
          import {renderToStaticMarkup} from 'react-dom/server';
          import {AttributionFooter,AttributionSettings} from './src/components/attribution';
          import {fixture} from '@workspace/api-client-react';
          test('only the principal sees editing tools; everyone still sees the credit',()=>{
            for (const permission of [true,false,null]) {
              fixture.permission=permission;
              const editor=renderToStaticMarkup(<AttributionSettings/>);
              assert.equal(editor.includes('button-remove-footer-credit'),permission===true);
              assert.equal(editor.includes('input-footer-credit'),permission===true);
              assert.ok(renderToStaticMarkup(<AttributionFooter/>).includes('م.وصل العتيبي'));
            }
          });
        `,
      },
      outfile: uiFile, bundle: true, platform: "node", format: "esm", jsx: "automatic",
      banner: { js: "import {createRequire} from 'node:module'; const require=createRequire(import.meta.url);" },
      plugins: [{
        name: "isolated-ui-fixtures",
        setup(builder) {
          builder.onResolve({ filter: /^@workspace\/api-client-react$/ }, () => ({ path: "api", namespace: "ui-fixture" }));
          builder.onResolve({ filter: /^@tanstack\/react-query$/ }, () => ({ path: "query", namespace: "ui-fixture" }));
          builder.onLoad({ filter: /.*/, namespace: "ui-fixture" }, args => ({
            loader: "js",
            contents: args.path === "query" ? `
              export const useQueryClient=()=>({setQueryData(){},async invalidateQueries(){}});
            ` : `
              export const fixture={permission:false};
              export const getGetBrandingQueryKey=()=>['branding'];
              export const useGetCurrentUser=()=>({data:fixture.permission===null?undefined:{canEditFooterCredit:fixture.permission}});
              export const useGetBranding=()=>({data:{footerCredit:'م.وصل العتيبي'},isLoading:false,isError:false});
              export const useUpdateBranding=()=>({isPending:false,mutate(){}});
            `,
          }));
        },
      }],
    });
    const uiResult = spawnSync(process.execPath, ["--test", uiFile], { stdio: "inherit" });
    process.exitCode = uiResult.status ?? 1;
  }
} finally {
  await rm(dir, { recursive: true, force: true });
}
